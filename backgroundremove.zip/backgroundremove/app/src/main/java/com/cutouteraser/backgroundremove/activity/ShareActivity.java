package com.cutouteraser.backgroundremove.activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.helper.FileUtils;
import com.cutouteraser.backgroundremove.helper.mp4u;

import java.io.ByteArrayOutputStream;

public class ShareActivity extends AppCompatActivity implements View.OnClickListener {
    private RelativeLayout bannerAdContainer;
    Bitmap bitmap;
    ImageView exit;
    ImageView facebook;
    ImageView home;
    Uri imageUri;
    ImageView imageView;
    String image_path;
    ImageView instagram;
    private Intent share;
    ImageView shareImage;
    ImageView twitter;
    ImageView whatsapp;

    /* access modifiers changed from: protected */
    @SuppressLint("WrongThread")
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_share);
        getWindow().setFlags(1024, 1024);
        loadAds();
        this.home = (ImageView) findViewById(R.id.home);
        this.shareImage = (ImageView) findViewById(R.id.shareImage);
        this.facebook = (ImageView) findViewById(R.id.facebook);
        this.whatsapp = (ImageView) findViewById(R.id.whatsapp);
        this.twitter = (ImageView) findViewById(R.id.twitter);
        this.instagram = (ImageView) findViewById(R.id.instagram);
        this.shareImage.setOnClickListener(this);
        this.home.setOnClickListener(this);
        this.facebook.setOnClickListener(this);
        this.whatsapp.setOnClickListener(this);
        this.twitter.setOnClickListener(this);
        this.instagram.setOnClickListener(this);
        String stringExtra = getIntent().getStringExtra("path");
        this.image_path = stringExtra;
        this.imageUri = Uri.parse(stringExtra);
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                this.bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(), this.imageUri));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            this.bitmap = BitmapFactory.decodeFile(this.image_path);
        }
        this.imageView.setImageBitmap(this.bitmap);
//        RateDialogManager.showRateDialog(this, bundle);
    }

    private void loadAds() {
        this.bannerAdContainer = (RelativeLayout) findViewById(R.id.bannerAdContainer);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.facebook /*2131230962*/:
                Intent intent = new Intent("android.intent.action.SEND");
                this.share = intent;
                intent.setType("image/jpeg");
                this.share.putExtra("android.intent.extra.STREAM", getImageUri(this, this.bitmap));
                Intent intent2 = this.share;
                intent2.putExtra("android.intent.extra.TEXT", "bg" + " Create By : " + mp4u.package_name);
                this.share.setPackage("com.facebook.katana");
                this.share.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try {
                    startActivity(Intent.createChooser(this.share, "Share Image with Facebook"));
                    return;
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(this, "Facebook have not been installed.", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.home /*2131230999*/:
                startActivity(new Intent(this, MainActivity.class));
                return;
            case R.id.instagram /*2131231020*/:
                Intent intent3 = new Intent("android.intent.action.SEND");
                this.share = intent3;
                intent3.setType("image/jpeg");
                this.share.putExtra("android.intent.extra.STREAM", getImageUri(this, this.bitmap));
                Intent intent4 = this.share;
                intent4.putExtra("android.intent.extra.TEXT", "bg" + " Create By : " + mp4u.package_name);
                this.share.setPackage("com.instagram.android");
                try {
                    startActivity(Intent.createChooser(this.share, "Share Image with Instagram"));
                    return;
                } catch (ActivityNotFoundException unused2) {
                    Toast.makeText(this, "Instagram have not been installed.", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.shareImage /*2131231219*/:
                try {
                    Intent intent5 = new Intent("android.intent.action.SEND");
                    intent5.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                    intent5.setType(FileUtils.MIME_TYPE_IMAGE);
                    intent5.putExtra("android.intent.extra.TEXT", "bg" + " Create By : " + mp4u.package_name);
                    intent5.putExtra("android.intent.extra.STREAM", getImageUri(this, this.bitmap));
                    startActivity(Intent.createChooser(intent5, "Share Image to Other..."));
                    return;
                } catch (Exception unused3) {
                    return;
                }
            case R.id.twitter /*2131231318*/:
                Intent intent6 = new Intent("android.intent.action.SEND");
                this.share = intent6;
                intent6.setType("image/jpeg");
                this.share.putExtra("android.intent.extra.STREAM", getImageUri(this, this.bitmap));
                Intent intent7 = this.share;
                intent7.putExtra("android.intent.extra.TEXT", "bg" + " Create By : " + mp4u.package_name);
                this.share.setPackage("com.twitter.android");
                try {
                    startActivity(Intent.createChooser(this.share, "Share Image with Twitter"));
                    return;
                } catch (ActivityNotFoundException unused4) {
                    Toast.makeText(this, "Twitter have not been installed.", Toast.LENGTH_SHORT).show();
                    return;
                }
            case R.id.whatsapp /*2131231332*/:
                Intent intent8 = new Intent("android.intent.action.SEND");
                this.share = intent8;
                intent8.setType("image/jpeg");
                this.share.putExtra("android.intent.extra.STREAM", getImageUri(this, this.bitmap));
                Intent intent9 = this.share;
                intent9.putExtra("android.intent.extra.TEXT", "bg" + " Create By : " + mp4u.package_name);
                this.share.setPackage("com.whatsapp");
                try {
                    startActivity(Intent.createChooser(this.share, "Share Image with WhatsApp"));
                    return;
                } catch (ActivityNotFoundException unused5) {
                    Toast.makeText(this, "Whatsapp have not been installed.", Toast.LENGTH_SHORT).show();
                    return;
                }
            default:
                return;
        }
    }

    public Uri getImageUri(Context context, Bitmap bitmap2) {
        bitmap2.compress(Bitmap.CompressFormat.JPEG, 100, new ByteArrayOutputStream());
        return Uri.parse(MediaStore.Images.Media.insertImage(context.getContentResolver(), bitmap2, "Title", (String) null));
    }

    private void exitto() {
        try {
            new AlertDialog.Builder(this).setTitle((CharSequence) "Exit !").setMessage((CharSequence) "Do you really want to Exit?").setCancelable(false).setPositiveButton((CharSequence) "Yes", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    ShareActivity.this.finish();
                    ShareActivity.this.Intentto();
                    Intent intent = new Intent("android.intent.action.MAIN");
                    intent.addCategory("android.intent.category.HOME");
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    ShareActivity.this.startActivity(intent);
                }
            }).setNegativeButton((CharSequence) "No", (DialogInterface.OnClickListener) null).show();
        } catch (Exception unused) {
        }
    }

    /* access modifiers changed from: private */
    public void Intentto() {
        startActivity(new Intent(this, MainActivity.class));
    }

    public boolean hasInternet() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED) {
            return true;
        }
        return false;
    }

    public void onBackPressed() {
        exitto();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}
