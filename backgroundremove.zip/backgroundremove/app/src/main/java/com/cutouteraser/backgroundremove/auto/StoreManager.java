package com.cutouteraser.backgroundremove.auto;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Environment;

import com.cutouteraser.backgroundremove.R;

import java.io.File;

public class StoreManager {
    private static String BITMAP_CROPED_FILE_NAME = "temp_croped_bitmap.png";
    private static String BITMAP_CROPED_MASK_FILE_NAME = "temp_croped_mask_bitmap.png";
    private static String BITMAP_FILE_NAME = "temp_bitmap.png";
    private static String BITMAP_ORIGINAL_FILE_NAME = "temp_original_bitmap.png";
    public static int croppedLeft = 0;
    public static int croppedTop = 0;
    public static boolean isNull = false;

    public static Bitmap getCurrentCroppedMaskBitmap(Activity activity) {
        if (isNull) {
            return null;
        }
        return getBitmapByFileName(activity, BITMAP_CROPED_MASK_FILE_NAME);
    }

    public static Bitmap getCurrentCropedBitmap(Activity activity) {
        if (isNull) {
            return null;
        }
        return getBitmapByFileName(activity, BITMAP_CROPED_FILE_NAME);
    }

    public static Bitmap getCurrentOriginalBitmap(Activity activity) {
        return getBitmapByFileName(activity, BITMAP_ORIGINAL_FILE_NAME);
    }

    private static Bitmap getBitmapByFileName(Activity activity, String str) {
        return BitmapFactory.decodeFile(getWorkspaceDirPath(activity) + "/" + str);
    }

    private static String getWorkspaceDirPath(Context context) {
        if (Build.VERSION.SDK_INT >= 29) {
            return context.getExternalFilesDir(Environment.DIRECTORY_PICTURES).getAbsolutePath();
        }
        return Environment.getExternalStorageDirectory().getAbsolutePath() + context.getResources().getString(R.string.directory);
    }

    /* JADX WARNING: Removed duplicated region for block: B:21:0x003c A[SYNTHETIC, Splitter:B:21:0x003c] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0042 A[SYNTHETIC, Splitter:B:25:0x0042] */
    /* JADX WARNING: Removed duplicated region for block: B:31:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void saveFile(Context r1, Bitmap r2, String r3) {
        /*
            if (r2 != 0) goto L_0x0003
            return
        L_0x0003:
            java.lang.String r1 = getWorkspaceDirPath(r1)
            java.io.File r0 = new java.io.File
            r0.<init>(r1)
            boolean r1 = r0.exists()
            if (r1 != 0) goto L_0x0015
            r0.mkdirs()
        L_0x0015:
            java.io.File r1 = new java.io.File
            r1.<init>(r0, r3)
            r3 = 0
            java.io.FileOutputStream r0 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0036 }
            r0.<init>(r1)     // Catch:{ Exception -> 0x0036 }
            android.graphics.Bitmap$CompressFormat r1 = android.graphics.Bitmap.CompressFormat.PNG     // Catch:{ Exception -> 0x0031, all -> 0x002e }
            r3 = 100
            r2.compress(r1, r3, r0)     // Catch:{ Exception -> 0x0031, all -> 0x002e }
            r0.flush()     // Catch:{ Exception -> 0x0031, all -> 0x002e }
            r0.close()     // Catch:{ Exception -> 0x003f }
            goto L_0x003f
        L_0x002e:
            r1 = move-exception
            r3 = r0
            goto L_0x0040
        L_0x0031:
            r1 = move-exception
            r3 = r0
            goto L_0x0037
        L_0x0034:
            r1 = move-exception
            goto L_0x0040
        L_0x0036:
            r1 = move-exception
        L_0x0037:
            r1.printStackTrace()     // Catch:{ all -> 0x0034 }
            if (r3 == 0) goto L_0x003f
            r3.close()     // Catch:{ Exception -> 0x003f }
        L_0x003f:
            return
        L_0x0040:
            if (r3 == 0) goto L_0x0045
            r3.close()     // Catch:{ Exception -> 0x0045 }
        L_0x0045:
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.cutouteraser.backgroundremove.auto.StoreManager.saveFile(android.content.Context, android.graphics.Bitmap, java.lang.String):void");
    }

    public static void deleteFile(Context context, String str) {
        File file = new File(getWorkspaceDirPath(context) + "/" + str);
        if (file.exists()) {
            file.delete();
        }
    }

    public static void setCurrentCropedBitmap(Activity activity, Bitmap bitmap) {
        if (bitmap == null) {
            deleteFile(activity, BITMAP_CROPED_FILE_NAME);
            isNull = true;
        } else {
            isNull = false;
        }
        saveFile(activity, bitmap, BITMAP_CROPED_FILE_NAME);
    }

    public static void setCurrentCroppedMaskBitmap(Activity activity, Bitmap bitmap) {
        if (bitmap == null) {
            deleteFile(activity, BITMAP_CROPED_MASK_FILE_NAME);
        }
        saveFile(activity, bitmap, BITMAP_CROPED_MASK_FILE_NAME);
    }

    public static void setCurrentOriginalBitmap(Activity activity, Bitmap bitmap) {
        if (bitmap == null) {
            deleteFile(activity, BITMAP_ORIGINAL_FILE_NAME);
        }
        saveFile(activity, bitmap, BITMAP_ORIGINAL_FILE_NAME);
    }
}
