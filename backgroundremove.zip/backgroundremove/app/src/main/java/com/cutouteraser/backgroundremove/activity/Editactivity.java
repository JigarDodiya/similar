package com.cutouteraser.backgroundremove.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.adapter.BgImageAdapter;
import com.cutouteraser.backgroundremove.cropper.CropImage;
import com.cutouteraser.backgroundremove.cropper.CropImageView;
import com.cutouteraser.backgroundremove.helper.AutofitTextRel;
import com.cutouteraser.backgroundremove.helper.ComponentInfo;
import com.cutouteraser.backgroundremove.helper.FileUtils;
import com.cutouteraser.backgroundremove.helper.ImageUtils;
import com.cutouteraser.backgroundremove.helper.ItemOffsetDecoration;
import com.cutouteraser.backgroundremove.helper.LastVersionManager;
import com.cutouteraser.backgroundremove.helper.MoveGestureDetector;
import com.cutouteraser.backgroundremove.helper.RecyclerTouchListener;
import com.cutouteraser.backgroundremove.helper.ResizableStickerView;
import com.cutouteraser.backgroundremove.helper.RotateGestureDetector;
import com.cutouteraser.backgroundremove.helper.ShoveGestureDetector;
import com.cutouteraser.backgroundremove.helper.StickerView;
import com.cutouteraser.backgroundremove.helper.TextInfo;
import com.cutouteraser.backgroundremove.helper.mp4u;
import com.jaredrummler.android.colorpicker.ColorPickerDialog;
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

public class Editactivity extends Activity implements View.OnTouchListener, ColorPickerDialogListener, View.OnClickListener, ResizableStickerView.TouchEventListener, AutofitTextRel.TouchEventListener {
    public static int IMAGE_PICKER = 1;
    static String aaa;
    public static Bitmap bgBitmap;
    public static File filenew1;
    RelativeLayout Crop_Activity;
    RelativeLayout Rotation_Layout;

    /* renamed from: ac */
    String f164ac = "EEEEEE";

    /* renamed from: ad */
    RelativeLayout f165ad;

    /* renamed from: ae */
    Button f166ae;

    /* renamed from: af */
    Button f167af;

    /* renamed from: ag */
    Handler f168ag = new Handler();

    /* renamed from: ak */
    boolean f169ak = false;
    TextView app_them;
    boolean bacgkround_active = false;
    LinearLayout background;
    private RecyclerView backgroundImageList;
    ImageView background_image;
    private RelativeLayout bannerAdContainer;
    Bitmap bitmap;
    Bitmap bitmap_trans;
    Bitmap bitmap_trans_square;
    boolean checksave = false;
    String color_Type;
    LinearLayout colour;
    Button colour_pic;
    ImageButton company_ad_icon;
    TextView company_ad_name;
    float density;
    ProgressDialog dialog;
    private boolean editMode = false;
    ImageButton eraser;
    ProgressDialog f6583O;
    int f6584P;
    int f6585Q;
    final Context f6586R = this;
    CropImageView f6591W;
    int f6592X = 0;
    Boolean f6595k = true;
    SeekBar fade_seek;
    private View focusedView;
    String fotoname;
    LinearLayout gallery;
    int heightPixels;
    Boolean isTransperent = true;
    Button landscape_photo;
    RelativeLayout layout_arrange;
    private int mAlpha = 255;
    /* access modifiers changed from: private */
    public StickerView mCurrentView;
    private float mFocusX = 0.0f;
    private float mFocusY = 0.0f;
    private Handler mHandler = new Handler();
    private int mImageHeight;
    private int mImageWidth;
    private int mInterval = 2200;
    private Matrix mMatrix = new Matrix();
    private MoveGestureDetector mMoveDetector;
    private RotateGestureDetector mRotateDetector;
    private float mRotationDegrees = 0.0f;
    private ScaleGestureDetector mScaleDetector;
    private float mScaleFactor = 0.4f;
    private Animation mShakeAnimation;
    private ShoveGestureDetector mShoveDetector;
    /* access modifiers changed from: private */
    public ArrayList<View> mViews;
    private float minScaleFactor = 0.1f;
    Button portrait;
    LinearLayout save;
    RelativeLayout saveLayout;
    SeekBar seek_rotation;
    LinearLayout sticker;
    private RecyclerView stickerImageList;
    RelativeLayout stickerLayout;
    boolean stiker_active = false;
    LinearLayout text;
    RelativeLayout textStickerView;
    int widthPixels;

    public void onDelete() {
    }

    public void onDialogDismissed(int i) {
    }

    public void onDoubleTap() {
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_potraint_activity);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.widthPixels = displayMetrics.widthPixels;
        this.heightPixels = displayMetrics.heightPixels;
        getWindow().setFlags(1024, 1024);
        this.density = getResources().getDisplayMetrics().density;
        initView();
        this.bannerAdContainer = (RelativeLayout) findViewById(R.id.bannerAdContainer);
    }

    public static int getDisplayWidth(Activity activity) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i = displayMetrics.heightPixels;
        return displayMetrics.widthPixels;
    }

    private void initView() {
        this.background_image = (ImageView) findViewById(R.id.background_image);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.rootRelative);
        this.saveLayout = relativeLayout;
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(getDisplayWidth(this), getDisplayWidth(this)));
        this.background_image.setLayoutParams(new RelativeLayout.LayoutParams(getDisplayWidth(this), getDisplayWidth(this)));
        this.textStickerView = (RelativeLayout) findViewById(R.id.textStickerView);
        this.stickerLayout = (RelativeLayout) findViewById(R.id.stickerLayout);
        this.mViews = new ArrayList<>();
        this.bitmap_trans = BitmapFactory.decodeResource(getResources(), R.drawable.trans);
        this.bitmap_trans_square = BitmapFactory.decodeResource(getResources(), R.drawable.trans_square);
        Bitmap bitmap2 = BGRemoverActivity.highResolutionOutput;
        this.bitmap = bitmap2;
        Bitmap resizeImageToNewSize = resizeImageToNewSize(bitmap2, this.widthPixels, this.heightPixels);
        this.bitmap = resizeImageToNewSize;
        if (resizeImageToNewSize != null) {
            addCropImage(resizeImageToNewSize);
        } else {
            Toast.makeText(this, "Error in Image", Toast.LENGTH_SHORT).show();
        }
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.b2);
        bgBitmap = decodeResource;
        Bitmap resizeImageToNewSize2 = resizeImageToNewSize(decodeResource, this.widthPixels, this.heightPixels);
        bgBitmap = resizeImageToNewSize2;
        this.background_image.setImageBitmap(resizeImageToNewSize2);
        this.background = (LinearLayout) findViewById(R.id.background);
        this.gallery = (LinearLayout) findViewById(R.id.gallery);
        this.colour = (LinearLayout) findViewById(R.id.color);
        this.text = (LinearLayout) findViewById(R.id.text);
        this.sticker = (LinearLayout) findViewById(R.id.sticker);
        this.save = (LinearLayout) findViewById(R.id.save);
        this.backgroundImageList = (RecyclerView) findViewById(R.id.backgroundImageList);
        this.stickerImageList = (RecyclerView) findViewById(R.id.stickerImageList);
        this.background_image.setOnClickListener(this);
        this.background.setOnClickListener(this);
        this.gallery.setOnClickListener(this);
        this.colour.setOnClickListener(this);
        this.text.setOnClickListener(this);
        this.sticker.setOnClickListener(this);
        this.save.setOnClickListener(this);
    }

    private void addCropImage(Bitmap bitmap2) {
        final StickerView stickerView = new StickerView(this);
        stickerView.setBitmap(bitmap2);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            public void onDeleteClick() {
                Editactivity.this.mViews.remove(stickerView);
                Editactivity.this.saveLayout.removeView(stickerView);
            }

            public void onEdit(StickerView stickerView) {
                Editactivity.this.mCurrentView.setInEdit(false);
                StickerView unused = Editactivity.this.mCurrentView = stickerView;
                Editactivity.this.mCurrentView.setInEdit(true);
            }

            public void onTop(StickerView stickerView) {
                int indexOf = Editactivity.this.mViews.indexOf(stickerView);
                if (indexOf != Editactivity.this.mViews.size() - 1) {
                    Editactivity.this.mViews.add(Editactivity.this.mViews.size(), (StickerView) Editactivity.this.mViews.remove(indexOf));
                }
            }
        });
        this.saveLayout.addView(stickerView, new RelativeLayout.LayoutParams(-1, -1));
        this.mViews.add(stickerView);
        setCurrentEdit(stickerView);
    }

    private void setCurrentEdit(StickerView stickerView) {
        StickerView stickerView2 = this.mCurrentView;
        if (stickerView2 != null) {
            stickerView2.setInEdit(false);
        }
        this.mCurrentView = stickerView;
        stickerView.setInEdit(true);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.background:
                this.backgroundImageList.setVisibility(View.VISIBLE);
                this.stickerImageList.setVisibility(View.GONE);
                openBackgroundsList();
                return;
            case R.id.background_image:
                removeImageViewControll();
                StickerView stickerView = this.mCurrentView;
                if (stickerView != null) {
                    stickerView.setInEdit(false);
                    return;
                }
                return;
            case R.id.color:
                openColorBox();
                return;
            case R.id.gallery:
                openGallery();
                return;
            case R.id.save:
                removeImageViewControll();
                StickerView stickerView2 = this.mCurrentView;
                if (stickerView2 != null) {
                    stickerView2.setInEdit(false);
                }
                this.checksave = true;
                new asynsaving().execute(new Void[0]);
                return;
            case R.id.sticker:
                this.stickerImageList.setVisibility(View.VISIBLE);
                this.backgroundImageList.setVisibility(View.GONE);
                openStickerList();
                return;
            case R.id.text:
                startActivityForResult(new Intent(this, TextActivity.class), 101);
                return;
            default:
                return;
        }
    }

    private void openColorBox() {
        new ColorPickerDialog();
//        ColorPickerDialog.newBuilder().setDialogType(ColorPickerDialog.TYPE_CUSTOM).setAllowPresets(false).setDialogId(0).setColor(-16777216).setShowAlphaSlider(true).show(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void openBackgroundsList() {
        BgImageAdapter bgImageAdapter = new BgImageAdapter(this, mp4u.bgList);
        this.backgroundImageList.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.backgroundImageList.setItemAnimator(new DefaultItemAnimator());
        if (!this.bacgkround_active) {
            this.bacgkround_active = true;
            this.backgroundImageList.addItemDecoration(new ItemOffsetDecoration(this, R.dimen.item_offset));
        }
        this.backgroundImageList.setAdapter(bgImageAdapter);
        this.backgroundImageList.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), this.backgroundImageList, new RecyclerTouchListener.ClickListener() {
            public void onLongClick(View view, int i) {
            }

            public void onClick(View view, int i) {
                if (i == 0) {
                    Editactivity.this.isTransperent = true;
                    Editactivity.this.background_image.setVisibility(View.GONE);
                } else if (i >= 28) {
                    Editactivity.this.isTransperent = true;
                    Editactivity.this.background_image.setVisibility(View.VISIBLE);
                    Editactivity.this.background_image.setImageBitmap(BitmapFactory.decodeResource(Editactivity.this.getResources(), mp4u.bgList[i]));
                } else {
                    Editactivity.this.isTransperent = false;
                    Editactivity.this.background_image.setVisibility(View.VISIBLE);
                    Editactivity.this.background_image.setImageBitmap(BitmapFactory.decodeResource(Editactivity.this.getResources(), mp4u.bgList[i]));
                }
            }
        }));
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    private void openStickerList() {
        BgImageAdapter bgImageAdapter = new BgImageAdapter(this, mp4u.stickerList);
        this.stickerImageList.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        this.stickerImageList.setItemAnimator(new DefaultItemAnimator());
        if (!this.stiker_active) {
            this.stiker_active = true;
            this.stickerImageList.addItemDecoration(new ItemOffsetDecoration(this, R.dimen.item_offset));
        }
        this.stickerImageList.setAdapter(bgImageAdapter);
        this.stickerImageList.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), this.stickerImageList, new RecyclerTouchListener.ClickListener() {
            public void onLongClick(View view, int i) {
            }

            public void onClick(View view, int i) {
                Editactivity editactivity = Editactivity.this;
                editactivity.addSticker(0, BitmapFactory.decodeResource(editactivity.getResources(), mp4u.stickerList[i]));
            }
        }));
    }

    /* access modifiers changed from: private */
    public void addSticker(int i, Bitmap bitmap2) {
        ComponentInfo componentInfo = new ComponentInfo();
        componentInfo.setPOS_X((float) ((this.saveLayout.getWidth() / 2) - ImageUtils.dpToPx(this, 70)));
        componentInfo.setPOS_Y((float) ((this.saveLayout.getHeight() / 2) - ImageUtils.dpToPx(this, 70)));
        componentInfo.setWIDTH(ImageUtils.dpToPx(this, 140));
        componentInfo.setHEIGHT(ImageUtils.dpToPx(this, 140));
        componentInfo.setROTATION(0.0f);
        componentInfo.setRES_ID(i);
        componentInfo.setBITMAP(bitmap2);
        componentInfo.setCOLORTYPE(this.color_Type);
        componentInfo.setTYPE("STICKER");
        ResizableStickerView resizableStickerView = new ResizableStickerView(this);
        resizableStickerView.setComponentInfo(componentInfo);
        this.stickerLayout.addView(resizableStickerView);
        resizableStickerView.setOnTouchCallbackListener(this);
        resizableStickerView.setBorderVisibility(true);
        new FrameLayout.LayoutParams(100, 100, 17).setMargins(0, 0, 0, 0);
    }

    /* access modifiers changed from: protected */
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != 20) {
            if (i == 101) {
                try {
                    Bundle extras = intent.getExtras();
                    TextInfo textInfo = new TextInfo();
                    textInfo.setPOS_X((float) extras.getInt("X", 0));
                    textInfo.setPOS_Y((float) extras.getInt("Y", 0));
                    textInfo.setWIDTH(extras.getInt("wi", mp4u.dpToPx(this, 200)));
                    textInfo.setHEIGHT(extras.getInt("he", mp4u.dpToPx(this, 200)));
                    textInfo.setTEXT(extras.getString("text", ""));
                    textInfo.setFONT_NAME(extras.getString("fontName", ""));
                    textInfo.setTEXT_COLOR(extras.getInt("tColor", Color.parseColor("#4149b6")));
                    textInfo.setTEXT_ALPHA(extras.getInt("tAlpha", 100));
                    textInfo.setSHADOW_COLOR(extras.getInt("shadowColor", Color.parseColor("#7641b6")));
                    textInfo.setSHADOW_PROG(extras.getInt("shadowProg", 5));
                    textInfo.setBG_COLOR(extras.getInt("bgColor", 0));
                    textInfo.setBG_DRAWABLE(extras.getString("bgDrawable", "0"));
                    textInfo.setBG_ALPHA(extras.getInt("bgAlpha", 255));
                    textInfo.setROTATION(extras.getFloat("rotation", 0.0f));
                    if (this.editMode) {
                        RelativeLayout relativeLayout = this.textStickerView;
                        ((AutofitTextRel) relativeLayout.getChildAt(relativeLayout.getChildCount() - 1)).setTextInfo(textInfo);
                        this.editMode = false;
                    } else {
                        AutofitTextRel autofitTextRel = new AutofitTextRel(this);
                        this.textStickerView.addView(autofitTextRel);
                        autofitTextRel.setTextInfo(textInfo);
                        autofitTextRel.setOnTouchCallbackListener(this);
                        autofitTextRel.setBorderVisibility(true);
                    }
                } catch (Exception unused) {
                }
                this.editMode = false;
            }
        } else if (i2 == -1) {
            try {
                Uri data = intent.getData();
                CropImage.activity(data).setGuidelines(CropImageView.Guidelines.ON).setActivityTitle("Crop Image").setCropShape(CropImageView.CropShape.RECTANGLE).setAspectRatio(5, 5).setCropMenuCropButtonTitle("Done").start(this);
                FileUtils.getPath(this, data);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (i == 203) {
            CropImage.ActivityResult activityResult = CropImage.getActivityResult(intent);
            if (i2 == -1) {
                this.background_image.setImageBitmap(Bitmap.createScaledBitmap(BitmapFactory.decodeFile(FileUtils.getPath(this, activityResult.getUri())), 800, 800, false));
                this.background_image.setVisibility(View.VISIBLE);
            } else if (i2 == 204) {
                Toast.makeText(this, "Cropping failed: " + activityResult.getError(), Toast.LENGTH_LONG).show();
            }
        }
    }

    public void onEdit(View view, String str) {
        if (str.equals("gone")) {
            if (view != this.focusedView) {
                this.focusedView = view;
            }
            boolean z = this.focusedView instanceof ResizableStickerView;
            return;
        }
        visibleIs();
    }

    public void onTouchDown(View view) {
        if (view != this.focusedView) {
            removeImageViewControll();
            this.focusedView = view;
            if (view instanceof ResizableStickerView) {
                this.stickerLayout.bringToFront();
            } else {
                this.textStickerView.bringToFront();
            }
        }
        boolean z = this.focusedView instanceof ResizableStickerView;
    }

    public void onTouchUp(View view) {
        visibleIs();
    }

    private void visibleIs() {
        try {
            if (this.focusedView instanceof ResizableStickerView) {
                int childCount = this.stickerLayout.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    ((ResizableStickerView) this.stickerLayout.getChildAt(i)).setBorderVisibility(true);
                }
            }
            if (this.focusedView instanceof AutofitTextRel) {
                int childCount2 = this.textStickerView.getChildCount();
                for (int i2 = 0; i2 < childCount2; i2++) {
                    ((AutofitTextRel) this.textStickerView.getChildAt(i2)).setBorderVisibility(true);
                }
            }
        } catch (Exception unused) {
        }
    }

    public void removeImageViewControll() {
        int childCount = this.stickerLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = this.stickerLayout.getChildAt(i);
            if (childAt instanceof ResizableStickerView) {
                ((ResizableStickerView) childAt).setBorderVisibility(false);
            }
        }
        int childCount2 = this.textStickerView.getChildCount();
        for (int i2 = 0; i2 < childCount2; i2++) {
            View childAt2 = this.textStickerView.getChildAt(i2);
            if (childAt2 instanceof AutofitTextRel) {
                ((AutofitTextRel) childAt2).setBorderVisibility(false);
            }
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        PrintStream printStream = System.out;
        printStream.println("****" + view);
        this.mScaleDetector.onTouchEvent(motionEvent);
        this.mRotateDetector.onTouchEvent(motionEvent);
        this.mMoveDetector.onTouchEvent(motionEvent);
        this.mShoveDetector.onTouchEvent(motionEvent);
        System.out.println("################################");
        float f = this.mScaleFactor;
        float f2 = (((float) this.mImageWidth) * f) / 2.0f;
        float f3 = (((float) this.mImageHeight) * f) / 2.0f;
        this.mMatrix.reset();
        Matrix matrix = this.mMatrix;
        float f4 = this.mScaleFactor;
        matrix.postScale(f4, f4);
        this.mMatrix.postRotate(this.mRotationDegrees, f2, f3);
        this.mMatrix.postTranslate(this.mFocusX - f2, this.mFocusY - f3);
        float f5 = this.mFocusX - f2;
        float f6 = this.mFocusY - f3;
        PrintStream printStream2 = System.out;
        printStream2.println("### x_position" + f5 + "y_position" + f6);
        ImageView imageView = (ImageView) view;
        imageView.setImageMatrix(this.mMatrix);
        imageView.setAlpha(this.mAlpha);
        return true;
    }

    public void onColorSelected(int i, int i2) {
        Bitmap createBitmap = Bitmap.createBitmap(800, 800, Bitmap.Config.ARGB_8888);
        createBitmap.eraseColor(i2);
        this.background_image.setImageBitmap(createBitmap);
        this.isTransperent = true;
        this.background_image.setVisibility(View.VISIBLE);
    }

    private Bitmap resizeImageToNewSize(Bitmap bitmap2, int i, int i2) {
        getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
        double d = (double) i2;
        double d2 = (double) i;
        if (((double) bitmap2.getHeight()) / ((double) bitmap2.getWidth()) < d / d2) {
            i2 = (int) (d2 * (((double) bitmap2.getHeight()) / ((double) bitmap2.getWidth())));
        } else {
            i = (int) (d * (((double) bitmap2.getWidth()) / ((double) bitmap2.getHeight())));
        }
        return Bitmap.createScaledBitmap(bitmap2, i, i2, false);
    }

    public Bitmap getScreenShot() {
        View findViewById = findViewById(R.id.rootRelative);
        findViewById.setDrawingCacheEnabled(true);
        Bitmap createBitmap = Bitmap.createBitmap(findViewById.getDrawingCache());
        findViewById.setDrawingCacheEnabled(false);
        Bitmap createBitmap2 = Bitmap.createBitmap(createBitmap.getWidth(), createBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        findViewById.draw(new Canvas(createBitmap2));
        return createBitmap2;
    }

    public void ScreenOut() {
        float f = this.mFocusX;
        if (f <= 0.0f) {
            this.mFocusX = 0.0f;
            return;
        }
        float f2 = this.mFocusY;
        if (f2 <= 0.0f) {
            this.mFocusY = 0.0f;
            return;
        }
        float f3 = (float) this.f6584P;
        if (f > f3) {
            this.mFocusX = f3;
            return;
        }
        float f4 = (float) this.f6585Q;
        if (f2 > f4) {
            this.mFocusY = f4;
        }
    }

    public void openGallery() {
        Intent intent = new Intent("android.intent.action.PICK");
        intent.setDataAndType(Uri.parse(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath()), FileUtils.MIME_TYPE_IMAGE);
        startActivityForResult(intent, 20);
    }

    private class asynsaving extends AsyncTask<Void, Void, Void> {
        private asynsaving() {
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
            Editactivity.this.dialog = new ProgressDialog(Editactivity.this, 4);
            if (Editactivity.this.checksave) {
                Editactivity.this.dialog.setMessage("Saving...");
            }
            Editactivity.this.dialog.show();
            Editactivity.this.dialog.setCancelable(false);
        }

        /* access modifiers changed from: protected */
        /* JADX WARNING: Can't wrap try/catch for region: R(11:6|(1:8)|9|(2:11|(1:13)(1:14))(2:15|(1:17)(1:18))|19|20|21|(1:23)(1:24)|25|26|27) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:26:0x00ca */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public Void doInBackground(Void... r7) {
            /*
                r6 = this;
                com.cutouteraser.backgroundremove.activity.Editactivity r7 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                android.graphics.Bitmap r7 = r7.getScreenShot()
                int r0 = android.os.Build.VERSION.SDK_INT
                r1 = 0
                java.lang.String r2 = "Image"
                r3 = 30
                if (r0 < r3) goto L_0x002f
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this     // Catch:{ IOException -> 0x0029 }
                java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x0029 }
                r3.<init>()     // Catch:{ IOException -> 0x0029 }
                r3.append(r2)     // Catch:{ IOException -> 0x0029 }
                long r4 = java.lang.System.currentTimeMillis()     // Catch:{ IOException -> 0x0029 }
                r3.append(r4)     // Catch:{ IOException -> 0x0029 }
                java.lang.String r2 = r3.toString()     // Catch:{ IOException -> 0x0029 }
                android.net.Uri unused = com.cutouteraser.backgroundremove.activity.Editactivity.saveImages(r0, r7, r2)     // Catch:{ IOException -> 0x0029 }
                goto L_0x00e0
            L_0x0029:
                r7 = move-exception
                r7.printStackTrace()
                goto L_0x00e0
            L_0x002f:
                java.io.File r0 = com.cutouteraser.backgroundremove.helper.mp4u.newDir
                boolean r0 = r0.exists()
                if (r0 != 0) goto L_0x003c
                java.io.File r0 = com.cutouteraser.backgroundremove.helper.mp4u.newDir
                r0.mkdir()
            L_0x003c:
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                java.lang.Boolean r0 = r0.isTransperent
                boolean r0 = r0.booleanValue()
                if (r0 == 0) goto L_0x0070
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                boolean r0 = r0.checksave
                if (r0 == 0) goto L_0x0069
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                r3.<init>()
                r3.append(r2)
                long r4 = java.lang.System.currentTimeMillis()
                r3.append(r4)
                java.lang.String r2 = ".png"
                r3.append(r2)
                java.lang.String r2 = r3.toString()
                r0.fotoname = r2
                goto L_0x0099
            L_0x0069:
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                java.lang.String r2 = "Image.png"
                r0.fotoname = r2
                goto L_0x0099
            L_0x0070:
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                boolean r0 = r0.checksave
                if (r0 == 0) goto L_0x0093
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                r3.<init>()
                r3.append(r2)
                long r4 = java.lang.System.currentTimeMillis()
                r3.append(r4)
                java.lang.String r2 = ".jpg"
                r3.append(r2)
                java.lang.String r2 = r3.toString()
                r0.fotoname = r2
                goto L_0x0099
            L_0x0093:
                com.cutouteraser.backgroundremove.activity.Editactivity r0 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                java.lang.String r2 = "Image.jpg"
                r0.fotoname = r2
            L_0x0099:
                java.io.File r0 = new java.io.File
                java.io.File r2 = com.cutouteraser.backgroundremove.helper.mp4u.newDir
                com.cutouteraser.backgroundremove.activity.Editactivity r3 = com.cutouteraser.backgroundremove.activity.Editactivity.this
                java.lang.String r3 = r3.fotoname
                r0.<init>(r2, r3)
                com.cutouteraser.backgroundremove.activity.Editactivity.filenew1 = r0
                java.io.FileOutputStream r0 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x00ca }
                java.io.File r2 = com.cutouteraser.backgroundremove.activity.Editactivity.filenew1     // Catch:{ Exception -> 0x00ca }
                r0.<init>(r2)     // Catch:{ Exception -> 0x00ca }
                com.cutouteraser.backgroundremove.activity.Editactivity r2 = com.cutouteraser.backgroundremove.activity.Editactivity.this     // Catch:{ Exception -> 0x00ca }
                java.lang.Boolean r2 = r2.isTransperent     // Catch:{ Exception -> 0x00ca }
                boolean r2 = r2.booleanValue()     // Catch:{ Exception -> 0x00ca }
                r3 = 100
                if (r2 == 0) goto L_0x00bf
                android.graphics.Bitmap$CompressFormat r2 = android.graphics.Bitmap.CompressFormat.PNG     // Catch:{ Exception -> 0x00ca }
                r7.compress(r2, r3, r0)     // Catch:{ Exception -> 0x00ca }
                goto L_0x00c4
            L_0x00bf:
                android.graphics.Bitmap$CompressFormat r2 = android.graphics.Bitmap.CompressFormat.JPEG     // Catch:{ Exception -> 0x00ca }
                r7.compress(r2, r3, r0)     // Catch:{ Exception -> 0x00ca }
            L_0x00c4:
                r0.flush()     // Catch:{ Exception -> 0x00ca }
                r0.close()     // Catch:{ Exception -> 0x00ca }
            L_0x00ca:
                com.cutouteraser.backgroundremove.activity.Editactivity r7 = com.cutouteraser.backgroundremove.activity.Editactivity.this     // Catch:{ Exception -> 0x00e0 }
                r0 = 1
                java.lang.String[] r0 = new java.lang.String[r0]     // Catch:{ Exception -> 0x00e0 }
                r2 = 0
                java.io.File r3 = com.cutouteraser.backgroundremove.activity.Editactivity.filenew1     // Catch:{ Exception -> 0x00e0 }
                java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x00e0 }
                r0[r2] = r3     // Catch:{ Exception -> 0x00e0 }
                com.cutouteraser.backgroundremove.activity.Editactivity$asynsaving$1 r2 = new com.cutouteraser.backgroundremove.activity.Editactivity$asynsaving$1     // Catch:{ Exception -> 0x00e0 }
                r2.<init>()     // Catch:{ Exception -> 0x00e0 }
                android.media.MediaScannerConnection.scanFile(r7, r0, r1, r2)     // Catch:{ Exception -> 0x00e0 }
            L_0x00e0:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.cutouteraser.backgroundremove.activity.Editactivity.asynsaving.doInBackground(java.lang.Void[]):java.lang.Void");
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Void voidR) {
            String str;
            super.onPostExecute(voidR);
            if (Editactivity.this.dialog.isShowing()) {
                Editactivity.this.dialog.dismiss();
            }
            if (Editactivity.this.checksave) {
                Intent intent = new Intent(Editactivity.this, ShareActivity.class);
                if (Build.VERSION.SDK_INT >= 30) {
                    str = Editactivity.aaa.toString();
                    LastVersionManager.addImageToMyPhotos(Editactivity.this.getApplicationContext(), str);
                    intent.putExtra("path", Editactivity.aaa);
                } else {
                    str = Editactivity.filenew1.getPath();
                    intent.putExtra("path", Editactivity.filenew1.toString());
                }
                Editactivity.this.startActivity(intent);
                Context applicationContext = Editactivity.this.getApplicationContext();
                Toast.makeText(applicationContext, "Image Successfully Save to:" + str, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /* access modifiers changed from: private */
    public static Uri saveImages(Context context, Bitmap bitmap2, String str) throws IOException {
        Uri uri;
        OutputStream outputStream;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver contentResolver = context.getContentResolver();
            ContentValues contentValues = new ContentValues();
            contentValues.put("_display_name", str);
            contentValues.put("mime_type", "image/png");
            contentValues.put("relative_path", Environment.DIRECTORY_PICTURES + File.separator + "BackgroundEraser");
            uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            outputStream = contentResolver.openOutputStream(uri);
            aaa = uri.toString();
        } else {
            String str2 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).toString() + File.separator;
            File file = new File(str2);
            if (!file.exists()) {
                file.mkdir();
            }
            outputStream = new FileOutputStream(new File(str2, str + ".png"));
            uri = null;
        }
        bitmap2.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        outputStream.flush();
        outputStream.close();
        return uri;
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}
