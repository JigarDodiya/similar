package com.cutouteraser.backgroundremove.activity;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.adapter.CreationAdapter;
import com.cutouteraser.backgroundremove.helper.ExifHelper;
import com.cutouteraser.backgroundremove.helper.LastVersionManager;
import com.cutouteraser.backgroundremove.helper.mp4u;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;

public class MyCreationActivity extends Activity {
    private RelativeLayout bannerAdContainer;
    private ImageView bback;
    ExifHelper exif = new ExifHelper();
    private CreationAdapter galleryAdapter;
    private GridView lstList;
    private ImageView noImage;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_my_creation);
        getWindow().setFlags(1024, 1024);
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
        bindView();
    }

    private void bindView() {
        this.noImage = (ImageView) findViewById(R.id.novideoimg);
        this.lstList = (GridView) findViewById(R.id.lstList);
        getImages();
        if (mp4u.IMAGEALLARY.size() <= 0) {
            this.noImage.setVisibility(View.VISIBLE);
            this.lstList.setVisibility(View.GONE);
        } else {
            this.noImage.setVisibility(View.GONE);
            this.lstList.setVisibility(View.VISIBLE);
        }
        ImageView imageView = (ImageView) findViewById(R.id.back);
        this.bback = imageView;
        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MyCreationActivity.this.finish();
            }
        });
        Collections.sort(mp4u.IMAGEALLARY);
        Collections.reverse(mp4u.IMAGEALLARY);
        CreationAdapter creationAdapter = new CreationAdapter(this, mp4u.IMAGEALLARY);
        this.galleryAdapter = creationAdapter;
        this.lstList.setAdapter(creationAdapter);
    }

    private void getImages() {
        if (Build.VERSION.SDK_INT < 23) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
            fetchImage();
        } else if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 5);
        }
    }

    private void fetchImage() {
        mp4u.IMAGEALLARY.clear();
        if (Build.VERSION.SDK_INT >= 30) {
            mp4u.IMAGEALLARY = LastVersionManager.getImageListMyPhotos(getApplicationContext());
            return;
        }
        mp4u.listAllImages(new File("/mnt/sdcard/" + mp4u.Edit_Folder_name + "/"));
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 5) {
            if (iArr[0] == 0) {
                fetchImage();
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 5);
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x001c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void saveExif(Uri r6) throws IOException {
        /*
            r5 = this;
            java.lang.String r6 = r5.getContentFilename(r6)
            if (r6 == 0) goto L_0x0077
            r0 = 0
            android.content.pm.PackageManager r1 = r5.getPackageManager()     // Catch:{ NameNotFoundException -> 0x0019 }
            java.lang.String r2 = r5.getPackageName()     // Catch:{ NameNotFoundException -> 0x0019 }
            r3 = 0
            android.content.pm.PackageInfo r1 = r1.getPackageInfo(r2, r3)     // Catch:{ NameNotFoundException -> 0x0019 }
            if (r1 == 0) goto L_0x0019
            java.lang.String r1 = r1.versionName     // Catch:{ NameNotFoundException -> 0x0019 }
            goto L_0x001a
        L_0x0019:
            r1 = r0
        L_0x001a:
            if (r1 != 0) goto L_0x001e
            java.lang.String r1 = "0.0"
        L_0x001e:
            com.cutouteraser.backgroundremove.helper.ExifHelper r2 = r5.exif
            java.lang.String r3 = r5.currentTimeAsExif()
            java.lang.String r4 = "DateTime"
            r2.setAttribute(r4, r3)
            com.cutouteraser.backgroundremove.helper.ExifHelper r2 = r5.exif
            java.lang.String r3 = "Orientation"
            java.lang.String r4 = "0"
            r2.setAttribute(r3, r4)
            com.cutouteraser.backgroundremove.helper.ExifHelper r2 = r5.exif
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            r4 = 2131689503(0x7f0f001f, float:1.9008023E38)
            java.lang.String r4 = r5.getString(r4)
            r3.append(r4)
            r3.append(r1)
            java.lang.String r1 = " (Android)"
            r3.append(r1)
            java.lang.String r1 = r3.toString()
            java.lang.String r3 = "Software"
            r2.setAttribute(r3, r1)
            com.cutouteraser.backgroundremove.helper.ExifHelper r1 = r5.exif
            java.lang.String r2 = "Description"
            java.lang.String r3 = "Made with MP4u Apps "
            r1.setAttribute(r2, r3)
            com.cutouteraser.backgroundremove.helper.ExifHelper r1 = r5.exif
            java.lang.String r2 = "ImageLength"
            r1.setAttribute(r2, r0)
            com.cutouteraser.backgroundremove.helper.ExifHelper r1 = r5.exif
            java.lang.String r2 = "ImageWidth"
            r1.setAttribute(r2, r0)
            com.cutouteraser.backgroundremove.helper.ExifHelper r1 = r5.exif
            java.lang.String r2 = "ImageHeight"
            r1.setAttribute(r2, r0)
            com.cutouteraser.backgroundremove.helper.ExifHelper r0 = r5.exif
            r0.writeExif(r6)
        L_0x0077:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.cutouteraser.backgroundremove.activity.MyCreationActivity.saveExif(android.net.Uri):void");
    }

    /* access modifiers changed from: package-private */
    public String currentTimeAsExif() {
        return new SimpleDateFormat("yyyy:MM:dd HH:mm:ss").format(new Date());
    }

    /* access modifiers changed from: package-private */
    public String getContentFilename(Uri uri) throws IOException {
        if (uri == null) {
            return null;
        }
        if ("file".equals(uri.getScheme())) {
            return uri.getPath();
        }
        Cursor query = getContentResolver().query(uri, new String[]{"_data"}, (String) null, (String[]) null, (String) null);
        if (query == null) {
            return null;
        }
        int columnIndexOrThrow = query.getColumnIndexOrThrow("_data");
        query.moveToFirst();
        return query.getString(columnIndexOrThrow);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}
