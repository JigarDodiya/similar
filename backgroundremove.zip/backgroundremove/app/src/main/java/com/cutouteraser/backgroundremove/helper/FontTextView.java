package com.cutouteraser.backgroundremove.helper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

public class FontTextView extends TextView {
    public FontTextView(Context context) {
        super(context);
        setTypeface(Typeface.createFromAsset(context.getAssets(), "splashfonts.ttf"));
    }

    public FontTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setTypeface(Typeface.createFromAsset(context.getAssets(), "splashfonts.ttf"));
    }

    public FontTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setTypeface(Typeface.createFromAsset(context.getAssets(), "splashfonts.ttf"));
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }
}
