package com.cutouteraser.backgroundremove.activity;

import android.view.View;

public final /* synthetic */ class SettingsActivity$$ExternalSyntheticLambda0 implements View.OnClickListener {
    public final /* synthetic */ SettingsActivity f$0;

    public /* synthetic */ SettingsActivity$$ExternalSyntheticLambda0(SettingsActivity settingsActivity) {
        this.f$0 = settingsActivity;
    }

    public final void onClick(View view) {
        this.f$0.mo12864x34b5a3be(view);
    }
}
