package com.cutouteraser.backgroundremove.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.bumptech.glide.Glide;
import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.helper.FileUtils;
import com.cutouteraser.backgroundremove.helper.LastVersionManager;
import com.cutouteraser.backgroundremove.helper.mp4u;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;

public class CreationAdapter extends BaseAdapter {
    private static LayoutInflater inflater;
    /* access modifiers changed from: private */
    public Activity dactivity;
    private int imageSize;
    ArrayList<String> imagegallary = new ArrayList<>();
    SparseBooleanArray mSparseBooleanArray;
    MediaMetadataRetriever metaRetriever;

    /* renamed from: vi */
    View f170vi;

    public long getItemId(int i) {
        return (long) i;
    }

    static class ViewHolder {
        public FrameLayout frm;
        ImageView imgIcon;

        ViewHolder() {
        }
    }

    public CreationAdapter(Activity activity, ArrayList<String> arrayList) {
        this.dactivity = activity;
        this.imagegallary = arrayList;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mSparseBooleanArray = new SparseBooleanArray(this.imagegallary.size());
    }

    public int getCount() {
        return this.imagegallary.size();
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        int i2 = this.dactivity.getResources().getDisplayMetrics().widthPixels;
        if (view == null) {
            view = LayoutInflater.from(this.dactivity).inflate(R.layout.list_gallary, viewGroup, false);
            viewHolder = new ViewHolder();
            viewHolder.frm = (FrameLayout) view.findViewById(R.id.frm);
            viewHolder.imgIcon = (ImageView) view.findViewById(R.id.imgIcon);
            viewHolder.imgIcon.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.Q)
                public void onClick(View view) {
                    @SuppressLint("ResourceType") final Dialog dialog = new Dialog(CreationAdapter.this.dactivity, 16973839);
                    DisplayMetrics displayMetrics = new DisplayMetrics();
                    CreationAdapter.this.dactivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                    int i = (int) (((double) displayMetrics.widthPixels) * 1.0d);
                    dialog.requestWindowFeature(1);
                    dialog.getWindow().setFlags(1024, 1024);
                    dialog.setContentView(R.layout.layout_fullscreen_image);
                    dialog.getWindow().setLayout(i, (int) (((double) displayMetrics.heightPixels)));
                    dialog.setCanceledOnTouchOutside(true);
                    ((ImageView) dialog.findViewById(R.id.imgDisplay)).setImageURI(Uri.parse(mp4u.IMAGEALLARY.get(i)));
                    ((LinearLayout) dialog.findViewById(R.id.imgShare)).setOnClickListener(new View.OnClickListener() {
                        @RequiresApi(api = Build.VERSION_CODES.Q)
                        public void onClick(View view) {
                            Bitmap bitmap;
                            if (Build.VERSION.SDK_INT >= 30) {
                                try {
                                    bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(CreationAdapter.this.dactivity.getContentResolver(), Uri.parse(mp4u.IMAGEALLARY.get(i))));
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    bitmap = null;
                                }
                            } else {
                                bitmap = BitmapFactory.decodeFile(new File(mp4u.IMAGEALLARY.get(i)).toString());
                            }
                            if (bitmap != null) {
                                try {
                                    Intent intent = new Intent("android.intent.action.SEND");
                                    intent.setType(FileUtils.MIME_TYPE_IMAGE);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                                    intent.putExtra("android.intent.extra.TEXT", "bg" + " Create By : " + mp4u.package_name);
                                    intent.putExtra("android.intent.extra.STREAM", CreationAdapter.this.getImageUri(CreationAdapter.this.dactivity, bitmap));
                                    CreationAdapter.this.dactivity.startActivity(Intent.createChooser(intent, "Share Image using"));
                                    dialog.dismiss();
                                } catch (Exception e2) {
                                    Log.e("Creation Adapter", e2.getMessage());
                                }
                            }
                        }
                    });
                    ((LinearLayout) dialog.findViewById(R.id.imgDelete)).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {
                            @SuppressLint("ResourceType") final Dialog dialog = new Dialog(CreationAdapter.this.dactivity, 16973839);
                            dialog.requestWindowFeature(1);
                            dialog.setContentView(R.layout.delete_confirmation);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                            dialog.setCanceledOnTouchOutside(true);
                            ((TextView) dialog.findViewById(R.id.delete_yes)).setOnClickListener(new View.OnClickListener() {
                                public void onClick(View view) {
                                    if (Build.VERSION.SDK_INT >= 30) {
                                        LastVersionManager.removeImageFromMyPhotos(CreationAdapter.this.dactivity, CreationAdapter.this.imagegallary.get(i));
                                        CreationAdapter.this.imagegallary.remove(i);
                                        CreationAdapter.this.notifyDataSetChanged();
                                        if (CreationAdapter.this.imagegallary.size() == 0) {
                                            Toast.makeText(CreationAdapter.this.dactivity, "No Image Found..", Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        File file = new File(CreationAdapter.this.imagegallary.get(i));
                                        if (file.exists()) {
                                            file.delete();
                                        }
                                        CreationAdapter.this.imagegallary.remove(i);
                                        CreationAdapter.this.dactivity.sendBroadcast(new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE", Uri.fromFile(new File(String.valueOf(file)))));
                                        CreationAdapter.this.notifyDataSetChanged();
                                        if (CreationAdapter.this.imagegallary.size() == 0) {
                                            Toast.makeText(CreationAdapter.this.dactivity, "No Image Found..", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                    dialog.dismiss();
                                    dialog.dismiss();
                                }
                            });
                            ((TextView) dialog.findViewById(R.id.delete_no)).setOnClickListener(new View.OnClickListener() {
                                public void onClick(View view) {
                                    dialog.dismiss();
                                }
                            });
                            dialog.show();
                        }
                    });
                    dialog.show();
                }
            });
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        Glide.with(this.dactivity).load(this.imagegallary.get(i)).into(viewHolder.imgIcon);
        System.gc();
        return view;
    }

    public Uri getImageUri(Context context, Bitmap bitmap) {
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, new ByteArrayOutputStream());
        return Uri.parse(MediaStore.Images.Media.insertImage(context.getContentResolver(), bitmap, this.dactivity.getString(R.string.app_name), (String) null));
    }
}
