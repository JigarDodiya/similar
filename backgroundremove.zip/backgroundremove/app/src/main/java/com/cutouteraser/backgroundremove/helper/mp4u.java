package com.cutouteraser.backgroundremove.helper;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.activity.SplashActivity;

import java.io.File;
import java.util.ArrayList;

@RequiresApi(api = Build.VERSION_CODES.Q)
public class mp4u {
    public static String Edit_Folder_name = SplashActivity.getContext().getString(R.string.app_name);
    public static ArrayList<String> IMAGEALLARY = new ArrayList<>();
    public static Bitmap backgroundBitmap;
    public static int[] bgList = {R.drawable.b0, R.drawable.b1, R.drawable.b2, R.drawable.b3, R.drawable.b4, R.drawable.b5, R.drawable.b6, R.drawable.b7, R.drawable.b8, R.drawable.b9, R.drawable.b10, R.drawable.b11, R.drawable.b12, R.drawable.b13, R.drawable.b14, R.drawable.b15, R.drawable.b16, R.drawable.b17, R.drawable.b18, R.drawable.b19, R.drawable.b20, R.drawable.b21, R.drawable.b22, R.drawable.b23, R.drawable.b24, R.drawable.b25, R.drawable.b26, R.drawable.b27, R.drawable.b28, R.drawable.b29, R.drawable.b30, R.drawable.b31, R.drawable.b32, R.drawable.b33, R.drawable.b34, R.drawable.b35, R.drawable.b36, R.drawable.b37, R.drawable.b38, R.drawable.b39, R.drawable.b40, R.drawable.b41, R.drawable.b42, R.drawable.b43, R.drawable.b44, R.drawable.b45, R.drawable.b46, R.drawable.b47, R.drawable.b48, R.drawable.b49, R.drawable.b50, R.drawable.b51, R.drawable.b52, R.drawable.b53, R.drawable.b54, R.drawable.b55, R.drawable.b56, R.drawable.b57, R.drawable.b58, R.drawable.b59, R.drawable.b60, R.drawable.b61, R.drawable.b62, R.drawable.b63, R.drawable.b64};
    public static File filenew;
    public static File newDir = new File(Environment.getExternalStorageDirectory() + "/" + SplashActivity.getContext().getString(R.string.app_name));
    public static String package_name = ("https://play.google.com/store/apps/details?id=" + SplashActivity.getContext().getOpPackageName());
    public static float screenHeight;
    public static float screenWidth;
    public static int[] stickerList = {R.drawable.big1, R.drawable.big2, R.drawable.big3, R.drawable.big4, R.drawable.big5, R.drawable.big6, R.drawable.big7, R.drawable.big8, R.drawable.big9, R.drawable.big10, R.drawable.big11, R.drawable.big12, R.drawable.big13, R.drawable.big14, R.drawable.big15, R.drawable.big16, R.drawable.big17, R.drawable.big18, R.drawable.big19, R.drawable.big20, R.drawable.big21, R.drawable.big22, R.drawable.big23, R.drawable.big24, R.drawable.big25, R.drawable.big26, R.drawable.big27, R.drawable.big28, R.drawable.big29, R.drawable.big30, R.drawable.big31, R.drawable.big32, R.drawable.big32, R.drawable.big34};

    public static int dpToPx(Context context, int i) {
        context.getResources();
        return (int) (((float) i) * Resources.getSystem().getDisplayMetrics().density);
    }

    public static float pxToDp(Context context, float f) {
        return f / (((float) context.getResources().getDisplayMetrics().densityDpi) / 160.0f);
    }

    @SuppressLint("WrongConstant")
    public static void rateApplication(Context context) {
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + context.getPackageName()));
        intent.addFlags(1476919296);
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException unused) {
            context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/details?id=" + context.getPackageName())));
        }
    }

    public static void moreApplication(Context context) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("market://search?q=pub:\"" + context.getString(R.string.more_link) + "\""));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public static void shareApplication(Context context) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
        intent.putExtra("android.intent.extra.TEXT", " Download this app on PlayStore :- https://play.google.com/store/apps/details?id=" + SplashActivity.getContext().getOpPackageName());
        context.startActivity(Intent.createChooser(intent, "Share With Your friends!"));
    }

    public static void listAllImages(File file) {
        File[] listFiles = file.listFiles();
        if (listFiles != null) {
            for (int length = listFiles.length - 1; length >= 0; length--) {
                String file2 = listFiles[length].toString();
                File file3 = new File(file2);
                Log.d("" + file3.length(), "" + file3.length());
                if (file3.length() <= 1024) {
                    Log.i("Invalid Image", "Delete Image");
                } else if (file3.toString().contains(".jpg") || file3.toString().contains(".png") || file3.toString().contains(".jpeg")) {
                    IMAGEALLARY.add(file2);
                }
                System.out.println(file2);
            }
            return;
        }
        System.out.println("Empty Folder");
    }

    public static boolean hasInternet(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED) {
            return true;
        }
        return false;
    }
}
