package com.cutouteraser.backgroundremove.activity;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.helper.MyApplication;

import java.net.MalformedURLException;
import java.net.URL;

public class SplashActivity extends AppCompatActivity {
    private static Context context = null;
    public static boolean locationInEU = false;
    public static boolean personalizedAds = false;
    public static boolean showAppOpen = false;
    /* access modifiers changed from: private */
    Handler handler;
    Runnable runnable;
    /* access modifiers changed from: private */
    public long secondsRemaining;

    public static Context getContext() {
        return context;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_splash);
        getWindow().setFlags(1024, 1024);
        context = getApplicationContext();
        continueIntent();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
        Handler handler2 = this.handler;
        if (handler2 != null) {
            handler2.removeCallbacks(this.runnable);
        }
    }

//    private void getConsentStatus() {
//        ConsentInformation.getInstance(this).requestConsentInfoUpdate(new String[]{getString(R.string.pub_id)}, new ConsentInfoUpdateListener() {
//            public void onConsentInfoUpdated(ConsentStatus consentStatus) {
//                if (ConsentInformation.getInstance(SplashActivity.this.getBaseContext()).isRequestLocationInEeaOrUnknown()) {
//                    int i = C08534.$SwitchMap$com$google$ads$consent$ConsentStatus[consentStatus.ordinal()];
//                    if (i == 1) {
//                        SplashActivity.this.displayConsentForm();
//                    } else if (i == 2) {
//                        SplashActivity.personalizedAds = true;
//                        SplashActivity.locationInEU = true;
//                        SplashActivity.this.startTimer();
//                    } else if (i == 3) {
//                        SplashActivity.personalizedAds = false;
//                        SplashActivity.locationInEU = true;
//                        SplashActivity.this.startTimer();
//                    }
//                } else {
//                    SplashActivity.personalizedAds = true;
//                    SplashActivity.locationInEU = false;
//                    SplashActivity.this.startTimer();
//                }
//            }
//
//            public void onFailedToUpdateConsentInfo(String str) {
//                SplashActivity.this.startTimer();
//            }
//        });
//    }

    /* renamed from: com.cutouteraser.backgroundremove.activity.SplashActivity$4 */
//    static /* synthetic */ class C08534 {
//        static final /* synthetic */ int[] $SwitchMap$com$google$ads$consent$ConsentStatus;
//
//        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
//        /* JADX WARNING: Failed to process nested try/catch */
//        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
//        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
//        static {
//            /*
//                com.google.ads.consent.ConsentStatus[] r0 = com.google.ads.consent.ConsentStatus.values()
//                int r0 = r0.length
//                int[] r0 = new int[r0]
//                $SwitchMap$com$google$ads$consent$ConsentStatus = r0
//                com.google.ads.consent.ConsentStatus r1 = com.google.ads.consent.ConsentStatus.UNKNOWN     // Catch:{ NoSuchFieldError -> 0x0012 }
//                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
//                r2 = 1
//                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
//            L_0x0012:
//                int[] r0 = $SwitchMap$com$google$ads$consent$ConsentStatus     // Catch:{ NoSuchFieldError -> 0x001d }
//                com.google.ads.consent.ConsentStatus r1 = com.google.ads.consent.ConsentStatus.PERSONALIZED     // Catch:{ NoSuchFieldError -> 0x001d }
//                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
//                r2 = 2
//                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
//            L_0x001d:
//                int[] r0 = $SwitchMap$com$google$ads$consent$ConsentStatus     // Catch:{ NoSuchFieldError -> 0x0028 }
//                com.google.ads.consent.ConsentStatus r1 = com.google.ads.consent.ConsentStatus.NON_PERSONALIZED     // Catch:{ NoSuchFieldError -> 0x0028 }
//                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
//                r2 = 3
//                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
//            L_0x0028:
//                return
//            */
//            throw new UnsupportedOperationException("Method not decompiled: com.cutouteraser.backgroundremove.activity.SplashActivity.C08534.<clinit>():void");
//        }
//    }

    /* access modifiers changed from: private */
//    public void displayConsentForm() {
//        URL url;
//        try {
//            url = new URL(getString(R.string.policy_url));
//        } catch (MalformedURLException unused) {
//            url = null;
//        }
//        ConsentForm build = new ConsentForm.Builder(this, url).withListener(new ConsentFormListener() {
//            public void onConsentFormError(String str) {
//            }
//
//            public void onConsentFormOpened() {
//            }
//
//            public void onConsentFormLoaded() {
//                SplashActivity.this.form.show();
//            }
//
//            public void onConsentFormClosed(ConsentStatus consentStatus, Boolean bool) {
//                if (consentStatus.equals(ConsentStatus.PERSONALIZED)) {
//                    SplashActivity.personalizedAds = true;
//                    SplashActivity.locationInEU = true;
//                    SplashActivity.this.startTimer();
//                    return;
//                }
//                SplashActivity.personalizedAds = false;
//                SplashActivity.locationInEU = true;
//                SplashActivity.this.startTimer();
//            }
//        }).withPersonalizedAdsOption().withNonPersonalizedAdsOption().build();
//        this.form = build;
//        build.load();
//    }

    /* access modifiers changed from: private */
    public void startTimer() {
        new CountDownTimer(5000, 1000) {
            public void onTick(long j) {
                long unused = SplashActivity.this.secondsRemaining = (j / 1000) + 1;
            }

            public void onFinish() {
                long unused = SplashActivity.this.secondsRemaining = 0;
                Application application = SplashActivity.this.getApplication();
                if (!(application instanceof MyApplication)) {
                    SplashActivity.this.continueIntent();
                } else if (!SplashActivity.showAppOpen) {
                    ((MyApplication) application).showAdIfAvailable(SplashActivity.this, new MyApplication.OnShowAdCompleteListener() {
                        public void onShowAdComplete() {
                            SplashActivity.this.continueIntent();
                        }
                    });
                } else {
                    SplashActivity.this.continueIntent();
                }
            }
        }.start();
    }

    /* access modifiers changed from: private */
    public void continueIntent() {
        showAppOpen = true;
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }
}
