package com.cutouteraser.backgroundremove.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.adapter.AssetsGrid;
import com.cutouteraser.backgroundremove.adapter.ColorListAdapter;
import com.cutouteraser.backgroundremove.helper.AutoFitEditText;
import com.cutouteraser.backgroundremove.helper.HorizontalListView;
import com.cutouteraser.backgroundremove.helper.ImageUtils;
import com.cutouteraser.backgroundremove.helper.TextInfo;

import java.io.IOException;

import yuku.ambilwarna.AmbilWarnaDialog;

public class TextActivity extends Activity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {
    public static Bundle bundle;
    public static String[] pallete = {"#4182b6", "#4149b6", "#7641b6", "#b741a7", "#c54657", "#d1694a", "#24352a", "#b8c847", "#67bb43", "#41b691", "#293b2f", "#1c0101", "#420a09", "#b4794b", "#4b86b4", "#93b6d2", "#72aa52", "#67aa59", "#fa7916", "#16a1fa", "#165efa", "#1697fa"};
    public static int[] pallete1 = {R.color.color1, R.color.color2, R.color.color3, R.color.color4, R.color.color5, R.color.color6, R.color.color7, R.color.color8, R.color.color9, R.color.color10, R.color.color11, R.color.color12, R.color.color13, R.color.color14, R.color.color15, R.color.color16, R.color.color17, R.color.color18, R.color.color19, R.color.color20, R.color.color21, R.color.color22};
    public static TextInfo textInfo;
    /* access modifiers changed from: private */
    public AutoFitEditText autoFitEditText;
    private int bgAlpha = 255;
    /* access modifiers changed from: private */
    public int bgColor = 0;
    /* access modifiers changed from: private */
    public String bgDrawable = "0";
    private RelativeLayout bg_rel;
    private ImageButton btn_back;
    private ImageButton btn_ok;
    View clickedView;
    private RelativeLayout color_rel;
    boolean firsttime = true;
    String[] font;
    /* access modifiers changed from: private */
    public String fontName = "";
    private RelativeLayout font_grid_rel;
    private GridView font_gridview;
    String hex = "";
    String hex1 = "";
    /* access modifiers changed from: private */
    public TextView hint_txt;
    private ImageView ic_kb;
    private InputMethodManager imm;
    private boolean isKbOpened = true;
    /* access modifiers changed from: private */
    public ImageView lay_back_img;
    /* access modifiers changed from: private */
    public RelativeLayout lay_below;
    private RelativeLayout lay_txtbg;
    private RelativeLayout lay_txtcolor;
    private RelativeLayout lay_txtfont;
    private RelativeLayout lay_txtshadow;
    /* access modifiers changed from: private */
    public RelativeLayout laykeyboard;
    int processValue = 200;
    private SeekBar seekBar;
    private SeekBar seekBar2;
    private SeekBar seekBar3;
    /* access modifiers changed from: private */
    public int shadowColor = Color.parseColor("#7641b6");
    private int shadowProg = 5;
    private RelativeLayout shadow_rel;
    private int tAlpha = 200;
    /* access modifiers changed from: private */
    public int tColor = Color.parseColor("#000000");
    private String text = "";
    private Typeface ttf;
    int value = 0;
    int value2 = 0;

    public void onStartTrackingTouch(SeekBar seekBar4) {
    }

    public void onStopTrackingTouch(SeekBar seekBar4) {
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle2) {
        super.onCreate(bundle2);
        setContentView(R.layout.activity_text);
        getWindow().setSoftInputMode(32);
        this.imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        initUI();
        initViewPager();
        this.lay_back_img.post(new Runnable() {
            public void run() {
                TextActivity.this.initUIData();
                TextActivity.this.laykeyboard.performClick();
            }
        });
        ((TextView) findViewById(R.id.headertext)).setTypeface(this.ttf);
        this.autoFitEditText.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            public void onGlobalLayout() {
                TextActivity textActivity = TextActivity.this;
                if (textActivity.isKeyboardShown(textActivity.autoFitEditText.getRootView())) {
                    TextActivity.this.lay_below.setVisibility(View.INVISIBLE);
                    TextActivity.this.setSelected(R.id.laykeyboard);
                    TextActivity.this.firsttime = false;
                } else if (!TextActivity.this.firsttime) {
                    TextActivity textActivity2 = TextActivity.this;
                    textActivity2.setSelected(textActivity2.clickedView.getId());
                    TextActivity.this.clickedView.performClick();
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public boolean isKeyboardShown(View view) {
        Rect rect = new Rect();
        view.getWindowVisibleDisplayFrame(rect);
        return ((float) (view.getBottom() - rect.bottom)) > view.getResources().getDisplayMetrics().density * 128.0f;
    }

    private void initUI() {
        this.autoFitEditText = (AutoFitEditText) findViewById(R.id.auto_fit_edit_text);
        this.btn_back = (ImageButton) findViewById(R.id.btn_back);
        this.btn_ok = (ImageButton) findViewById(R.id.btn_ok);
        this.hint_txt = (TextView) findViewById(R.id.hint_txt);
        this.laykeyboard = (RelativeLayout) findViewById(R.id.laykeyboard);
        this.lay_txtfont = (RelativeLayout) findViewById(R.id.lay_txtfont);
        this.lay_txtcolor = (RelativeLayout) findViewById(R.id.lay_txtcolor);
        this.lay_txtshadow = (RelativeLayout) findViewById(R.id.lay_txtshadow);
        this.lay_txtbg = (RelativeLayout) findViewById(R.id.lay_txtbg);
        this.clickedView = this.lay_txtfont;
        this.lay_below = (RelativeLayout) findViewById(R.id.lay_below);
        this.font_grid_rel = (RelativeLayout) findViewById(R.id.font_grid_rel);
        this.color_rel = (RelativeLayout) findViewById(R.id.color_rel);
        this.shadow_rel = (RelativeLayout) findViewById(R.id.shadow_rel);
        this.bg_rel = (RelativeLayout) findViewById(R.id.bg_rel);
        ImageView imageView = (ImageView) findViewById(R.id.ic_kb);
        this.ic_kb = imageView;
        imageView.setOnClickListener(this);
        this.seekBar = (SeekBar) findViewById(R.id.seekBar1);
        this.seekBar2 = (SeekBar) findViewById(R.id.seekBar2);
        this.seekBar3 = (SeekBar) findViewById(R.id.seekBar3);
        this.lay_txtfont.setOnClickListener(this);
        this.lay_txtcolor.setOnClickListener(this);
        this.lay_txtshadow.setOnClickListener(this);
        this.lay_txtbg.setOnClickListener(this);
        this.seekBar.setOnSeekBarChangeListener(this);
        this.seekBar2.setOnSeekBarChangeListener(this);
        this.seekBar3.setOnSeekBarChangeListener(this);
        this.seekBar2.setProgress(5);
        this.lay_back_img = (ImageView) findViewById(R.id.lay_back_txt);
        this.autoFitEditText.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.length() == 0) {
                    TextActivity.this.hint_txt.setVisibility(View.VISIBLE);
                } else {
                    TextActivity.this.hint_txt.setVisibility(View.GONE);
                }
            }
        });
        this.btn_back.setOnClickListener(this);
        this.btn_ok.setOnClickListener(this);
        this.laykeyboard.setOnClickListener(this);
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(this.autoFitEditText, 0);
        this.font_gridview = (GridView) findViewById(R.id.font_gridview);
        HorizontalListView horizontalListView = (HorizontalListView) findViewById(R.id.color_listview1);
        final ColorListAdapter colorListAdapter = new ColorListAdapter(this, pallete);
        horizontalListView.setAdapter((ListAdapter) colorListAdapter);
        horizontalListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                TextActivity.this.updateColor(((Integer) colorListAdapter.getItem(i)).intValue(), 1);
            }
        });
        HorizontalListView horizontalListView2 = (HorizontalListView) findViewById(R.id.color_listview2);
        final ColorListAdapter colorListAdapter2 = new ColorListAdapter(this, pallete);
        horizontalListView2.setAdapter((ListAdapter) colorListAdapter2);
        horizontalListView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                TextActivity.this.updateColor(((Integer) colorListAdapter2.getItem(i)).intValue(), 2);
            }
        });
        findViewById(R.id.txt_bg_none).setOnClickListener(this);
        findViewById(R.id.color_picker3).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                TextActivity textActivity = TextActivity.this;
                new AmbilWarnaDialog(textActivity, textActivity.bgColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    public void onCancel(AmbilWarnaDialog ambilWarnaDialog) {
                    }

                    public void onOk(AmbilWarnaDialog ambilWarnaDialog, int i) {
                        String unused = TextActivity.this.bgDrawable = "0";
                        int unused2 = TextActivity.this.bgColor = i;
                        TextActivity.this.lay_back_img.setImageBitmap((Bitmap) null);
                        TextActivity.this.lay_back_img.setBackgroundColor(TextActivity.this.bgColor);
                        TextActivity.this.lay_back_img.setVisibility(View.VISIBLE);
                    }
                }).show();
            }
        });
        findViewById(R.id.color_picker2).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                TextActivity textActivity = TextActivity.this;
                new AmbilWarnaDialog(textActivity, textActivity.shadowColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    public void onCancel(AmbilWarnaDialog ambilWarnaDialog) {
                    }

                    public void onOk(AmbilWarnaDialog ambilWarnaDialog, int i) {
                        TextActivity.this.updateColor(i, 2);
                    }
                }).show();
            }
        });
        findViewById(R.id.color_picker1).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                TextActivity textActivity = TextActivity.this;
                new AmbilWarnaDialog(textActivity, textActivity.tColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
                    public void onCancel(AmbilWarnaDialog ambilWarnaDialog) {
                    }

                    public void onOk(AmbilWarnaDialog ambilWarnaDialog, int i) {
                        TextActivity.this.updateColor(i, 1);
                    }
                }).show();
            }
        });
        HorizontalListView horizontalListView3 = (HorizontalListView) findViewById(R.id.color_listview3);
        final ColorListAdapter colorListAdapter3 = new ColorListAdapter(this, pallete);
        horizontalListView3.setAdapter((ListAdapter) colorListAdapter3);
        horizontalListView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                String unused = TextActivity.this.bgDrawable = "0";
                int unused2 = TextActivity.this.bgColor = ((Integer) colorListAdapter3.getItem(i)).intValue();
                TextActivity.this.lay_back_img.setImageBitmap((Bitmap) null);
                TextActivity.this.lay_back_img.setBackgroundColor(TextActivity.this.bgColor);
                TextActivity.this.lay_back_img.setVisibility(View.VISIBLE);
            }
        });
    }

    private void initViewPager() {
        try {
            this.font = getAssets().list("fonts");
            for (int i = 0; i < this.font.length; i++) {
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        final AssetsGrid assetsGrid = new AssetsGrid(this, this.font);
        GridView gridView = (GridView) findViewById(R.id.font_gridview);
        this.font_gridview = gridView;
        gridView.setAdapter(assetsGrid);
        this.font_gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                String unused = TextActivity.this.fontName = (String) assetsGrid.getItem(i);
                Editable text = TextActivity.this.autoFitEditText.getText();
                AutoFitEditText access$200 = TextActivity.this.autoFitEditText;
                AssetManager assets = TextActivity.this.getAssets();
                access$200.setTypeface(Typeface.createFromAsset(assets, "fonts/" + TextActivity.this.fontName));
                TextActivity.this.autoFitEditText.setText(text);
                TextActivity.this.autoFitEditText.invalidate();
            }
        });
    }

    /* access modifiers changed from: private */
    public void initUIData() {
        Bundle extras = getIntent().getExtras();
        bundle = extras;
        if (extras != null) {
            this.text = extras.getString("text", "");
            this.fontName = bundle.getString("fontName", "");
            this.tColor = bundle.getInt("tColor", Color.parseColor("#4149b6"));
            this.tAlpha = bundle.getInt("tAlpha", 200);
            this.shadowColor = bundle.getInt("shadowColor", Color.parseColor("#7641b6"));
            this.shadowProg = bundle.getInt("shadowProg", 5);
            this.bgDrawable = bundle.getString("bgDrawable", "0");
            this.bgColor = bundle.getInt("bgColor", 0);
            this.bgAlpha = bundle.getInt("bgAlpha", 255);
            this.autoFitEditText.setText(this.text);
            this.seekBar.setProgress(this.tAlpha);
            this.seekBar2.setProgress(this.shadowProg);
            updateColor(this.tColor, 1);
            updateColor(this.shadowColor, 2);
            if (!this.bgDrawable.equals("0")) {
                this.lay_back_img.setImageBitmap(getTiledBitmap(this, getResources().getIdentifier(this.bgDrawable, "drawable", getPackageName()), this.autoFitEditText.getWidth(), this.autoFitEditText.getHeight()));
                this.lay_back_img.setVisibility(View.VISIBLE);
                this.lay_back_img.postInvalidate();
                this.lay_back_img.requestLayout();
            }
            int i = this.bgColor;
            if (i != 0) {
                this.lay_back_img.setBackgroundColor(i);
                this.lay_back_img.setVisibility(View.VISIBLE);
            }
            this.seekBar3.setProgress(this.bgAlpha);
            try {
                this.autoFitEditText.setTypeface(Typeface.createFromAsset(getAssets(), this.fontName));
            } catch (Exception unused) {
            }
        }
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                finish();
                return;
            case R.id.btn_ok:
                if (this.autoFitEditText.getText().toString().trim().length() > 0) {
                    Intent intent = new Intent();
                    intent.putExtras(getInfoBundle());
                    setResult(-1, intent);
                    finish();
                    return;
                }
                return;
            case R.id.ic_kb:
                this.isKbOpened = true;
                this.firsttime = true;
                setSelected(view.getId());
                this.imm.showSoftInput(this.autoFitEditText, 0);
                return;
            case R.id.lay_txtbg:
                setSelected(view.getId());
                this.clickedView = view;
                this.font_grid_rel.setVisibility(View.GONE);
                this.color_rel.setVisibility(View.GONE);
                this.shadow_rel.setVisibility(View.GONE);
                this.bg_rel.setVisibility(View.VISIBLE);
                this.lay_below.setVisibility(View.VISIBLE);
                this.imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                return;
            case R.id.lay_txtcolor:
                setSelected(view.getId());
                this.clickedView = view;
                this.font_grid_rel.setVisibility(View.GONE);
                this.color_rel.setVisibility(View.VISIBLE);
                this.shadow_rel.setVisibility(View.GONE);
                this.bg_rel.setVisibility(View.GONE);
                this.lay_below.setVisibility(View.VISIBLE);
                this.imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                return;
            case R.id.lay_txtfont:
                setSelected(view.getId());
                this.clickedView = view;
                this.font_grid_rel.setVisibility(View.VISIBLE);
                this.color_rel.setVisibility(View.GONE);
                this.shadow_rel.setVisibility(View.GONE);
                this.bg_rel.setVisibility(View.GONE);
                this.lay_below.setVisibility(View.VISIBLE);
                this.imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                return;
            case R.id.lay_txtshadow:
                setSelected(view.getId());
                this.clickedView = view;
                this.font_grid_rel.setVisibility(View.GONE);
                this.color_rel.setVisibility(View.GONE);
                this.shadow_rel.setVisibility(View.VISIBLE);
                this.bg_rel.setVisibility(View.GONE);
                this.lay_below.setVisibility(View.VISIBLE);
                this.imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
                return;
            case R.id.txt_bg_none:
                this.lay_back_img.setVisibility(View.GONE);
                this.bgDrawable = "0";
                this.bgColor = 0;
                return;
            default:
                return;
        }
    }

    public void onProgressChanged(SeekBar seekBar4, int i, boolean z) {
        this.processValue = i;
        this.value = i;
        int id = seekBar4.getId();
        if (id == R.id.seekBar1) {
            this.autoFitEditText.setAlpha(((float) seekBar4.getProgress()) / ((float) seekBar4.getMax()));
        } else if (id == R.id.seekBar2) {
            if (this.hex1.equals("")) {
                this.autoFitEditText.setShadowLayer((float) i, 0.0f, 0.0f, Color.parseColor("#fdab52"));
                return;
            }
            this.autoFitEditText.setShadowLayer((float) i, 0.0f, 0.0f, Color.parseColor("#" + this.hex1));
        } else if (id == R.id.seekBar3) {
            this.lay_back_img.setAlpha(((float) i) / 255.0f);
        }
    }

    private Bundle getInfoBundle() {
        if (bundle == null) {
            bundle = new Bundle();
        }
        String replace = this.autoFitEditText.getText().toString().trim().replace("\n", " ");
        this.text = replace;
        bundle.putString("text", replace);
        bundle.putString("fontName", this.fontName);
        bundle.putInt("tColor", this.tColor);
        bundle.putInt("tAlpha", this.seekBar.getProgress());
        bundle.putInt("shadowColor", this.shadowColor);
        bundle.putInt("shadowProg", this.seekBar2.getProgress());
        bundle.putString("bgDrawable", this.bgDrawable);
        bundle.putInt("bgColor", this.bgColor);
        bundle.putInt("bgAlpha", this.seekBar3.getProgress());
        try {
            TextInfo textInfo2 = new TextInfo();
            textInfo = textInfo2;
            textInfo2.setPOS_X((float) bundle.getInt("X", 0));
            textInfo.setPOS_Y((float) bundle.getInt("Y", 0));
            textInfo.setWIDTH(bundle.getInt("wi", ImageUtils.dpToPx(this, 200)));
            textInfo.setHEIGHT(bundle.getInt("he", ImageUtils.dpToPx(this, 200)));
            textInfo.setTEXT(bundle.getString("text", ""));
            textInfo.setFONT_NAME(bundle.getString("fontName", ""));
            textInfo.setTEXT_COLOR(bundle.getInt("tColor", Color.parseColor("#4149b6")));
            textInfo.setTEXT_ALPHA(bundle.getInt("tAlpha", 100));
            textInfo.setSHADOW_COLOR(bundle.getInt("shadowColor", Color.parseColor("#7641b6")));
            textInfo.setSHADOW_PROG(bundle.getInt("shadowProg", 5));
            textInfo.setBG_COLOR(bundle.getInt("bgColor", 0));
            textInfo.setBG_DRAWABLE(bundle.getString("bgDrawable", "0"));
            textInfo.setBG_ALPHA(bundle.getInt("bgAlpha", 255));
            textInfo.setROTATION(bundle.getFloat("rotation", 0.0f));
        } catch (Exception unused) {
        }
        return bundle;
    }

    /* access modifiers changed from: private */
    public void updateColor(int i, int i2) {
        if (i2 == 1) {
            this.tColor = i;
            this.hex = Integer.toHexString(i);
            AutoFitEditText autoFitEditText2 = this.autoFitEditText;
            autoFitEditText2.setTextColor(Color.parseColor("#" + this.hex));
        } else if (i2 == 2) {
            this.shadowColor = i;
            int progress = this.seekBar2.getProgress();
            this.hex1 = Integer.toHexString(i);
            this.autoFitEditText.setShadowLayer((float) progress, 0.0f, 0.0f, Color.parseColor("#" + this.hex1));
        }
    }

    public void setSelected(int i) {
        if (i == R.id.laykeyboard) {
            this.laykeyboard.getChildAt(0).setBackgroundResource(R.drawable.textlib_kb1);
            this.lay_txtfont.getChildAt(0).setBackgroundResource(R.drawable.textlib_text);
            this.lay_txtcolor.getChildAt(0).setBackgroundResource(R.drawable.textlib_tcolor);
            this.lay_txtshadow.getChildAt(0).setBackgroundResource(R.drawable.textlib_tshadow);
            this.lay_txtbg.getChildAt(0).setBackgroundResource(R.drawable.textlib_tbg);
        }
        if (i == R.id.lay_txtfont) {
            this.laykeyboard.getChildAt(0).setBackgroundResource(R.drawable.textlib_kb);
            this.lay_txtfont.getChildAt(0).setBackgroundResource(R.drawable.textlib_text1);
            this.lay_txtcolor.getChildAt(0).setBackgroundResource(R.drawable.textlib_tcolor);
            this.lay_txtshadow.getChildAt(0).setBackgroundResource(R.drawable.textlib_tshadow);
            this.lay_txtbg.getChildAt(0).setBackgroundResource(R.drawable.textlib_tbg);
        }
        if (i == R.id.lay_txtcolor) {
            this.laykeyboard.getChildAt(0).setBackgroundResource(R.drawable.textlib_kb);
            this.lay_txtfont.getChildAt(0).setBackgroundResource(R.drawable.textlib_text);
            this.lay_txtcolor.getChildAt(0).setBackgroundResource(R.drawable.textlib_tcolor1);
            this.lay_txtshadow.getChildAt(0).setBackgroundResource(R.drawable.textlib_tshadow);
            this.lay_txtbg.getChildAt(0).setBackgroundResource(R.drawable.textlib_tbg);
        }
        if (i == R.id.lay_txtshadow) {
            this.laykeyboard.getChildAt(0).setBackgroundResource(R.drawable.textlib_kb);
            this.lay_txtfont.getChildAt(0).setBackgroundResource(R.drawable.textlib_text);
            this.lay_txtcolor.getChildAt(0).setBackgroundResource(R.drawable.textlib_tcolor);
            this.lay_txtshadow.getChildAt(0).setBackgroundResource(R.drawable.textlib_tshadow1);
            this.lay_txtbg.getChildAt(0).setBackgroundResource(R.drawable.textlib_tbg);
        }
        if (i == R.id.lay_txtbg) {
            this.laykeyboard.getChildAt(0).setBackgroundResource(R.drawable.textlib_kb);
            this.lay_txtfont.getChildAt(0).setBackgroundResource(R.drawable.textlib_text);
            this.lay_txtcolor.getChildAt(0).setBackgroundResource(R.drawable.textlib_tcolor);
            this.lay_txtshadow.getChildAt(0).setBackgroundResource(R.drawable.textlib_tshadow);
            this.lay_txtbg.getChildAt(0).setBackgroundResource(R.drawable.textlib_tbg1);
        }
    }

    private Bitmap getTiledBitmap(Context context, int i, int i2, int i3) {
        Rect rect = new Rect(0, 0, i2, i3);
        Paint paint = new Paint();
        paint.setShader(new BitmapShader(BitmapFactory.decodeResource(context.getResources(), i, new BitmapFactory.Options()), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        Bitmap createBitmap = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
        new Canvas(createBitmap).drawRect(rect, paint);
        return createBitmap;
    }
}
