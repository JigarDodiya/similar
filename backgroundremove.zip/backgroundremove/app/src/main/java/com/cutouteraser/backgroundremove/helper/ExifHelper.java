package com.cutouteraser.backgroundremove.helper;

import androidx.exifinterface.media.ExifInterface;

import java.io.IOException;
import java.util.HashMap;

public class ExifHelper {
    public static final String[] EXIF_KEYS = {ExifInterface.TAG_F_NUMBER, ExifInterface.TAG_DATETIME, ExifInterface.TAG_EXPOSURE_TIME, ExifInterface.TAG_FLASH, ExifInterface.TAG_FOCAL_LENGTH, ExifInterface.TAG_GPS_ALTITUDE, ExifInterface.TAG_GPS_ALTITUDE_REF, ExifInterface.TAG_GPS_DATESTAMP, ExifInterface.TAG_GPS_LATITUDE, ExifInterface.TAG_GPS_LATITUDE_REF, ExifInterface.TAG_GPS_LONGITUDE, ExifInterface.TAG_GPS_LONGITUDE_REF, ExifInterface.TAG_GPS_PROCESSING_METHOD, ExifInterface.TAG_GPS_TIMESTAMP, ExifInterface.TAG_IMAGE_LENGTH, ExifInterface.TAG_IMAGE_WIDTH, ExifInterface.TAG_ISO_SPEED_RATINGS, ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_ORIENTATION, ExifInterface.TAG_WHITE_BALANCE};
    HashMap<String, String> f10001a;

    public ExifHelper() {
        reset();
    }

    public String getAttribute(String str) {
        return this.f10001a.get(str);
    }

    public void readExif(String str) throws IOException {
        android.media.ExifInterface exifInterface = new android.media.ExifInterface(str);
        for (String str2 : EXIF_KEYS) {
            String attribute = exifInterface.getAttribute(str2);
            if (attribute != null) {
                this.f10001a.put(str2, attribute);
            }
        }
    }

    public void reset() {
        this.f10001a = new HashMap<>();
    }

    public void setAttribute(String str, String str2) {
        this.f10001a.put(str, str2);
    }

    public void writeExif(String str) throws IOException {
        android.media.ExifInterface exifInterface = new android.media.ExifInterface(str);
        for (String next : this.f10001a.keySet()) {
            String str2 = this.f10001a.get(next);
            if (!(next == null || str2 == null)) {
                exifInterface.setAttribute(next, str2);
            }
        }
        exifInterface.saveAttributes();
    }
}
