package com.cutouteraser.backgroundremove.helper;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class ItemOffsetDecoration extends RecyclerView.ItemDecoration {
    private int mItemOffset;

    public ItemOffsetDecoration(int i) {
        this.mItemOffset = i;
    }

    public ItemOffsetDecoration(Context context, int i) {
        this(context.getResources().getDimensionPixelSize(i));
    }

    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        super.getItemOffsets(rect, view, recyclerView, state);
        rect.bottom = this.mItemOffset;
        if (recyclerView.getChildAdapterPosition(view) % 2 == 0) {
            rect.right = this.mItemOffset;
        } else {
            rect.left = this.mItemOffset;
        }
    }
}
