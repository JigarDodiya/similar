package com.cutouteraser.backgroundremove.activity;

import android.view.View;

public final /* synthetic */ class SettingsActivity$$ExternalSyntheticLambda1 implements View.OnClickListener {
    public final /* synthetic */ SettingsActivity f$0;

    public /* synthetic */ SettingsActivity$$ExternalSyntheticLambda1(SettingsActivity settingsActivity) {
        this.f$0 = settingsActivity;
    }

    public final void onClick(View view) {
        this.f$0.mo12865xef2b443f(view);
    }
}
