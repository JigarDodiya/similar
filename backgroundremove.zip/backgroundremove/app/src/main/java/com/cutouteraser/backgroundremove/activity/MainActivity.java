package com.cutouteraser.backgroundremove.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.helper.FileUtils;
import com.cutouteraser.backgroundremove.helper.mp4u;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.util.List;
@SuppressLint("MissingInflatedId")
public class MainActivity extends Activity {
    private static final int SELECT_PICTURE_FROM_CAMERA = 1;
    /* access modifiers changed from: private */
    Uri photoURI;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(1024, 1024);
        permissionCheck();
        findViewById(R.id.imageViewSettings).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        findViewById(R.id.createNew).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                createNewBackground();
            }
        });
        findViewById(R.id.myCreations).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.permissionCheck();
                MainActivity.this.startActivity(new Intent(MainActivity.this, MyCreationActivity.class));
            }
        });
        findViewById(R.id.rate).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mp4u.rateApplication(MainActivity.this);
            }
        });
    }

    /* access modifiers changed from: private */
    public void createNewBackground() {
        permissionCheck();
        Intent intent = new Intent("android.intent.action.PICK");
        intent.setType(FileUtils.MIME_TYPE_IMAGE);
        startActivityForResult(intent, 11111);
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i != 1) {
            if (i == 11111 && i2 == -1) {
                try {
                    for (String s : new String[]{"_data"}) {

                    }

                    String path = FileUtils.getPath(this, intent.getData());
                    Intent intent2 = new Intent(this, BGRemoverActivity.class);
                    intent2.putExtra("image_path", path);
                    startActivity(intent2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (i2 == -1) {
            Cursor query = getContentResolver().query(this.photoURI, new String[]{"_id", "orientation", "_data"}, (String) null, (String[]) null, (String) null);
            query.moveToFirst();
            String string = query.getString(query.getColumnIndexOrThrow("_data"));
            Intent intent3 = new Intent(this, BGRemoverActivity.class);
            intent3.putExtra("image_path", string);
            startActivity(intent3);
        }
    }

    public void permissionCheck() {
        Dexter.withActivity(this).withPermissions("android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE").withListener(new MultiplePermissionsListener() {
            public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                multiplePermissionsReport.areAllPermissionsGranted();
                if (multiplePermissionsReport.isAnyPermissionPermanentlyDenied()) {
                    MainActivity.this.showSettingsDialog();
                }
            }

            public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).withErrorListener(new PermissionRequestErrorListener() {
            public void onError(DexterError dexterError) {
                Toast.makeText(MainActivity.this.getApplicationContext(), "Error occurred! ", Toast.LENGTH_SHORT).show();
            }
        }).onSameThread().check();
    }

    /* access modifiers changed from: private */
    public void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle((CharSequence) "Need Permissions");
        builder.setMessage((CharSequence) "This app needs permission to use this feature. You can grant them in app settings.");
        builder.setPositiveButton((CharSequence) "GOTO SETTINGS", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
                MainActivity.this.openSettings();
            }
        });
        builder.setNegativeButton((CharSequence) "Cancel", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();
    }

    /* access modifiers changed from: private */
    public void openSettings() {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
        intent.setData(Uri.fromParts("package", getPackageName(), (String) null));
        startActivityForResult(intent, 101);
    }

    private void exitto() {
        try {
            new AlertDialog.Builder(this).setTitle((CharSequence) "Exit !").setMessage((CharSequence) "Do you really want to Exit?").setCancelable(false).setPositiveButton((CharSequence) "Yes", (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent("android.intent.action.MAIN");
                    intent.addCategory("android.intent.category.HOME");
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    MainActivity.this.startActivity(intent);
                }
            }).setNegativeButton((CharSequence) "No", (DialogInterface.OnClickListener) null).show();
        } catch (Exception unused) {
        }
    }

//    public void loadAd() {
//        AdRequest adRequest;
//        if (SplashActivity.personalizedAds) {
//            adRequest = new AdRequest.Builder().build();
//        } else {
//            Bundle bundle = new Bundle();
//            bundle.putString("npa", "1");
//            adRequest = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, bundle).build();
//        }
//        InterstitialAd.load(this, getResources().getString(R.string.interstitial_google), adRequest, new InterstitialAdLoadCallback() {
//            public void onAdLoaded(InterstitialAd interstitialAd) {
//                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
//                interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
//                    public void onAdDismissedFullScreenContent() {
//                        InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
//                        MainActivity.this.createNewBackground();
//                    }
//
//                    public void onAdFailedToShowFullScreenContent(AdError adError) {
//                        InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
//                    }
//
//                    public void onAdShowedFullScreenContent() {
//                        Log.d("TAG", "The ad was shown.");
//                    }
//                });
//            }
//
//            public void onAdFailedToLoad(LoadAdError loadAdError) {
//                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
//            }
//        });
//    }

//    public void showInterstitial() {
//        InterstitialAd interstitialAd = this.mInterstitialAd;
//        if (interstitialAd != null) {
//            interstitialAd.show(this);
//        } else {
//            createNewBackground();
//        }
//    }

    public void onBackPressed() {
        exitto();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}
