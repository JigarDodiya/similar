package com.cutouteraser.backgroundremove.helper;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class LastVersionManager {
    static Context last_context = null;
    static String name = "pref_lastversion";

    public static void addImageToMyPhotos(Context context, String str) {
        last_context = context;
        ArrayList<String> arrayList = getArrayList();
        if (arrayList == null) {
            arrayList = new ArrayList<>();
        }
        arrayList.add(str);
        saveArrayList(arrayList);
    }

    public static ArrayList<String> getImageListMyPhotos(Context context) {
        last_context = context;
        ArrayList<String> arrayList = getArrayList();
        return arrayList == null ? new ArrayList<>() : arrayList;
    }

    public static void removeImageFromMyPhotos(Context context, String str) {
        last_context = context;
        ArrayList<String> arrayList = getArrayList();
        if (arrayList == null) {
            arrayList = new ArrayList<>();
        }
        arrayList.remove(str);
        saveArrayList(arrayList);
    }

    private static void saveArrayList(ArrayList<String> arrayList) {
        SharedPreferences.Editor edit = PreferenceManager.getDefaultSharedPreferences(last_context).edit();
        edit.putString(name, new Gson().toJson((Object) arrayList));
        edit.apply();
    }

    private static ArrayList<String> getArrayList() {
        return (ArrayList) new Gson().fromJson(PreferenceManager.getDefaultSharedPreferences(last_context).getString(name, (String) null), new TypeToken<ArrayList<String>>() {
        }.getType());
    }
}
