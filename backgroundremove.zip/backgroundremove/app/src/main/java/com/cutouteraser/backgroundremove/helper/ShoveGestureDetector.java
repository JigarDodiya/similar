package com.cutouteraser.backgroundremove.helper;

import android.content.Context;
import android.view.MotionEvent;

public class ShoveGestureDetector extends TwoFingerGestureDetector {
    private float mCurrAverageY;
    private final OnShoveGestureListener mListener;
    private float mPrevAverageY;
    private boolean mSloppyGesture;

    public interface OnShoveGestureListener {
        boolean onShove(ShoveGestureDetector shoveGestureDetector);

        boolean onShoveBegin(ShoveGestureDetector shoveGestureDetector);

        void onShoveEnd(ShoveGestureDetector shoveGestureDetector);
    }

    public static class SimpleOnShoveGestureListener implements OnShoveGestureListener {
        public boolean onShove(ShoveGestureDetector shoveGestureDetector) {
            return false;
        }

        public boolean onShoveBegin(ShoveGestureDetector shoveGestureDetector) {
            return true;
        }

        public void onShoveEnd(ShoveGestureDetector shoveGestureDetector) {
        }
    }

    public ShoveGestureDetector(Context context, OnShoveGestureListener onShoveGestureListener) {
        super(context);
        this.mListener = onShoveGestureListener;
    }

    /* access modifiers changed from: protected */
    public void handleStartProgressEvent(int i, MotionEvent motionEvent) {
        if (i != 2) {
            if (i == 5) {
                resetState();
                this.mPrevEvent = MotionEvent.obtain(motionEvent);
                this.mTimeDelta = 0;
                updateStateByEvent(motionEvent);
                boolean isSloppyGesture = isSloppyGesture(motionEvent);
                this.mSloppyGesture = isSloppyGesture;
                if (!isSloppyGesture) {
                    this.mGestureInProgress = this.mListener.onShoveBegin(this);
                }
            }
        } else if (this.mSloppyGesture) {
            boolean isSloppyGesture2 = isSloppyGesture(motionEvent);
            this.mSloppyGesture = isSloppyGesture2;
            if (!isSloppyGesture2) {
                this.mGestureInProgress = this.mListener.onShoveBegin(this);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void handleInProgressEvent(int i, MotionEvent motionEvent) {
        if (i == 2) {
            updateStateByEvent(motionEvent);
            if (this.mCurrPressure / this.mPrevPressure > 0.67f && Math.abs(getShovePixelsDelta()) > 0.5f && this.mListener.onShove(this)) {
                this.mPrevEvent.recycle();
                this.mPrevEvent = MotionEvent.obtain(motionEvent);
            }
        } else if (i == 3) {
            if (!this.mSloppyGesture) {
                this.mListener.onShoveEnd(this);
            }
            resetState();
        } else if (i == 6) {
            updateStateByEvent(motionEvent);
            if (!this.mSloppyGesture) {
                this.mListener.onShoveEnd(this);
            }
            resetState();
        }
    }

    /* access modifiers changed from: protected */
    public void resetState() {
        super.resetState();
        this.mSloppyGesture = false;
        this.mPrevAverageY = 0.0f;
        this.mCurrAverageY = 0.0f;
    }

    /* access modifiers changed from: protected */
    public void updateStateByEvent(MotionEvent motionEvent) {
        super.updateStateByEvent(motionEvent);
        MotionEvent motionEvent2 = this.mPrevEvent;
        this.mPrevAverageY = (motionEvent2.getY(0) + motionEvent2.getY(1)) / 2.0f;
        this.mCurrAverageY = (motionEvent.getY(0) + motionEvent.getY(1)) / 2.0f;
    }

    /* access modifiers changed from: protected */
    public boolean isSloppyGesture(MotionEvent motionEvent) {
        if (super.isSloppyGesture(motionEvent)) {
            return true;
        }
        double abs = Math.abs(Math.atan2((double) this.mCurrFingerDiffY, (double) this.mCurrFingerDiffX));
        if ((0.0d >= abs || abs >= 0.3499999940395355d) && (2.7899999618530273d >= abs || abs >= 3.141592653589793d)) {
            return true;
        }
        return false;
    }

    public float getShovePixelsDelta() {
        return this.mCurrAverageY - this.mPrevAverageY;
    }
}
