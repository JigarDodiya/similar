package com.cutouteraser.backgroundremove.activity;

import android.view.View;

public final /* synthetic */ class SettingsActivity$$ExternalSyntheticLambda3 implements View.OnClickListener {
    public final /* synthetic */ SettingsActivity f$0;

    public /* synthetic */ SettingsActivity$$ExternalSyntheticLambda3(SettingsActivity settingsActivity) {
        this.f$0 = settingsActivity;
    }

    public final void onClick(View view) {
        this.f$0.mo12867x64168541(view);
    }
}
