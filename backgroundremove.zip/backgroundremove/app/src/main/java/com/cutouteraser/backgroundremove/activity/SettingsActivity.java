package com.cutouteraser.backgroundremove.activity;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.net.MailTo;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.helper.mp4u;

public class SettingsActivity extends AppCompatActivity {
    public LinearLayout relativeLayoutApps;
    public LinearLayout relativeLayoutFeedBack;
    public LinearLayout relativeLayoutGDPR;
    public LinearLayout relativeLayoutPrivacy;
    public LinearLayout relativeLayoutRate;
    public LinearLayout relativeLayoutShare;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_settings);
        getWindow().setFlags(1024, 1024);
        findViewById(R.id.image_view_exit).setOnClickListener(new View.OnClickListener() {
            public final void onClick(View view) {
                SettingsActivity.this.onBackPressed();
            }
        });
        this.relativeLayoutShare = (LinearLayout) findViewById(R.id.linearLayoutShare);
        this.relativeLayoutRate = (LinearLayout) findViewById(R.id.linearLayoutRate);
        this.relativeLayoutFeedBack = (LinearLayout) findViewById(R.id.linearLayoutFeedback);
        this.relativeLayoutPrivacy = (LinearLayout) findViewById(R.id.linearLayoutPrivacy);
        this.relativeLayoutApps = (LinearLayout) findViewById(R.id.linearLayoutApps);
        this.relativeLayoutGDPR = (LinearLayout) findViewById(R.id.linearLayoutGDPR);
        if (!SplashActivity.locationInEU) {
            this.relativeLayoutGDPR.setVisibility(View.GONE);
        }
        this.relativeLayoutShare.setOnClickListener(new SettingsActivity$$ExternalSyntheticLambda0(this));
        this.relativeLayoutRate.setOnClickListener(new SettingsActivity$$ExternalSyntheticLambda1(this));
        this.relativeLayoutFeedBack.setOnClickListener(new SettingsActivity$$ExternalSyntheticLambda2(this));
        this.relativeLayoutPrivacy.setOnClickListener(new SettingsActivity$$ExternalSyntheticLambda3(this));
        this.relativeLayoutApps.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    SettingsActivity settingsActivity = SettingsActivity.this;
                    settingsActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://search?q=pub:" + SettingsActivity.this.getString(R.string.more_link))));
                } catch (ActivityNotFoundException unused) {
                    SettingsActivity settingsActivity2 = SettingsActivity.this;
                    settingsActivity2.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://play.google.com/store/apps/developer?id=" + SettingsActivity.this.getString(R.string.more_link))));
                }
            }
        });
        this.relativeLayoutGDPR.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                new AlertDialog.Builder(SettingsActivity.this, R.style.MyDialogTheme).setMessage((int) R.string.gdpr_text).setPositiveButton((CharSequence) SettingsActivity.this.getResources().getString(R.string.yes), (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SettingsActivity.this.startActivity(new Intent(SettingsActivity.this, SplashActivity.class));
                    }
                }).setNegativeButton((CharSequence) SettingsActivity.this.getResources().getString(R.string.no), (DialogInterface.OnClickListener) new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                }).show();
            }
        });
    }

    /* renamed from: lambda$onCreate$0$com-cutouteraser-backgroundremove-activity-SettingsActivity */
    public /* synthetic */ void mo12864x34b5a3be(View view) {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.TEXT", "Download this awesome app\n https://play.google.com/store/apps/details?id=" + getPackageName() + " \n");
        startActivity(intent);
    }

    /* renamed from: lambda$onCreate$1$com-cutouteraser-backgroundremove-activity-SettingsActivity */
    public /* synthetic */ void mo12865xef2b443f(View view) {
        mp4u.rateApplication(this);
    }

    /* renamed from: lambda$onCreate$2$com-cutouteraser-backgroundremove-activity-SettingsActivity */
    public /* synthetic */ void mo12866xa9a0e4c0(View view) {
        Intent intent = new Intent("android.intent.action.SENDTO");
        intent.setData(Uri.parse(MailTo.MAILTO_SCHEME));
        boolean z = true;
        intent.putExtra("android.intent.extra.EMAIL", new String[]{getResources().getString(R.string.email_feedback)});
        intent.putExtra("android.intent.extra.TEXT", "");
        intent.putExtra("android.intent.extra.SUBJECT", getString(R.string.app_name));
        if (intent.resolveActivity(getPackageManager()) == null) {
            z = false;
        }
        if (z) {
            startActivity(intent);
        } else {
            Toast.makeText(this, R.string.email_app_not_installed, Toast.LENGTH_SHORT).show();
        }
    }

    /* renamed from: lambda$onCreate$3$com-cutouteraser-backgroundremove-activity-SettingsActivity */
    public /* synthetic */ void mo12867x64168541(View view) {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(getString(R.string.policy_url))));
        } catch (Exception unused) {
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }
}
