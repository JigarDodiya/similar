package com.cutouteraser.backgroundremove.helper;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

import com.cutouteraser.backgroundremove.activity.SplashActivity;

import java.util.Date;

public class MyApplication extends Application implements Application.ActivityLifecycleCallbacks, LifecycleObserver {
    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;

    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
    }

    public void onActivityResumed(Activity activity) {
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStopped(Activity activity) {
    }

    public void onCreate() {
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
        this.appOpenAdManager = new AppOpenAdManager();
    }

    /* access modifiers changed from: protected */
//    @OnLifecycleEvent(Lifecycle.Event.ON_START)
//    public void onMoveToForeground() {
//        if (!SplashActivity.showAppOpen) {
//            this.appOpenAdManager.showAdIfAvailable(this.currentActivity);
//        }
//    }

    public void onActivityStarted(Activity activity) {
        if (!this.appOpenAdManager.isShowingAd) {
            this.currentActivity = activity;
        }
    }

    public void showAdIfAvailable(Activity activity, OnShowAdCompleteListener onShowAdCompleteListener) {
//        if (!SplashActivity.showAppOpen) {
//            this.appOpenAdManager.showAdIfAvailable(activity, onShowAdCompleteListener);
//        }
    }

    private class AppOpenAdManager {
        private static final String AD_UNIT_ID = "ca-app-pub-1192275768252854/7022918784";
        private static final String LOG_TAG = "AppOpenAdManager";
        /* access modifiers changed from: private */
        /* access modifiers changed from: private */
        public boolean isLoadingAd = false;
        /* access modifiers changed from: private */
        public boolean isShowingAd = false;
        /* access modifiers changed from: private */
        public long loadTime = 0;

        public AppOpenAdManager() {
        }

        /* access modifiers changed from: private */
//        public void loadAd(Context context) {
//            AdRequest adRequest;
//            if (!this.isLoadingAd && !isAdAvailable()) {
//                this.isLoadingAd = true;
//                if (SplashActivity.personalizedAds) {
//                    adRequest = new AdRequest.Builder().build();
//                } else {
//                    Bundle bundle = new Bundle();
//                    bundle.putString("npa", "1");
//                    adRequest = new AdRequest.Builder().addNetworkExtrasBundle(AdMobAdapter.class, bundle).build();
//                }
////                AppOpenAd.load(context, AD_UNIT_ID, adRequest, 1, (AppOpenAd.AppOpenAdLoadCallback) new AppOpenAd.AppOpenAdLoadCallback() {
////                    public void onAdLoaded(AppOpenAd appOpenAd) {
////                        AppOpenAd unused = AppOpenAdManager.this.appOpenAd = appOpenAd;
////                        boolean unused2 = AppOpenAdManager.this.isLoadingAd = false;
////                        long unused3 = AppOpenAdManager.this.loadTime = new Date().getTime();
////                    }
////
////                    public void onAdFailedToLoad(LoadAdError loadAdError) {
////                        boolean unused = AppOpenAdManager.this.isLoadingAd = false;
////                    }
////                });
//            }
//        }

        private boolean wasLoadTimeLessThanNHoursAgo(long j) {
            return new Date().getTime() - this.loadTime < j * 3600000;
        }

//        private boolean isAdAvailable() {
//            return this.appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4);
//        }

        /* access modifiers changed from: private */
//        public void showAdIfAvailable(Activity activity) {
//            if (!SplashActivity.showAppOpen) {
//                showAdIfAvailable(activity, new OnShowAdCompleteListener() {
//                    public void onShowAdComplete() {
//                    }
//                });
//            }
//        }

        /* access modifiers changed from: private */
//        public void showAdIfAvailable(final Activity activity, final OnShowAdCompleteListener onShowAdCompleteListener) {
//            if (SplashActivity.showAppOpen) {
//                return;
//            }
//            if (this.isShowingAd) {
//                Log.d(LOG_TAG, "The app open ad is already showing.");
//            } else if (!isAdAvailable()) {
//                Log.d(LOG_TAG, "The app open ad is not ready yet.");
//                onShowAdCompleteListener.onShowAdComplete();
//                loadAd(activity);
//            } else {
//                this.appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
//                    public void onAdShowedFullScreenContent() {
//                    }
//
//                    public void onAdDismissedFullScreenContent() {
//                        AppOpenAd unused = AppOpenAdManager.this.appOpenAd = null;
//                        boolean unused2 = AppOpenAdManager.this.isShowingAd = false;
//                        onShowAdCompleteListener.onShowAdComplete();
//                        AppOpenAdManager.this.loadAd(activity);
//                    }
//
//                    public void onAdFailedToShowFullScreenContent(AdError adError) {
//                        AppOpenAd unused = AppOpenAdManager.this.appOpenAd = null;
//                        boolean unused2 = AppOpenAdManager.this.isShowingAd = false;
//                        onShowAdCompleteListener.onShowAdComplete();
//                        AppOpenAdManager.this.loadAd(activity);
//                    }
//                });
//                this.isShowingAd = true;
//                this.appOpenAd.show(activity);
//            }
//        }
    }
}
