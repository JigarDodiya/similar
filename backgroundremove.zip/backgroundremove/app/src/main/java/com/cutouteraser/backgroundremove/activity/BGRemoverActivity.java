package com.cutouteraser.backgroundremove.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Shader;
import android.media.ExifInterface;
import android.media.MediaScannerConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;

import androidx.recyclerview.widget.ItemTouchHelper;

import com.cutouteraser.backgroundremove.R;
import com.cutouteraser.backgroundremove.auto.BitmapUtils;
import com.cutouteraser.backgroundremove.auto.DeeplabMobile;
import com.cutouteraser.backgroundremove.auto.MotionUtils;
import com.cutouteraser.backgroundremove.auto.StoreManager;
import com.cutouteraser.backgroundremove.auto.SupportedClass;
import com.cutouteraser.backgroundremove.helper.BrushView;
import com.cutouteraser.backgroundremove.helper.TouchImageView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

public class BGRemoverActivity extends Activity {
    static final int AUTO_BRUSH = 2;
    static final int ERASE = 1;
    static final int ERASE_BRUSH = 1;
    static final int GREEN = 2;
    static final int LASSO = 7;
    static final int LASSO_BRUSH = 3;
    static final int NONE = 0;
    static final int NO_BRUSH = 0;
    static final int RED = 1;
    static final int REDRAW = 2;
    static final int TARGET = 6;
    static final int TARGET_AREA = 4;
    static final int TARGET_COLOR = 3;
    static final int ZOOM = 5;
    public static Bitmap highResolutionOutput;
    final int BRUSH_OFFSET_RANGE = 350;
    float BRUSH_SIZE = 70.0f;
    final int BRUSH_WIDTH_RANGE = 150;
    final int CAMERA_REQUEST = 2;
    int DRAWING_MODE = 1;
    int INITIAL_DRAWING_COUNT;
    int INITIAL_DRAWING_COUNT_LIMIT = 20;
    boolean IS_MULTIPLE_TOUCH_ERASING;
    final int JPEG = 2;
    final int LIBRARY_REQUEST = 1;
    final int MAX_THRESHOLD = 50;
    final float MIN_BRUSH_SIZE = 20.0f;
    final int MIN_OFFSET_SIZE = 270;
    int MODE = 0;
    int OFFSET = ItemTouchHelper.Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
    final int PNG = 1;
    int SAVE_COUNT = 0;
    public float TARGET_OFFSET;
    int TOLERANCE = 50;
    int TopBarButtonGap = 0;
    int UNDO_LIMIT = 10;
    int UPDATED_BRUSH_SIZE;
    LinearLayout autoEraseBtn;
    private RelativeLayout bannerAdContainer;
    LinearLayout bg_buttons_container;
    Bitmap bitmapMaster;
    ImageButton black_button;
    LinearLayout bottomBar;
    LinearLayout bottomBar1;
    BrushView brush;
    Vector<Integer> brushSizes = new Vector<>();
    Canvas canvasMaster;
    float currentx = 0.0f;
    float currenty = 0.0f;
    int density;
    TouchImageView drawingImageView;
    /* access modifiers changed from: private */
    public Path drawingPath;
    LinearLayout eraseBtn;
    Vector<Integer> erasing = new Vector<>();
    LinearLayout fitBtn;
    String imagePath;
    RelativeLayout imageViewContainer;
    int imageViewHeight;
    int imageViewWidth;
    boolean isAsyncExecuteForThresholdChange;
    boolean isBitmapUpdated;
    boolean isCheckBackGroundSet;
    boolean isImageResized;
    public boolean isPanning = false;
    boolean isSetBitmapAfterImageImport;
    boolean isTouchOnBitmap;
    boolean isWhiteCheckBackground = false;
    LinearLayout lassoBtn;
    int lassoStartX;
    int lassoStartY;
    Bitmap lastEiditedBitmap;
    float lastx = 0.0f;
    float lasty = 0.0f;
    int left;
    /* access modifiers changed from: private */
    LinearLayout mainLayout;
    Point mainViewSize;
    Bitmap maskBitmap;
    MediaScannerConnection msConn;
    SeekBar offsetSeekBar = null;
    Bitmap originalBitmap;
    String orignal;
    private ArrayList<Path> paths = new ArrayList<>();
    LinearLayout reDrawBtn;
    Vector<Integer> redoBrushSizes = new Vector<>();
    LinearLayout redoBtn;
    Vector<Integer> redoErasing = new Vector<>();
    private ArrayList<Path> redoPaths = new ArrayList<>();
    private ArrayList<Vector<Point>> redoTargetPointsArray = new ArrayList<>();
    LinearLayout resetBtn;
    Bitmap resizedBitmap;
    LinearLayout shareBtn;
    public boolean softEdge = false;
    LinearLayout softedgeButton;
    Uri source;
    /* access modifiers changed from: private */
    public ProgressBar spinner;
    LinearLayout targetAreaBtn;
    Vector<Point> targetPoints;
    private ArrayList<Vector<Point>> targetPointsArray = new ArrayList<>();
    int targetValueX;
    int targetValueY;
    LinearLayout thresholdContainer;
    SeekBar thresholdSeekBar = null;
    int top;
    LinearLayout topBar;
    ImageButton trans_button;
    LinearLayout undoBtn;
    boolean wasImageSaved;
    ImageButton whitebutton;
    LinearLayout widthContainer;
    SeekBar widthSeekBar = null;
    LinearLayout zoomAndPanBtn;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_bgremover);
        getWindow().setFlags(1024, 1024);
        AllocatrVariable();
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
        this.spinner = progressBar;
        progressBar.setVisibility(View.INVISIBLE);
        this.mainLayout = (LinearLayout) findViewById(R.id.mainLayOut);
        this.widthContainer = (LinearLayout) findViewById(R.id.widthcontainer);
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.thresholdcontainer);
        this.thresholdContainer = linearLayout;
        linearLayout.setVisibility(View.INVISIBLE);
        this.bg_buttons_container = (LinearLayout) findViewById(R.id.bg_buttons);
        this.drawingImageView = (TouchImageView) findViewById(R.id.drawingImageView);
        this.brush = (BrushView) findViewById(R.id.brushContainingView);
        this.topBar = (LinearLayout) findViewById(R.id.topBar);
        this.bottomBar = (LinearLayout) findViewById(R.id.bottomBar);
        this.bottomBar1 = (LinearLayout) findViewById(R.id.bottomBar1);
        this.imageViewContainer = (RelativeLayout) findViewById(R.id.imageViewContainer);
        this.fitBtn = (LinearLayout) findViewById(R.id.fitBtn);
        this.resetBtn = (LinearLayout) findViewById(R.id.resetBtn);
        this.shareBtn = (LinearLayout) findViewById(R.id.shareBtn);
        this.undoBtn = (LinearLayout) findViewById(R.id.undoBtn);
        this.redoBtn = (LinearLayout) findViewById(R.id.redoBtn);
        this.lassoBtn = (LinearLayout) findViewById(R.id.lassoBtn);
        this.eraseBtn = (LinearLayout) findViewById(R.id.eraseBtn);
        this.reDrawBtn = (LinearLayout) findViewById(R.id.restoreBtn);
        this.autoEraseBtn = (LinearLayout) findViewById(R.id.autoEraseBtn);
        this.targetAreaBtn = (LinearLayout) findViewById(R.id.targetAreaBtn);
        this.softedgeButton = (LinearLayout) findViewById(R.id.softEdge);
        this.zoomAndPanBtn = (LinearLayout) findViewById(R.id.zoomBtn);
        this.trans_button = (ImageButton) findViewById(R.id.trans_button);
        this.whitebutton = (ImageButton) findViewById(R.id.white_button);
        this.black_button = (ImageButton) findViewById(R.id.black_button);
        this.offsetSeekBar = (SeekBar) findViewById(R.id.offsetSeekBar);
        this.widthSeekBar = (SeekBar) findViewById(R.id.widthSeekBar);
        this.thresholdSeekBar = (SeekBar) findViewById(R.id.thresholdSeekBar);
        this.bannerAdContainer = (RelativeLayout) findViewById(R.id.bannerAdContainer);
        this.trans_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.imageViewContainer.setBackgroundResource(R.drawable.pattern);
            }
        });
        this.black_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.imageViewContainer.setBackgroundResource(R.drawable.black_pattern);
            }
        });
        this.whitebutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.imageViewContainer.setBackgroundResource(R.drawable.white_pattern);
            }
        });
        setUiSize();
        setOnClickActionsMethods();
        this.orignal = getIntent().getExtras().getString("path");
        try {

            this.originalBitmap = BitmapFactory.decodeResource(getResources(),
                    R.drawable.jigar);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.wasImageSaved = true;
        setBitMap();
        updateBrush((float) (this.mainViewSize.x / 2), (float) (this.mainViewSize.y / 2));
        this.drawingImageView.setOnTouchListener(new mainTouchListner());
        this.widthSeekBar.setMax(150);
        this.widthSeekBar.setProgress((int) (this.BRUSH_SIZE - 20.0f));
        this.widthSeekBar.setOnSeekBarChangeListener(new brushSizeChangeListner());
        this.offsetSeekBar.setMax(350);
        this.offsetSeekBar.setProgress(this.OFFSET);
        this.offsetSeekBar.setOnSeekBarChangeListener(new offsetChangeListner());
        this.thresholdSeekBar.setMax(50);
        this.thresholdSeekBar.setProgress(25);
        this.thresholdSeekBar.setOnSeekBarChangeListener(new tolerenceSeekbarListner());
    }

    private void AllocatrVariable() {
        this.drawingPath = new Path();
        this.targetPoints = new Vector<>();
    }

    public void setUiSize() {
        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        Point point = new Point();
        this.mainViewSize = point;
        defaultDisplay.getSize(point);
        int i = (int) getResources().getDisplayMetrics().density;
        this.density = i;
        this.TARGET_OFFSET = (float) (i * 66);
        getWindow().getDecorView().getWindowVisibleDisplayFrame(new Rect());
        this.imageViewWidth = this.mainViewSize.x;
        this.imageViewHeight = this.mainViewSize.y;
    }

    public void setOnClickActionsMethods() {
        this.fitBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.fitBtnClicked();
            }
        });
        this.resetBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.resetBtnClicked();
            }
        });
        this.undoBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.undoBtnClicked();
            }
        });
        this.redoBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.redoBtnClicked();
            }
        });
        this.shareBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
            }
        });
        this.lassoBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.lassoBtnClicked();
            }
        });
        this.eraseBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.eraseBtnClicked();
            }
        });
        this.reDrawBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.reDrawBtnClicked();
            }
        });
        this.autoEraseBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.changeBackground(3);
                BGRemoverActivity.this.applyEraseAutoProgressBar();
            }
        });
        this.targetAreaBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.targetAreaBtnClicked();
            }
        });
        this.softedgeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (BGRemoverActivity.this.softEdge) {
                    BGRemoverActivity.this.softEdge = false;
                    BGRemoverActivity.this.softedgeButton.setAlpha(0.55f);
                    return;
                }
                BGRemoverActivity.this.softEdge = true;
                BGRemoverActivity.this.softedgeButton.setAlpha(1.0f);
            }
        });
        this.zoomAndPanBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BGRemoverActivity.this.zoomAndPanBtnClicked();
            }
        });
    }

    /* access modifiers changed from: private */
    public void applyEraseAutoProgressBar() {
        this.thresholdContainer.setVisibility(View.INVISIBLE);
        this.spinner.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {

            /* renamed from: com.cutouteraser.backgroundremove.activity.BGRemoverActivity$17$autoRunabble */
            class autoRunabble implements Runnable {
                autoRunabble() {
                }

                public void run() {
                    BGRemoverActivity.this.spinner.setVisibility(View.INVISIBLE);
                }
            }

            public void run() {
                BGRemoverActivity bGRemoverActivity = BGRemoverActivity.this;
                bGRemoverActivity.bitmapMaster = BitmapFactory.decodeResource(getResources(),
                        R.drawable.jigar);
                BGRemoverActivity bGRemoverActivity2 = BGRemoverActivity.this;
                bGRemoverActivity2.lastEiditedBitmap = bGRemoverActivity2.autoEraseAi(bGRemoverActivity2.lastEiditedBitmap);
                BGRemoverActivity.this.canvasMaster = new Canvas(BGRemoverActivity.this.bitmapMaster);
                BGRemoverActivity.this.canvasMaster.drawBitmap(BGRemoverActivity.this.lastEiditedBitmap, 0.0f, 0.0f, (Paint) null);
                BGRemoverActivity.this.drawingImageView.setImageBitmap(BGRemoverActivity.this.bitmapMaster);
                BGRemoverActivity.this.addDrawingPathToArrayList();
                BGRemoverActivity.this.resetRedoPathArrays();
                BGRemoverActivity.this.undoBtn.setEnabled(true);
                BGRemoverActivity.this.redoBtn.setEnabled(false);
                new Handler().postDelayed(new autoRunabble(), 100);
            }
        }, 100);
    }

    private Bitmap rotate(Bitmap bitmap, float f) {
        Matrix matrix = new Matrix();
        matrix.postRotate(f);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    private Bitmap flip(Bitmap bitmap, boolean z, boolean z2) {
        Matrix matrix = new Matrix();
        float f = -1.0f;
        float f2 = z ? -1.0f : 1.0f;
        if (!z2) {
            f = 1.0f;
        }
        matrix.preScale(f2, f);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    }

    private Bitmap modifyOrientation(Bitmap bitmap, String str) throws IOException {
        int attributeInt = new ExifInterface(str).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
        if (attributeInt == 2) {
            return flip(bitmap, true, false);
        }
        if (attributeInt == 3) {
            return rotate(bitmap, 180.0f);
        }
        if (attributeInt == 4) {
            return flip(bitmap, false, true);
        }
        if (attributeInt == 6) {
            return rotate(bitmap, 90.0f);
        }
        if (attributeInt != 8) {
            return bitmap;
        }
        return rotate(bitmap, 270.0f);
    }

    public void setBitMap() {
        this.isImageResized = false;
        Bitmap bitmap = this.resizedBitmap;
        if (bitmap != null) {
            bitmap.recycle();
            this.resizedBitmap = null;
        }
        Bitmap bitmap2 = this.bitmapMaster;
        if (bitmap2 != null) {
            bitmap2.recycle();
            this.bitmapMaster = null;
        }
        this.canvasMaster = null;
        Bitmap resizeBitmapByCanvas = resizeBitmapByCanvas(true);
        this.resizedBitmap = resizeBitmapByCanvas;
        if (this.wasImageSaved) {
            Bitmap bmEditedfromInternalStorage = getBmEditedfromInternalStorage();
            if (bmEditedfromInternalStorage != null) {
                this.lastEiditedBitmap = bmEditedfromInternalStorage.copy(Bitmap.Config.ARGB_8888, true);
                bmEditedfromInternalStorage.recycle();
            } else {
                this.lastEiditedBitmap = this.resizedBitmap.copy(Bitmap.Config.ARGB_8888, true);
            }
        } else {
            this.lastEiditedBitmap = resizeBitmapByCanvas.copy(Bitmap.Config.ARGB_8888, true);
        }
        try {
            this.lastEiditedBitmap = modifyOrientation(this.lastEiditedBitmap, getIntent().getStringExtra("image_path"));
        } catch (Exception unused) {
        }
        this.bitmapMaster = Bitmap.createBitmap(this.lastEiditedBitmap.getWidth(), this.lastEiditedBitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(this.bitmapMaster);
        this.canvasMaster = canvas;
        canvas.drawBitmap(this.lastEiditedBitmap, 0.0f, 0.0f, (Paint) null);
        this.drawingImageView.setImageBitmap(this.bitmapMaster);
        resetPathArrays();
        eraseBtnClicked();
    }

    public void updateBrush(float f, float f2) {
        this.brush.offset = (float) this.OFFSET;
        this.brush.centerx = f;
        this.brush.centery = f2;
        this.brush.width = this.BRUSH_SIZE / 2.0f;
        this.brush.invalidate();
    }

    private class mainTouchListner implements View.OnTouchListener {
        mainTouchListner() {
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (BGRemoverActivity.this.isPanning || (motionEvent.getPointerCount() != 1 && !BGRemoverActivity.this.IS_MULTIPLE_TOUCH_ERASING)) {
                if (BGRemoverActivity.this.INITIAL_DRAWING_COUNT > 0) {
                    if (BGRemoverActivity.this.DRAWING_MODE == 1 || BGRemoverActivity.this.DRAWING_MODE == 2) {
                        BGRemoverActivity.this.UpdateCanvas(false);
                        BGRemoverActivity.this.drawingPath.reset();
                    } else if (BGRemoverActivity.this.DRAWING_MODE == 7) {
                        BGRemoverActivity.this.brush.lessoLineDrawingPath.reset();
                        BGRemoverActivity.this.brush.invalidate();
                    }
                    BGRemoverActivity.this.INITIAL_DRAWING_COUNT = 0;
                }
                BGRemoverActivity.this.drawingImageView.onTouchEvent(motionEvent);
                BGRemoverActivity.this.MODE = 5;
            } else if (action == 0) {
                BGRemoverActivity.this.isTouchOnBitmap = false;
                BGRemoverActivity.this.drawingImageView.onTouchEvent(motionEvent);
                BGRemoverActivity.this.MODE = 1;
                BGRemoverActivity.this.INITIAL_DRAWING_COUNT = 0;
                BGRemoverActivity.this.IS_MULTIPLE_TOUCH_ERASING = false;
                if (BGRemoverActivity.this.DRAWING_MODE == 1 || BGRemoverActivity.this.DRAWING_MODE == 2 || BGRemoverActivity.this.DRAWING_MODE == 7) {
                    BGRemoverActivity bGRemoverActivity = BGRemoverActivity.this;
                    bGRemoverActivity.moveTopoint((TouchImageView) view, bGRemoverActivity.bitmapMaster, motionEvent.getX(), motionEvent.getY());
                }
                if (BGRemoverActivity.this.DRAWING_MODE == 7) {
                    BGRemoverActivity.this.brush.resetLessoLineDrawingPath(motionEvent.getX(), motionEvent.getY());
                }
                BGRemoverActivity.this.updateBrush(motionEvent.getX(), motionEvent.getY());
            } else if (action == 2) {
                if (BGRemoverActivity.this.MODE == 1) {
                    BGRemoverActivity.this.currentx = motionEvent.getX();
                    BGRemoverActivity.this.currenty = motionEvent.getY();
                    if (BGRemoverActivity.this.DRAWING_MODE == 7) {
                        BGRemoverActivity.this.brush.addLineToLessoLineDrawingPath(motionEvent.getX(), motionEvent.getY());
                    }
                    BGRemoverActivity bGRemoverActivity2 = BGRemoverActivity.this;
                    bGRemoverActivity2.updateBrush(bGRemoverActivity2.currentx, BGRemoverActivity.this.currenty);
                    if (BGRemoverActivity.this.DRAWING_MODE == 1 || BGRemoverActivity.this.DRAWING_MODE == 2 || BGRemoverActivity.this.DRAWING_MODE == 7) {
                        BGRemoverActivity bGRemoverActivity3 = BGRemoverActivity.this;
                        bGRemoverActivity3.lineTopoint((TouchImageView) view, bGRemoverActivity3.bitmapMaster, BGRemoverActivity.this.currentx, BGRemoverActivity.this.currenty);
                        if (BGRemoverActivity.this.DRAWING_MODE != 7) {
                            BGRemoverActivity.this.drawOnTouchMove();
                        }
                    }
                }
            } else if (action == 1 || action == 6) {
                if (BGRemoverActivity.this.MODE == 1) {
                    if (BGRemoverActivity.this.DRAWING_MODE == 4) {
                        BGRemoverActivity.this.TOLERANCE = 25;
                        BGRemoverActivity.this.thresholdSeekBar.setProgress(BGRemoverActivity.this.TOLERANCE);
                        BGRemoverActivity.this.applyFloodFil(motionEvent.getX(), motionEvent.getY());
                    } else if (BGRemoverActivity.this.DRAWING_MODE == 3) {
                        BGRemoverActivity.this.applyRePlaceColor(motionEvent.getX(), motionEvent.getY());
                    } else if ((BGRemoverActivity.this.DRAWING_MODE == 1 || BGRemoverActivity.this.DRAWING_MODE == 2 || BGRemoverActivity.this.DRAWING_MODE == 7) && BGRemoverActivity.this.INITIAL_DRAWING_COUNT > 0) {
                        if (BGRemoverActivity.this.DRAWING_MODE == 7) {
                            BGRemoverActivity.this.brush.lessoLineDrawingPath.reset();
                            BGRemoverActivity.this.brush.invalidate();
                            if (BGRemoverActivity.this.isTouchOnBitmap) {
                                BGRemoverActivity.this.applyLasso();
                            }
                        }
                        if (BGRemoverActivity.this.isTouchOnBitmap) {
                            BGRemoverActivity.this.addDrawingPathToArrayList();
                        }
                    }
                }
                BGRemoverActivity.this.IS_MULTIPLE_TOUCH_ERASING = false;
                BGRemoverActivity.this.INITIAL_DRAWING_COUNT = 0;
                BGRemoverActivity.this.MODE = 0;
            }
            if (action == 1 || action == 6) {
                BGRemoverActivity.this.MODE = 0;
            }
            return true;
        }
    }

    private class brushSizeChangeListner implements SeekBar.OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
        }

        brushSizeChangeListner() {
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            BGRemoverActivity.this.BRUSH_SIZE = ((float) i) + 20.0f;
            BGRemoverActivity.this.updateBrushWidth();
        }
    }

    private class offsetChangeListner implements SeekBar.OnSeekBarChangeListener {
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
        }

        offsetChangeListner() {
        }

        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            BGRemoverActivity.this.OFFSET = i;
            BGRemoverActivity.this.updateBrushOffset();
        }
    }

    private class tolerenceSeekbarListner implements SeekBar.OnSeekBarChangeListener {
        public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        tolerenceSeekbarListner() {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            if (BGRemoverActivity.this.DRAWING_MODE == 3 || BGRemoverActivity.this.DRAWING_MODE == 4) {
                BGRemoverActivity.this.TOLERANCE = seekBar.getProgress();
                if (BGRemoverActivity.this.isBitmapUpdated) {
                    if (BGRemoverActivity.this.DRAWING_MODE == 4) {
                        BGRemoverActivity.this.isAsyncExecuteForThresholdChange = true;
                        BGRemoverActivity.this.applyFloodFillWithProgressBar();
                    } else if (BGRemoverActivity.this.DRAWING_MODE == 3) {
                        BGRemoverActivity bGRemoverActivity = BGRemoverActivity.this;
                        bGRemoverActivity.rePlaceAcolorOfBitmap(bGRemoverActivity.bitmapMaster, BGRemoverActivity.this.bitmapMaster.getPixel(BGRemoverActivity.this.targetValueX, BGRemoverActivity.this.targetValueY), 0);
                    }
                }
            }
        }
    }

    public void resetBtnClicked() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.warning);
        builder.setMessage(R.string.progress_will_be_lost);
        builder.setNeutralButton(R.string.no, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.setNegativeButton(R.string.yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                BGRemoverActivity.this.resetPathArrays();
                BGRemoverActivity.this.canvasMaster.drawBitmap(BGRemoverActivity.this.resizedBitmap, 0.0f, 0.0f, (Paint) null);
                if (BGRemoverActivity.this.lastEiditedBitmap != null) {
                    BGRemoverActivity.this.lastEiditedBitmap.recycle();
                    BGRemoverActivity.this.lastEiditedBitmap = null;
                }
                BGRemoverActivity bGRemoverActivity = BGRemoverActivity.this;
                bGRemoverActivity.lastEiditedBitmap = bGRemoverActivity.resizedBitmap.copy(BGRemoverActivity.this.resizedBitmap.getConfig(), true);
                BGRemoverActivity.this.drawingImageView.invalidate();
                BGRemoverActivity.this.undoBtn.setEnabled(false);
                BGRemoverActivity.this.redoBtn.setEnabled(false);
                BGRemoverActivity.this.isBitmapUpdated = false;
            }
        });
        builder.show();
    }

    public void fitBtnClicked() {
        if (this.MODE == 0) {
            this.drawingImageView.resetZoom();
        }
    }

    public void undoBtnClicked() {
        if (this.MODE == 0) {
            this.isBitmapUpdated = false;
            int size = this.paths.size();
            if (size != 0) {
                if (size == 1) {
                    this.undoBtn.setEnabled(false);
                }
                int i = size - 1;
                this.redoTargetPointsArray.add(this.targetPointsArray.remove(i));
                this.redoPaths.add(this.paths.remove(i));
                this.redoErasing.add(this.erasing.remove(i));
                this.redoBrushSizes.add(this.brushSizes.remove(i));
                if (!this.redoBtn.isEnabled()) {
                    this.redoBtn.setEnabled(true);
                }
                UpdateCanvas(false);
            }
        }
    }

    public void redoBtnClicked() {
        if (this.MODE == 0) {
            this.isBitmapUpdated = false;
            int size = this.redoPaths.size();
            if (size != 0) {
                if (size == 1) {
                    this.redoBtn.setEnabled(false);
                }
                int i = size - 1;
                this.targetPointsArray.add(this.redoTargetPointsArray.remove(i));
                this.paths.add(this.redoPaths.remove(i));
                this.erasing.add(this.redoErasing.remove(i));
                this.brushSizes.add(this.redoBrushSizes.remove(i));
                if (!this.undoBtn.isEnabled()) {
                    this.undoBtn.setEnabled(true);
                }
                UpdateCanvas(false);
            }
        }
    }

    public void lassoBtnClicked() {
        this.widthContainer.setVisibility(View.VISIBLE);
        this.thresholdContainer.setVisibility(View.INVISIBLE);
        this.bg_buttons_container.setVisibility(View.INVISIBLE);
        if (this.DRAWING_MODE == 2) {
            this.DRAWING_MODE = 7;
            UpdateCanvas(false);
        }
        this.drawingImageView.setPan(false);
        this.isPanning = false;
        this.DRAWING_MODE = 7;
        changeBackground(7);
        this.brush.setMode(3);
        this.brush.invalidate();
    }

    public void eraseBtnClicked() {
        this.widthContainer.setVisibility(View.VISIBLE);
        this.thresholdContainer.setVisibility(View.INVISIBLE);
        this.bg_buttons_container.setVisibility(View.INVISIBLE);
        if (this.DRAWING_MODE == 2) {
            this.DRAWING_MODE = 1;
            if (this.paths.size() > 0) {
                UpdateCanvas(false);
            }
        }
        this.drawingImageView.setPan(false);
        this.isPanning = false;
        this.DRAWING_MODE = 1;
        changeBackground(1);
        this.brush.setMode(1);
        this.brush.invalidate();
    }

    public void reDrawBtnClicked() {
        if (!(this.DRAWING_MODE == 2 || this.resizedBitmap == null)) {
            Bitmap bitmap = this.bitmapMaster;
            Bitmap copy = bitmap.copy(bitmap.getConfig(), false);
            this.canvasMaster.drawBitmap(this.resizedBitmap, 0.0f, 0.0f, (Paint) null);
            this.canvasMaster.drawColor(Color.argb(150, 0, 255, 20));
            this.canvasMaster.drawBitmap(copy, 0.0f, 0.0f, (Paint) null);
        }
        this.widthContainer.setVisibility(View.VISIBLE);
        this.thresholdContainer.setVisibility(View.INVISIBLE);
        this.bg_buttons_container.setVisibility(View.INVISIBLE);
        this.drawingImageView.setPan(false);
        this.isPanning = false;
        this.DRAWING_MODE = 2;
        changeBackground(2);
        this.brush.setMode(1);
        this.brush.invalidate();
    }

    public Bitmap autoEraseAi(Bitmap bitmap) {
        DeeplabMobile deeplabMobile = new DeeplabMobile();
        deeplabMobile.initialize(getApplicationContext());
        return loadInBackground(bitmap, deeplabMobile);
    }

    public Bitmap loadInBackground(Bitmap bitmap, DeeplabMobile deeplabMobile) {
        if (bitmap == null) {
            return null;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        float max = 513.0f / ((float) Math.max(bitmap.getWidth(), bitmap.getHeight()));
        int round = Math.round(((float) width) * max);
        int round2 = Math.round(((float) height) * max);
        Bitmap segment = deeplabMobile.segment(SupportedClass.tfResizeBilinear(bitmap, round, round2));
        this.maskBitmap = segment;
        if (segment == null) {
            return null;
        }
        Bitmap createClippedBitmap = BitmapUtils.createClippedBitmap(segment, (segment.getWidth() - round) / 2, (this.maskBitmap.getHeight() - round2) / 2, round, round2);
        this.maskBitmap = createClippedBitmap;
        Bitmap scaleBitmap = BitmapUtils.scaleBitmap(createClippedBitmap, width, height);
        this.maskBitmap = scaleBitmap;
        this.left = (scaleBitmap.getWidth() - width) / 2;
        this.top = (this.maskBitmap.getHeight() - height) / 2;
        StoreManager.croppedLeft = this.left;
        int i = this.top;
        StoreManager.croppedTop = i;
        this.top = i;
        StoreManager.setCurrentCroppedMaskBitmap(this, this.maskBitmap);
        return MotionUtils.cropBitmapWithMask(bitmap, this.maskBitmap, 0, 0);
    }

    public void targetAreaBtnClicked() {
        if (this.DRAWING_MODE != 4) {
            this.isBitmapUpdated = false;
        }
        this.widthContainer.setVisibility(View.INVISIBLE);
        this.thresholdContainer.setVisibility(View.VISIBLE);
        this.bg_buttons_container.setVisibility(View.INVISIBLE);
        if (this.DRAWING_MODE == 2) {
            this.DRAWING_MODE = 4;
            UpdateCanvas(false);
        }
        this.brush.setMode(2);
        this.DRAWING_MODE = 4;
        changeBackground(4);
        this.drawingImageView.setPan(false);
        this.isPanning = false;
        this.brush.invalidate();
    }

    public void targetColorBtnClicked() {
        this.widthContainer.setVisibility(View.INVISIBLE);
        this.thresholdContainer.setVisibility(View.GONE);
        this.bg_buttons_container.setVisibility(View.INVISIBLE);
        if (this.DRAWING_MODE == 2) {
            this.brush.setMode(2);
            this.DRAWING_MODE = 3;
            this.drawingImageView.setPan(false);
            this.isPanning = false;
            this.brush.invalidate();
            return;
        }
        this.brush.setMode(2);
        this.DRAWING_MODE = 3;
        this.drawingImageView.setPan(false);
        this.isPanning = false;
        this.brush.invalidate();
    }

    public void zoomAndPanBtnClicked() {
        this.drawingImageView.setPan(true);
        this.isPanning = true;
        changeBackground(5);
        this.brush.setMode(0);
        this.brush.invalidate();
    }

    public void changeBackground(int i) {
        this.lassoBtn.setBackgroundColor(Color.argb(0, 0, 0, 0));
        this.eraseBtn.setBackgroundColor(Color.argb(0, 0, 0, 0));
        this.autoEraseBtn.setBackgroundColor(Color.argb(0, 0, 0, 0));
        this.targetAreaBtn.setBackgroundColor(Color.argb(0, 0, 0, 0));
        this.reDrawBtn.setBackgroundColor(Color.argb(0, 0, 0, 0));
        this.zoomAndPanBtn.setBackgroundColor(Color.argb(0, 0, 0, 0));
        if (i == 7) {
            this.lassoBtn.setBackgroundColor(Color.argb(255, 58, 58, 58));
        } else if (i == 1) {
            this.eraseBtn.setBackgroundColor(Color.argb(255, 58, 58, 58));
        } else if (i == 4) {
            this.targetAreaBtn.setBackgroundColor(Color.argb(255, 58, 58, 58));
        } else if (i == 2) {
            this.reDrawBtn.setBackgroundColor(Color.argb(255, 58, 58, 58));
        } else if (i == 5) {
            this.zoomAndPanBtn.setBackgroundColor(Color.argb(255, 58, 58, 58));
        } else if (i == 3) {
            this.autoEraseBtn.setBackgroundColor(Color.argb(255, 58, 58, 58));
        }
    }


    public void shareBtnClicked() {
        if (this.MODE == 0) {
            if (this.DRAWING_MODE == 2) {
                UpdateCanvas(true);
                makeHighResolutionOutput();
                Bitmap bitmap = this.bitmapMaster;
                Bitmap copy = bitmap.copy(bitmap.getConfig(), false);
                this.canvasMaster.drawBitmap(this.resizedBitmap, 0.0f, 0.0f, (Paint) null);
                this.canvasMaster.drawColor(Color.argb(150, 0, 255, 20));
                this.canvasMaster.drawBitmap(copy, 0.0f, 0.0f, (Paint) null);
            } else {
                makeHighResolutionOutput();
            }
            new imageSaveByAsync().execute(new String[0]);
        }
    }

    public void UpdateCanvas(boolean z) {
        this.canvasMaster.drawColor(0, PorterDuff.Mode.CLEAR);
        this.canvasMaster.drawBitmap(this.lastEiditedBitmap, 0.0f, 0.0f, (Paint) null);
        for (int i = 0; i < this.paths.size(); i++) {
            int intValue = this.brushSizes.get(i).intValue();
            int intValue2 = this.erasing.get(i).intValue();
            Paint paint = new Paint();
            if (this.softEdge) {
                paint.setMaskFilter(new BlurMaskFilter(10.0f, BlurMaskFilter.Blur.NORMAL));
            } else {
                paint.setMaskFilter(new BlurMaskFilter(1.0f, BlurMaskFilter.Blur.NORMAL));
            }
            if (intValue2 == 1) {
                paint.setColor(0);
                paint.setStyle(Paint.Style.STROKE);
                paint.setAntiAlias(true);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
                paint.setStrokeWidth((float) intValue);
                this.canvasMaster.drawPath(this.paths.get(i), paint);
            } else if (intValue2 == 2) {
                paint.setStrokeWidth((float) intValue);
                paint.setStyle(Paint.Style.STROKE);
                paint.setAntiAlias(true);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setStrokeCap(Paint.Cap.ROUND);
                BitmapShader bitmapShader = new BitmapShader(this.resizedBitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
                paint.setColor(-1);
                paint.setShader(bitmapShader);
                this.canvasMaster.drawPath(this.paths.get(i), paint);
            } else if (intValue2 == 7) {
                Bitmap bitmap = this.bitmapMaster;
                Bitmap copy = bitmap.copy(bitmap.getConfig(), true);
                new Canvas(copy).drawBitmap(this.bitmapMaster, 0.0f, 0.0f, (Paint) null);
                Canvas canvas = new Canvas(this.bitmapMaster);
                canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                Paint paint2 = new Paint();
                canvas.drawPath(this.paths.get(i), paint2);
                paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                canvas.drawBitmap(copy, 0.0f, 0.0f, paint2);
            } else if (intValue2 == 6) {
                Vector vector = this.targetPointsArray.get(i);
                for (int i2 = 0; i2 < vector.size(); i2++) {
                    Point point = (Point) vector.get(i2);
                    this.bitmapMaster.setPixel(point.x, point.y, 0);
                }
            }
        }
        if (!z) {
            if (this.DRAWING_MODE == 2) {
                Bitmap bitmap2 = this.bitmapMaster;
                Bitmap copy2 = bitmap2.copy(bitmap2.getConfig(), false);
                this.canvasMaster.drawBitmap(this.resizedBitmap, 0.0f, 0.0f, (Paint) null);
                this.canvasMaster.drawColor(Color.argb(150, 0, 255, 20));
                this.canvasMaster.drawBitmap(copy2, 0.0f, 0.0f, (Paint) null);
            }
            this.drawingImageView.invalidate();
        }
    }

    private void makeHighResolutionOutput() {
        if (this.isImageResized) {
            Bitmap createBitmap = Bitmap.createBitmap(this.originalBitmap.getWidth(), this.originalBitmap.getHeight(), this.originalBitmap.getConfig());
            Canvas canvas = new Canvas(createBitmap);
            Paint paint = new Paint();
            if (this.softEdge) {
                paint.setMaskFilter(new BlurMaskFilter(10.0f, BlurMaskFilter.Blur.NORMAL));
            } else {
                paint.setMaskFilter(new BlurMaskFilter(1.0f, BlurMaskFilter.Blur.NORMAL));
            }
            paint.setColor(Color.argb(255, 255, 255, 255));
            Rect rect = new Rect(0, 0, this.bitmapMaster.getWidth(), this.bitmapMaster.getHeight());
            Rect rect2 = new Rect(0, 0, this.originalBitmap.getWidth(), this.originalBitmap.getHeight());
            canvas.drawRect(rect2, paint);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            canvas.drawBitmap(this.bitmapMaster, rect, rect2, paint);
            highResolutionOutput = null;
            highResolutionOutput = Bitmap.createBitmap(this.originalBitmap.getWidth(), this.originalBitmap.getHeight(), this.originalBitmap.getConfig());
            Canvas canvas2 = new Canvas(highResolutionOutput);
            canvas2.drawBitmap(this.originalBitmap, 0.0f, 0.0f, (Paint) null);
            Paint paint2 = new Paint();
            paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
            canvas2.drawBitmap(createBitmap, 0.0f, 0.0f, paint2);
            return;
        }
        highResolutionOutput = null;
        Bitmap bitmap = this.bitmapMaster;
        highResolutionOutput = bitmap.copy(bitmap.getConfig(), true);
    }

    private class imageSaveByAsync extends AsyncTask<String, Void, Boolean> {
        private imageSaveByAsync() {
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            BGRemoverActivity.this.getWindow().setFlags(16, 16);
        }

        /* access modifiers changed from: protected */
        public Boolean doInBackground(String... strArr) {
            try {
                BGRemoverActivity.this.savePhoto(BGRemoverActivity.highResolutionOutput, 1);
                return true;
            } catch (Exception unused) {
                return false;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Boolean bool) {
            BGRemoverActivity.this.spinner.setVisibility(View.INVISIBLE);
            BGRemoverActivity.this.SAVE_COUNT++;
            BGRemoverActivity.this.getWindow().clearFlags(16);
        }
    }

    public void savePhoto(Bitmap bitmap, int i) {
        startActivity(new Intent(this, Editactivity.class));
    }

    /* access modifiers changed from: private */
    public void moveTopoint(TouchImageView touchImageView, Bitmap bitmap, float f, float f2) {
        float imageViewZoom = getImageViewZoom();
        float f3 = f2 - ((float) this.OFFSET);
        if (this.redoPaths.size() > 0) {
            resetRedoPathArrays();
        }
        PointF imageViewTranslation = getImageViewTranslation();
        double d = (double) imageViewZoom;
        int i = (int) ((float) (((double) (f - imageViewTranslation.x)) / d));
        int i2 = (int) ((float) (((double) (f3 - imageViewTranslation.y)) / d));
        this.drawingPath.moveTo((float) i, (float) i2);
        if (this.DRAWING_MODE == 7) {
            this.lassoStartX = i;
            this.lassoStartY = i2;
        }
        this.UPDATED_BRUSH_SIZE = (int) (this.BRUSH_SIZE / imageViewZoom);
    }

    public PointF getImageViewTranslation() {
        return this.drawingImageView.getTransForm();
    }

    /* access modifiers changed from: private */
    public void lineTopoint(TouchImageView touchImageView, Bitmap bitmap, float f, float f2) {
        int i = this.INITIAL_DRAWING_COUNT;
        int i2 = this.INITIAL_DRAWING_COUNT_LIMIT;
        if (i < i2) {
            int i3 = i + 1;
            this.INITIAL_DRAWING_COUNT = i3;
            if (i3 == i2) {
                this.IS_MULTIPLE_TOUCH_ERASING = true;
            }
        }
        float imageViewZoom = getImageViewZoom();
        float f3 = f2 - ((float) this.OFFSET);
        PointF imageViewTranslation = getImageViewTranslation();
        double d = (double) imageViewZoom;
        int i4 = (int) ((float) (((double) (f - imageViewTranslation.x)) / d));
        int i5 = (int) ((float) (((double) (f3 - imageViewTranslation.y)) / d));
        if (!this.isTouchOnBitmap && i4 > 0 && i4 < bitmap.getWidth() && i5 > 0 && i5 < bitmap.getHeight()) {
            this.isTouchOnBitmap = true;
        }
        this.drawingPath.lineTo((float) i4, (float) i5);
    }

    /* access modifiers changed from: private */
    public void drawOnTouchMove() {
        Paint paint = new Paint();
        if (this.softEdge) {
            paint.setMaskFilter(new BlurMaskFilter(10.0f, BlurMaskFilter.Blur.NORMAL));
        } else {
            paint.setMaskFilter(new BlurMaskFilter(1.0f, BlurMaskFilter.Blur.NORMAL));
        }
        int i = this.DRAWING_MODE;
        if (i == 1) {
            paint.setStrokeWidth((float) this.UPDATED_BRUSH_SIZE);
            paint.setColor(0);
            paint.setStyle(Paint.Style.STROKE);
            paint.setAntiAlias(true);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
        } else if (i == 2) {
            paint.setStrokeWidth((float) this.UPDATED_BRUSH_SIZE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setAntiAlias(true);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeCap(Paint.Cap.ROUND);
            BitmapShader bitmapShader = new BitmapShader(this.resizedBitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            paint.setColor(-1);
            paint.setShader(bitmapShader);
        }
        this.canvasMaster.drawPath(this.drawingPath, paint);
        this.drawingImageView.invalidate();
    }

    /* access modifiers changed from: private */
    public void applyLasso() {
        Bitmap bitmap = this.bitmapMaster;
        Bitmap copy = bitmap.copy(bitmap.getConfig(), true);
        new Canvas(copy).drawBitmap(this.bitmapMaster, 0.0f, 0.0f, (Paint) null);
        this.canvasMaster.drawColor(0, PorterDuff.Mode.CLEAR);
        Paint paint = new Paint();
        if (this.softEdge) {
            paint.setMaskFilter(new BlurMaskFilter(10.0f, BlurMaskFilter.Blur.NORMAL));
        } else {
            paint.setMaskFilter(new BlurMaskFilter(1.0f, BlurMaskFilter.Blur.NORMAL));
        }
        paint.setAntiAlias(true);
        this.canvasMaster.drawPath(this.drawingPath, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        this.canvasMaster.drawBitmap(copy, 0.0f, 0.0f, paint);
        this.drawingImageView.invalidate();
    }

    /* access modifiers changed from: private */
    public void applyFloodFil(float f, float f2) {
        this.isBitmapUpdated = false;
        float imageViewZoom = getImageViewZoom();
        float f3 = f2 - this.TARGET_OFFSET;
        PointF imageViewTranslation = getImageViewTranslation();
        double d = (double) imageViewZoom;
        int i = (int) ((float) (((double) (f - imageViewTranslation.x)) / d));
        int i2 = (int) ((float) (((double) (f3 - imageViewTranslation.y)) / d));
        if (i >= 0 && i <= this.bitmapMaster.getWidth() && i2 >= 0 && i2 <= this.bitmapMaster.getHeight()) {
            this.isBitmapUpdated = true;
            this.targetValueX = i;
            this.targetValueY = i2;
            this.isAsyncExecuteForThresholdChange = false;
            applyFloodFillWithProgressBar();
        }
    }

    /* access modifiers changed from: private */
    public void applyRePlaceColor(float f, float f2) {
        this.isBitmapUpdated = false;
        float imageViewZoom = getImageViewZoom();
        float f3 = f2 - this.TARGET_OFFSET;
        PointF imageViewTranslation = getImageViewTranslation();
        double d = (double) imageViewZoom;
        int i = (int) ((float) (((double) (f - imageViewTranslation.x)) / d));
        int i2 = (int) ((float) (((double) (f3 - imageViewTranslation.y)) / d));
        if (i >= 0 && i <= this.bitmapMaster.getWidth() && i2 >= 0 && i2 <= this.bitmapMaster.getHeight() && this.bitmapMaster.getPixel(i, i2) != 0) {
            this.targetValueX = i;
            this.targetValueY = i2;
            Bitmap bitmap = this.bitmapMaster;
            rePlaceAcolorOfBitmap(bitmap, bitmap.getPixel(i, i2), 0);
            if (this.targetPoints.size() != 0) {
                this.isBitmapUpdated = true;
                if (this.redoPaths.size() > 0) {
                    resetRedoPathArrays();
                }
                addDrawingPathToArrayList();
            }
        }
    }

    public Bitmap resizeBitmapByCanvas(boolean z) {
        float f;
        float f2;
        float width = (float) this.originalBitmap.getWidth();
        float height = (float) this.originalBitmap.getHeight();
        if (width > height) {
            int i = this.imageViewWidth;
            f = (float) i;
            f2 = (((float) i) * height) / width;
        } else {
            int i2 = this.imageViewHeight;
            float f3 = (float) i2;
            f = (((float) i2) * width) / height;
            f2 = f3;
        }
        if (f > width || f2 > height) {
            return this.originalBitmap;
        }
        Bitmap createBitmap = Bitmap.createBitmap((int) f, (int) f2, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        float f4 = f / width;
        Matrix matrix = new Matrix();
        matrix.postTranslate(0.0f, (f2 - (height * f4)) / 2.0f);
        matrix.preScale(f4, f4);
        Paint paint = new Paint();
        paint.setFilterBitmap(true);
        canvas.drawBitmap(this.originalBitmap, matrix, paint);
        this.isImageResized = true;
        return createBitmap;
    }

    public void saveBmEditedToInternalStorage(Bitmap bitmap) {
        try {
            FileOutputStream openFileOutput = openFileOutput("BITMAP_EDITED", 0);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, openFileOutput);
            openFileOutput.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public Bitmap getBmEditedfromInternalStorage() {
        try {
            FileInputStream openFileInput = openFileInput("BITMAP_EDITED");
            Bitmap decodeStream = BitmapFactory.decodeStream(openFileInput);
            openFileInput.close();
            return decodeStream;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e2) {
            e2.printStackTrace();
            return null;
        }
    }

    public void resetPathArrays() {
        this.undoBtn.setEnabled(false);
        this.redoBtn.setEnabled(false);
        this.targetPointsArray.clear();
        this.redoTargetPointsArray.clear();
        this.paths.clear();
        this.brushSizes.clear();
        this.erasing.clear();
        this.redoPaths.clear();
        this.redoBrushSizes.clear();
        this.redoErasing.clear();
    }

    /* access modifiers changed from: private */
    public void addDrawingPathToArrayList() {
        if (this.paths.size() >= this.UNDO_LIMIT) {
            UpdateLastEiditedBitmapForUndoLimit();
            this.targetPointsArray.remove(0);
            this.paths.remove(0);
            this.erasing.remove(0);
            this.brushSizes.remove(0);
        }
        if (this.paths.size() == 0) {
            this.undoBtn.setEnabled(true);
            this.redoBtn.setEnabled(false);
        }
        int i = this.DRAWING_MODE;
        if (i == 1) {
            this.erasing.add(1);
        } else if (i == 2) {
            this.erasing.add(2);
        } else if (i == 4 || i == 3) {
            this.erasing.add(6);
        } else if (i == 7) {
            this.erasing.add(7);
        }
        this.brushSizes.add(Integer.valueOf(this.UPDATED_BRUSH_SIZE));
        this.paths.add(this.drawingPath);
        this.drawingPath = new Path();
        this.targetPointsArray.add(this.targetPoints);
        this.targetPoints = new Vector<>();
    }

    public void updateBrushWidth() {
        this.brush.width = this.BRUSH_SIZE / 2.0f;
        this.brush.invalidate();
    }

    public void updateBrushOffset() {
        this.brush.centery += ((float) this.OFFSET) - this.brush.offset;
        this.brush.offset = (float) this.OFFSET;
        this.brush.invalidate();
    }

    public void UpdateLastEiditedBitmapForUndoLimit() {
        Canvas canvas = new Canvas(this.lastEiditedBitmap);
        for (int i = 0; i < 1; i++) {
            int intValue = this.brushSizes.get(i).intValue();
            int intValue2 = this.erasing.get(i).intValue();
            Paint paint = new Paint();
            if (this.softEdge) {
                paint.setMaskFilter(new BlurMaskFilter(10.0f, BlurMaskFilter.Blur.NORMAL));
            } else {
                paint.setMaskFilter(new BlurMaskFilter(1.0f, BlurMaskFilter.Blur.NORMAL));
            }
            if (intValue2 == 1) {
                paint.setColor(0);
                paint.setStyle(Paint.Style.STROKE);
                paint.setAntiAlias(true);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
                paint.setStrokeWidth((float) intValue);
                canvas.drawPath(this.paths.get(i), paint);
            } else if (intValue2 == 2) {
                paint.setStrokeWidth((float) intValue);
                paint.setStyle(Paint.Style.STROKE);
                paint.setAntiAlias(true);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setStrokeCap(Paint.Cap.ROUND);
                BitmapShader bitmapShader = new BitmapShader(this.resizedBitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
                paint.setColor(-1);
                paint.setShader(bitmapShader);
                canvas.drawPath(this.paths.get(i), paint);
            } else if (intValue2 == 7) {
                Bitmap bitmap = this.lastEiditedBitmap;
                Bitmap copy = bitmap.copy(bitmap.getConfig(), true);
                new Canvas(copy).drawBitmap(this.lastEiditedBitmap, 0.0f, 0.0f, (Paint) null);
                Canvas canvas2 = new Canvas(this.lastEiditedBitmap);
                canvas2.drawColor(0, PorterDuff.Mode.CLEAR);
                Paint paint2 = new Paint();
                paint2.setAntiAlias(true);
                canvas2.drawPath(this.paths.get(i), paint2);
                paint2.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                canvas2.drawBitmap(copy, 0.0f, 0.0f, paint2);
            } else if (intValue2 == 6) {
                Vector vector = this.targetPointsArray.get(i);
                for (int i2 = 0; i2 < vector.size(); i2++) {
                    Point point = (Point) vector.get(i2);
                    this.lastEiditedBitmap.setPixel(point.x, point.y, 0);
                }
            }
        }
    }

    /* access modifiers changed from: private */
    public void applyFloodFillWithProgressBar() {
        this.thresholdContainer.setVisibility(View.INVISIBLE);
        this.spinner.setVisibility(View.VISIBLE);
        getWindow().setFlags(16, 16);
        this.thresholdSeekBar.setEnabled(false);
        new Handler().postDelayed(new Runnable() {

            /* renamed from: com.cutouteraser.backgroundremove.activity.BGRemoverActivity$20$autoRunabble */
            class autoRunabble implements Runnable {
                autoRunabble() {
                }

                public void run() {
                    BGRemoverActivity.this.spinner.setVisibility(View.INVISIBLE);
                    if (BGRemoverActivity.this.DRAWING_MODE == 4) {
                        BGRemoverActivity.this.thresholdContainer.setVisibility(View.VISIBLE);
                    }
                    BGRemoverActivity.this.thresholdSeekBar.setEnabled(true);
                    BGRemoverActivity.this.getWindow().clearFlags(16);
                }
            }

            public void run() {
                if (BGRemoverActivity.this.isAsyncExecuteForThresholdChange) {
                    BGRemoverActivity.this.undoForThresholdChange();
                }
                BGRemoverActivity bGRemoverActivity = BGRemoverActivity.this;
                bGRemoverActivity.FloodFill(bGRemoverActivity.bitmapMaster, new Point(BGRemoverActivity.this.targetValueX, BGRemoverActivity.this.targetValueY), BGRemoverActivity.this.bitmapMaster.getPixel(BGRemoverActivity.this.targetValueX, BGRemoverActivity.this.targetValueY), 0);
                if (BGRemoverActivity.this.isBitmapUpdated) {
                    BGRemoverActivity.this.addDrawingPathToArrayList();
                    BGRemoverActivity.this.resetRedoPathArrays();
                    BGRemoverActivity.this.undoBtn.setEnabled(true);
                    BGRemoverActivity.this.redoBtn.setEnabled(false);
                }
                new Handler().postDelayed(new autoRunabble(), 100);
            }
        }, 100);
    }

    public void rePlaceAcolorOfBitmap(Bitmap bitmap, int i, int i2) {
        for (int i3 = 0; i3 < bitmap.getWidth(); i3++) {
            for (int i4 = 0; i4 < bitmap.getHeight(); i4++) {
                if (compareColor(bitmap.getPixel(i3, i4), i)) {
                    bitmap.setPixel(i3, i4, i2);
                    this.targetPoints.add(new Point(i3, i4));
                }
            }
        }
        this.drawingImageView.invalidate();
    }

    public boolean compareColor(int i, int i2) {
        if (!(i == 0 || i2 == 0)) {
            if (i == i2) {
                return true;
            }
            int abs = Math.abs(Color.red(i) - Color.red(i2));
            int abs2 = Math.abs(Color.green(i) - Color.green(i2));
            int abs3 = Math.abs(Color.blue(i) - Color.blue(i2));
            int i3 = this.TOLERANCE;
            return abs <= i3 && abs2 <= i3 && abs3 <= i3;
        }
        return false;
    }

    public void rePlaceColor(Bitmap bitmap, int i, int i2, int i3, int i4) {
        int max = Math.max(i - i4, 0);
        int max2 = Math.max(i2 - i4, 0);
        int max3 = Math.max(i3 - i4, 0);
        int min = Math.min(i + i4, 255);
        int min2 = Math.min(i2 + i4, 255);
        int min3 = Math.min(i3 + i4, 255);
        for (int i5 = 0; i5 < bitmap.getWidth(); i5++) {
            for (int i6 = 0; i6 < bitmap.getHeight(); i6++) {
                int pixel = bitmap.getPixel(i5, i6);
                int i7 = (pixel >> 16) & 255;
                int i8 = (pixel >> 8) & 255;
                int i9 = pixel & 255;
                if (i7 >= max && i7 <= min && i8 >= max2 && i8 <= min2 && i9 >= max3 && i9 <= min3) {
                    bitmap.setPixel(i5, i6, 0);
                    this.targetPoints.add(new Point(i5, i6));
                }
            }
        }
        this.drawingImageView.invalidate();
    }

    public void undoForThresholdChange() {
        int size = this.paths.size() - 1;
        if (this.erasing.get(size).intValue() == 6) {
            Vector vector = this.targetPointsArray.get(size);
            for (int i = 0; i < vector.size(); i++) {
                Point point = (Point) vector.get(i);
                this.bitmapMaster.setPixel(point.x, point.y, this.resizedBitmap.getPixel(point.x, point.y));
            }
            this.targetPointsArray.remove(size);
            this.paths.remove(size);
            this.erasing.remove(size);
            this.brushSizes.remove(size);
        }
    }

    /* access modifiers changed from: private */
    public void FloodFill(Bitmap bitmap, Point point, int i, int i2) {
        if (i == 0) {
            this.isBitmapUpdated = false;
            return;
        }
        LinkedList linkedList = new LinkedList();
        linkedList.add(point);
        while (linkedList.size() > 0) {
            Point point2 = (Point) linkedList.poll();
            if (compareColor(bitmap.getPixel(point2.x, point2.y), i)) {
                Point point3 = new Point(point2.x + 1, point2.y);
                while (point2.x > 0 && compareColor(bitmap.getPixel(point2.x, point2.y), i)) {
                    bitmap.setPixel(point2.x, point2.y, i2);
                    this.targetPoints.add(new Point(point2.x, point2.y));
                    if (point2.y > 0 && compareColor(bitmap.getPixel(point2.x, point2.y - 1), i)) {
                        linkedList.add(new Point(point2.x, point2.y - 1));
                    }
                    if (point2.y < bitmap.getHeight() - 1 && compareColor(bitmap.getPixel(point2.x, point2.y + 1), i)) {
                        linkedList.add(new Point(point2.x, point2.y + 1));
                    }
                    point2.x--;
                }
                while (point3.x < bitmap.getWidth() - 1 && compareColor(bitmap.getPixel(point3.x, point3.y), i)) {
                    bitmap.setPixel(point3.x, point3.y, i2);
                    this.targetPoints.add(new Point(point3.x, point3.y));
                    if (point3.y > 0 && compareColor(bitmap.getPixel(point3.x, point3.y - 1), i)) {
                        linkedList.add(new Point(point3.x, point3.y - 1));
                    }
                    if (point3.y < bitmap.getHeight() - 1 && compareColor(bitmap.getPixel(point3.x, point3.y + 1), i)) {
                        linkedList.add(new Point(point3.x, point3.y + 1));
                    }
                    point3.x++;
                }
            }
        }
    }

    public void resetRedoPathArrays() {
        this.redoBtn.setEnabled(false);
        this.redoTargetPointsArray.clear();
        this.redoPaths.clear();
        this.redoBrushSizes.clear();
        this.redoErasing.clear();
    }

    public float getImageViewZoom() {
        return this.drawingImageView.getCurrentZoom();
    }

    public boolean hasInternet() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED) {
            return true;
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}
