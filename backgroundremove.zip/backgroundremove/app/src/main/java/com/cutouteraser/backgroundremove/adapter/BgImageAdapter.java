package com.cutouteraser.backgroundremove.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.cutouteraser.backgroundremove.R;

public class BgImageAdapter extends RecyclerView.Adapter<BgImageAdapter.MyViewHolder> {
    private Activity context;
    private int[] msgImages;

    public BgImageAdapter(Activity activity, int[] iArr) {
        this.context = activity;
        this.msgImages = iArr;
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.bgimage_layout, viewGroup, false));
    }

    public void onBindViewHolder(MyViewHolder myViewHolder, int i) {
        Glide.with(this.context).load(Integer.valueOf(this.msgImages[i])).into(myViewHolder.imageView);
    }

    public int getItemCount() {
        return this.msgImages.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;

        public MyViewHolder(View view) {
            super(view);
            this.imageView = (ImageView) view.findViewById(R.id.image);
        }
    }
}
