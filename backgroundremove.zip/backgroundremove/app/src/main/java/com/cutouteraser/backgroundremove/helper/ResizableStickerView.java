package com.cutouteraser.backgroundremove.helper;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.cutouteraser.backgroundremove.R;

public class ResizableStickerView extends RelativeLayout implements MultiTouchListener.TouchCallbackListener {
    private static final int SELF_SIZE_DP = 30;
    public static final String TAG = "ResizableStickerView";
    private int alphaProg = 0;
    double angle = 0.0d;
    int baseh;
    int basew;
    int basex;
    int basey;
    private ImageView border_iv;
    private Bitmap btmp = null;

    /* renamed from: cX */
    float f177cX = 0.0f;

    /* renamed from: cY */
    float f178cY = 0.0f;
    private double centerX = 0.0d;
    private double centerY = 0.0d;
    private String colorType = "color";
    private Context context;
    double dAngle = 0.0d;
    private ImageView delete_iv;
    private int drawableId;
    private ImageView edit_iv;
    private ImageView flip_iv;
    /* access modifiers changed from: private */

    /* renamed from: he */
    public int f179he;
    private int hueProg = 0;
    private int imgColor = 0;
    private boolean isBorderVisible = false;
    private boolean isColorFilterEnable = false;
    private boolean isSticker = true;
    private boolean isStrickerEditEnable = false;
    /* access modifiers changed from: private */
    public TouchEventListener listener = null;
    private OnTouchListener mTouchListener1 = new OnTouchListener() {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int rawX = (int) motionEvent.getRawX();
            int rawY = (int) motionEvent.getRawY();
            LayoutParams layoutParams = (LayoutParams) ResizableStickerView.this.getLayoutParams();
            int action = motionEvent.getAction();
            if (action == 0) {
                ResizableStickerView.this.invalidate();
                ResizableStickerView.this.basex = rawX;
                ResizableStickerView.this.basey = rawY;
                ResizableStickerView resizableStickerView = ResizableStickerView.this;
                resizableStickerView.basew = resizableStickerView.getWidth();
                ResizableStickerView resizableStickerView2 = ResizableStickerView.this;
                resizableStickerView2.baseh = resizableStickerView2.getHeight();
                ResizableStickerView.this.getLocationOnScreen(new int[2]);
                ResizableStickerView.this.margl = layoutParams.leftMargin;
                ResizableStickerView.this.margt = layoutParams.topMargin;
                ResizableStickerView.this.bringToFront();
                if (ResizableStickerView.this.listener != null) {
                    ResizableStickerView.this.listener.onEdit(ResizableStickerView.this, "gone");
                }
            } else if (action == 1) {
                ResizableStickerView resizableStickerView3 = ResizableStickerView.this;
                int unused = resizableStickerView3.f181wi = resizableStickerView3.getLayoutParams().width;
                ResizableStickerView resizableStickerView4 = ResizableStickerView.this;
                int unused2 = resizableStickerView4.f179he = resizableStickerView4.getLayoutParams().height;
                if (ResizableStickerView.this.listener != null) {
                    ResizableStickerView.this.listener.onEdit(ResizableStickerView.this, "view");
                }
            } else if (action == 2) {
                float degrees = (float) Math.toDegrees(Math.atan2((double) (rawY - ResizableStickerView.this.basey), (double) (rawX - ResizableStickerView.this.basex)));
                if (degrees < 0.0f) {
                    degrees += 360.0f;
                }
                int i = rawX - ResizableStickerView.this.basex;
                int i2 = rawY - ResizableStickerView.this.basey;
                int i3 = i2 * i2;
                int sqrt = (int) (Math.sqrt((double) ((i * i) + i3)) * Math.cos(Math.toRadians((double) (degrees - ResizableStickerView.this.getRotation()))));
                int sqrt2 = (int) (Math.sqrt((double) ((sqrt * sqrt) + i3)) * Math.sin(Math.toRadians((double) (degrees - ResizableStickerView.this.getRotation()))));
                int i4 = (sqrt * 2) + ResizableStickerView.this.basew;
                int i5 = (sqrt2 * 2) + ResizableStickerView.this.baseh;
                if (i4 > ResizableStickerView.this.f180s) {
                    layoutParams.width = i4;
                    layoutParams.leftMargin = ResizableStickerView.this.margl - sqrt;
                }
                if (i5 > ResizableStickerView.this.f180s) {
                    layoutParams.height = i5;
                    layoutParams.topMargin = ResizableStickerView.this.margt - sqrt2;
                }
                ResizableStickerView.this.setLayoutParams(layoutParams);
                ResizableStickerView.this.performLongClick();
            }
            return true;
        }
    };
    public ImageView main_iv;
    int margl;
    int margt;
    double onTouchAngle = 0.0d;
    private OnTouchListener rTouchListener = new OnTouchListener() {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action == 1) {
                ResizableStickerView.this.bringToFront();
                if (ResizableStickerView.this.listener != null) {
                    ResizableStickerView.this.listener.onEdit(ResizableStickerView.this, "view");
                }
            } else if (action == 2) {
                ResizableStickerView resizableStickerView = ResizableStickerView.this;
                resizableStickerView.angle = (Math.atan2((double) (resizableStickerView.f178cY - motionEvent.getRawY()), (double) (ResizableStickerView.this.f177cX - motionEvent.getRawX())) * 180.0d) / 3.141592653589793d;
                ((View) view.getParent()).setRotation((float) (ResizableStickerView.this.angle + ResizableStickerView.this.dAngle));
                ((View) view.getParent()).invalidate();
                ((View) view.getParent()).requestLayout();
            } else if (action == 3) {
                Rect rect = new Rect();
                ((View) view.getParent()).getGlobalVisibleRect(rect);
                ResizableStickerView.this.f177cX = rect.exactCenterX();
                ResizableStickerView.this.f178cY = rect.exactCenterY();
                ResizableStickerView.this.vAngle = (double) ((View) view.getParent()).getRotation();
                ResizableStickerView resizableStickerView2 = ResizableStickerView.this;
                resizableStickerView2.tAngle = (Math.atan2((double) (resizableStickerView2.f178cY - motionEvent.getRawY()), (double) (ResizableStickerView.this.f177cX - motionEvent.getRawX())) * 180.0d) / 3.141592653589793d;
                ResizableStickerView resizableStickerView3 = ResizableStickerView.this;
                resizableStickerView3.dAngle = resizableStickerView3.vAngle - ResizableStickerView.this.tAngle;
                if (ResizableStickerView.this.listener != null) {
                    ResizableStickerView.this.listener.onEdit(ResizableStickerView.this, "gone");
                }
            }
            return true;
        }
    };
    private Uri resUri = null;
    private float rotation;
    /* access modifiers changed from: private */

    /* renamed from: s */
    public int f180s;
    Animation scale;
    private ImageView scale_iv;
    private double scale_orgHeight = -1.0d;
    private double scale_orgWidth = -1.0d;
    private float scale_orgX = -1.0f;
    private float scale_orgY = -1.0f;
    double tAngle = 0.0d;
    private float this_orgX = -1.0f;
    private float this_orgY = -1.0f;
    double vAngle = 0.0d;
    /* access modifiers changed from: private */

    /* renamed from: wi */
    public int f181wi;
    private float yRotation;
    Animation zoomInScale;
    Animation zoomOutScale;

    public interface TouchEventListener {
        void onDelete();

        void onEdit(View view, String str);

        void onTouchDown(View view);

        void onTouchUp(View view);
    }

    public ResizableStickerView setOnTouchCallbackListener(TouchEventListener touchEventListener) {
        this.listener = touchEventListener;
        return this;
    }

    public ResizableStickerView(Context context2) {
        super(context2);
        init(context2);
    }

    public ResizableStickerView(Context context2, AttributeSet attributeSet) {
        super(context2, attributeSet);
        init(context2);
    }

    public ResizableStickerView(Context context2, AttributeSet attributeSet, int i) {
        super(context2, attributeSet, i);
        init(context2);
    }

    public void init(Context context2) {
        this.context = context2;
        this.main_iv = new ImageView(this.context);
        this.scale_iv = new ImageView(this.context);
        this.border_iv = new ImageView(this.context);
        this.flip_iv = new ImageView(this.context);
        this.edit_iv = new ImageView(this.context);
        this.delete_iv = new ImageView(this.context);
        this.f180s = dpToPx(this.context, 25);
        this.f181wi = dpToPx(this.context, 200);
        this.f179he = dpToPx(this.context, 200);
        this.scale_iv.setImageResource(R.drawable.sticker_scale);
        this.border_iv.setImageResource(R.drawable.sticker_border_gray);
        this.flip_iv.setImageResource(R.drawable.sticker_flip);
        this.edit_iv.setImageResource(R.drawable.rotate);
        this.delete_iv.setImageResource(R.drawable.sticker_delete1);
        LayoutParams layoutParams = new LayoutParams(this.f181wi, this.f179he);
        LayoutParams layoutParams2 = new LayoutParams(-1, -1);
        layoutParams2.setMargins(5, 5, 5, 5);
        layoutParams2.addRule(17);
        int i = this.f180s;
        LayoutParams layoutParams3 = new LayoutParams(i, i);
        layoutParams3.addRule(12);
        layoutParams3.addRule(11);
        layoutParams3.setMargins(5, 5, 5, 5);
        int i2 = this.f180s;
        LayoutParams layoutParams4 = new LayoutParams(i2, i2);
        layoutParams4.addRule(10);
        layoutParams4.addRule(11);
        layoutParams4.setMargins(5, 5, 5, 5);
        int i3 = this.f180s;
        LayoutParams layoutParams5 = new LayoutParams(i3, i3);
        layoutParams5.addRule(12);
        layoutParams5.addRule(9);
        layoutParams5.setMargins(5, 5, 5, 5);
        int i4 = this.f180s;
        LayoutParams layoutParams6 = new LayoutParams(i4, i4);
        layoutParams6.addRule(10);
        layoutParams6.addRule(9);
        layoutParams6.setMargins(5, 5, 5, 5);
        LayoutParams layoutParams7 = new LayoutParams(-1, -1);
        setLayoutParams(layoutParams);
        addView(this.border_iv);
        this.border_iv.setLayoutParams(layoutParams7);
        this.border_iv.setScaleType(ImageView.ScaleType.FIT_XY);
        this.border_iv.setTag("border_iv");
        addView(this.main_iv);
        this.main_iv.setLayoutParams(layoutParams2);
        this.main_iv.setTag("main_iv");
        addView(this.flip_iv);
        this.flip_iv.setLayoutParams(layoutParams4);
        this.flip_iv.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                ImageView imageView = ResizableStickerView.this.main_iv;
                float f = -180.0f;
                if (ResizableStickerView.this.main_iv.getRotationY() == -180.0f) {
                    f = 0.0f;
                }
                imageView.setRotationY(f);
                ResizableStickerView.this.main_iv.invalidate();
                ResizableStickerView.this.requestLayout();
            }
        });
        addView(this.edit_iv);
        this.edit_iv.setLayoutParams(layoutParams5);
        this.edit_iv.setOnTouchListener(this.rTouchListener);
        addView(this.delete_iv);
        this.delete_iv.setLayoutParams(layoutParams6);
        this.delete_iv.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                final ViewGroup viewGroup = (ViewGroup) ResizableStickerView.this.getParent();
                ResizableStickerView.this.zoomInScale.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationRepeat(Animation animation) {
                    }

                    public void onAnimationStart(Animation animation) {
                    }

                    public void onAnimationEnd(Animation animation) {
                        viewGroup.removeView(ResizableStickerView.this);
                    }
                });
                ResizableStickerView.this.main_iv.startAnimation(ResizableStickerView.this.zoomInScale);
                ResizableStickerView.this.setBorderVisibility(false);
                if (ResizableStickerView.this.listener != null) {
                    ResizableStickerView.this.listener.onDelete();
                }
            }
        });
        addView(this.scale_iv);
        this.scale_iv.setLayoutParams(layoutParams3);
        this.scale_iv.setOnTouchListener(this.mTouchListener1);
        this.scale_iv.setTag("scale_iv");
        this.rotation = getRotation();
        this.scale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_anim);
        this.zoomOutScale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_zoom_out);
        this.zoomInScale = AnimationUtils.loadAnimation(getContext(), R.anim.sticker_scale_zoom_in);
        setDefaultTouchListener();
    }

    public void setDefaultTouchListener() {
        setOnTouchListener(new MultiTouchListener().enableRotation(true).setOnTouchCallbackListener(this));
    }

    public void setBorderVisibility(boolean z) {
        this.isBorderVisible = z;
        if (!z) {
            this.border_iv.setVisibility(View.GONE);
            this.scale_iv.setVisibility(View.GONE);
            this.flip_iv.setVisibility(View.GONE);
            this.edit_iv.setVisibility(View.GONE);
            this.delete_iv.setVisibility(View.GONE);
            setBackgroundResource(0);
            if (this.isColorFilterEnable) {
                this.main_iv.setColorFilter(Color.parseColor("#303828"));
            }
        } else if (this.border_iv.getVisibility() != View.VISIBLE) {
            this.border_iv.setVisibility(View.VISIBLE);
            this.scale_iv.setVisibility(View.VISIBLE);
            if (this.isSticker) {
                this.flip_iv.setVisibility(View.VISIBLE);
            }
            this.edit_iv.setVisibility(View.VISIBLE);
            this.delete_iv.setVisibility(View.VISIBLE);
            this.main_iv.startAnimation(this.scale);
        }
    }

    public boolean getBorderVisbilty() {
        return this.isBorderVisible;
    }

    public int getHueProg() {
        return this.hueProg;
    }

    public void setHueProg(int i) {
        this.hueProg = i;
        this.main_iv.setColorFilter(ColorFilterGenerator.adjustHue((float) i));
    }

    public String getColorType() {
        return this.colorType;
    }

    public void setColorType(String str) {
        this.colorType = str;
    }

    public int getAlphaProg() {
        return this.alphaProg;
    }

    public void setAlphaProg(int i) {
        this.alphaProg = i;
        this.main_iv.setImageAlpha(255 - i);
    }

    public int getColor() {
        return this.imgColor;
    }

    public void setColor(int i) {
        try {
            this.main_iv.setColorFilter(i);
            this.imgColor = i;
        } catch (Exception unused) {
        }
    }

    public void setBgDrawable(int i) {
        try {
            this.main_iv.setImageResource(i);
            this.drawableId = i;
            this.main_iv.startAnimation(this.zoomOutScale);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public void setMainImageUri(Uri uri) {
        this.resUri = uri;
        this.main_iv.setImageURI(uri);
    }

    public Uri getMainImageUri() {
        return this.resUri;
    }

    public void setMainImageBitmap(Bitmap bitmap) {
        this.main_iv.setImageBitmap(bitmap);
    }

    public Bitmap getMainImageBitmap() {
        return this.btmp;
    }

    public void setComponentInfo(ComponentInfo componentInfo) {
        this.f181wi = componentInfo.getWIDTH();
        this.f179he = componentInfo.getHEIGHT();
        this.drawableId = componentInfo.getRES_ID();
        this.resUri = componentInfo.getRES_URI();
        this.btmp = componentInfo.getBITMAP();
        this.imgColor = componentInfo.getSTC_COLOR();
        this.rotation = componentInfo.getROTATION();
        this.yRotation = componentInfo.getY_ROTATION();
        this.colorType = componentInfo.getCOLORTYPE();
        setX(componentInfo.getPOS_X());
        setY(componentInfo.getPOS_Y());
        int i = this.drawableId;
        if (i == 0) {
            this.main_iv.setImageBitmap(this.btmp);
        } else {
            setBgDrawable(i);
        }
        setRotation(this.rotation);
        setColor(this.imgColor);
        setColorType(this.colorType);
        getLayoutParams().width = this.f181wi;
        getLayoutParams().height = this.f179he;
        if (componentInfo.getTYPE() == "SHAPE") {
            this.flip_iv.setVisibility(View.GONE);
            this.isSticker = false;
        }
        if (componentInfo.getTYPE() == "STICKER") {
            this.flip_iv.setVisibility(View.VISIBLE);
            this.isSticker = true;
        }
        this.main_iv.setRotationY(this.yRotation);
    }

    public void optimize(float f, float f2) {
        setX(getX() * f);
        setY(getY() * f2);
        getLayoutParams().width = (int) (((float) this.f181wi) * f);
        getLayoutParams().height = (int) (((float) this.f179he) * f2);
    }

    public ComponentInfo getComponentInfo() {
        ComponentInfo componentInfo = new ComponentInfo();
        componentInfo.setPOS_X(getX());
        componentInfo.setPOS_Y(getY());
        componentInfo.setWIDTH(this.f181wi);
        componentInfo.setHEIGHT(this.f179he);
        componentInfo.setRES_ID(this.drawableId);
        componentInfo.setSTC_COLOR(this.imgColor);
        componentInfo.setRES_URI(this.resUri);
        componentInfo.setCOLORTYPE(this.colorType);
        componentInfo.setBITMAP(this.btmp);
        componentInfo.setROTATION(getRotation());
        componentInfo.setY_ROTATION(this.main_iv.getRotationY());
        return componentInfo;
    }

    public int dpToPx(Context context2, int i) {
        context2.getResources();
        return (int) (((float) i) * Resources.getSystem().getDisplayMetrics().density);
    }

    private double getLength(double d, double d2, double d3, double d4) {
        return Math.sqrt(Math.pow(d4 - d2, 2.0d) + Math.pow(d3 - d, 2.0d));
    }

    public void enableColorFilter(boolean z) {
        this.isColorFilterEnable = z;
    }

    public void onTouchCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchDown(view);
        }
    }

    public void onTouchUpCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchUp(view);
        }
    }
}
