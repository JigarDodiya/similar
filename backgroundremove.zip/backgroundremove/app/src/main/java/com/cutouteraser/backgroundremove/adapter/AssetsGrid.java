package com.cutouteraser.backgroundremove.adapter;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.cutouteraser.backgroundremove.R;

public class AssetsGrid extends BaseAdapter {
    private final String[] Imageid;
    private Context mContext;

    public long getItemId(int i) {
        return 0;
    }

    public class ViewHolder {
        TextView txtView;

        public ViewHolder() {
        }
    }

    public AssetsGrid(Context context, String[] strArr) {
        this.mContext = context;
        this.Imageid = strArr;
    }

    public int getCount() {
        return this.Imageid.length;
    }

    public Object getItem(int i) {
        return this.Imageid[i];
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            view = ((LayoutInflater) this.mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.libtext_grid_assets, (ViewGroup) null);
            viewHolder = new ViewHolder();
            viewHolder.txtView = (TextView) view.findViewById(R.id.grid_text);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        TextView textView = viewHolder.txtView;
        AssetManager assets = this.mContext.getAssets();
        textView.setTypeface(Typeface.createFromAsset(assets, "fonts/" + this.Imageid[i]));
        return view;
    }
}
