package com.cutouteraser.backgroundremove.helper;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.cutouteraser.backgroundremove.R;

public class AutofitTextRel extends RelativeLayout implements MultiTouchListener.TouchCallbackListener {
    public static final String TAG = "TextView";
    /* access modifiers changed from: private */
    public ImageView background_iv;
    int baseh;
    int basew;
    int basex;
    int basey;
    private int bgAlpha = 255;
    private int bgColor = 0;
    /* access modifiers changed from: private */
    public String bgDrawable = "0";
    private ImageView border_iv;
    /* access modifiers changed from: private */
    public double centerX;
    /* access modifiers changed from: private */
    public double centerY;
    private Context context;
    private ImageView delete_iv;
    private String fontName = "";

    /* renamed from: gd */
    private GestureDetector f171gd = null;
    /* access modifiers changed from: private */

    /* renamed from: he */
    public int f172he;
    private boolean isBorderVisible = false;
    /* access modifiers changed from: private */
    public TouchEventListener listener = null;
    private OnTouchListener mTouchListener1 = new OnTouchListener() {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int rawX = (int) motionEvent.getRawX();
            int rawY = (int) motionEvent.getRawY();
            LayoutParams layoutParams = (LayoutParams) AutofitTextRel.this.getLayoutParams();
            int action = motionEvent.getAction();
            if (action == 0) {
                AutofitTextRel.this.invalidate();
                AutofitTextRel.this.basex = rawX;
                AutofitTextRel.this.basey = rawY;
                AutofitTextRel autofitTextRel = AutofitTextRel.this;
                autofitTextRel.basew = autofitTextRel.getWidth();
                AutofitTextRel autofitTextRel2 = AutofitTextRel.this;
                autofitTextRel2.baseh = autofitTextRel2.getHeight();
                AutofitTextRel.this.getLocationOnScreen(new int[2]);
                AutofitTextRel.this.margl = layoutParams.leftMargin;
                AutofitTextRel.this.margt = layoutParams.topMargin;
                if (AutofitTextRel.this.listener != null) {
                    AutofitTextRel.this.listener.onEdit(AutofitTextRel.this, "gone");
                }
            } else if (action == 1) {
                AutofitTextRel autofitTextRel3 = AutofitTextRel.this;
                int unused = autofitTextRel3.f174wi = autofitTextRel3.getLayoutParams().width;
                AutofitTextRel autofitTextRel4 = AutofitTextRel.this;
                int unused2 = autofitTextRel4.f172he = autofitTextRel4.getLayoutParams().height;
                if (AutofitTextRel.this.listener != null) {
                    AutofitTextRel.this.listener.onEdit(AutofitTextRel.this, "view");
                }
            } else if (action == 2) {
                float degrees = (float) Math.toDegrees(Math.atan2((double) (rawY - AutofitTextRel.this.basey), (double) (rawX - AutofitTextRel.this.basex)));
                if (degrees < 0.0f) {
                    degrees += 360.0f;
                }
                int i = rawX - AutofitTextRel.this.basex;
                int i2 = rawY - AutofitTextRel.this.basey;
                int i3 = i2 * i2;
                int sqrt = (int) (Math.sqrt((double) ((i * i) + i3)) * Math.cos(Math.toRadians((double) (degrees - AutofitTextRel.this.getRotation()))));
                int sqrt2 = (int) (Math.sqrt((double) ((sqrt * sqrt) + i3)) * Math.sin(Math.toRadians((double) (degrees - AutofitTextRel.this.getRotation()))));
                int i4 = (sqrt * 2) + AutofitTextRel.this.basew;
                int i5 = (sqrt2 * 2) + AutofitTextRel.this.baseh;
                if (i4 > AutofitTextRel.this.f173s) {
                    layoutParams.width = i4;
                    layoutParams.leftMargin = AutofitTextRel.this.margl - sqrt;
                }
                if (i5 > AutofitTextRel.this.f173s) {
                    layoutParams.height = i5;
                    layoutParams.topMargin = AutofitTextRel.this.margt - sqrt2;
                }
                AutofitTextRel.this.setLayoutParams(layoutParams);
                if (!AutofitTextRel.this.bgDrawable.equals("0")) {
                    AutofitTextRel autofitTextRel5 = AutofitTextRel.this;
                    int unused3 = autofitTextRel5.f174wi = autofitTextRel5.getLayoutParams().width;
                    AutofitTextRel autofitTextRel6 = AutofitTextRel.this;
                    int unused4 = autofitTextRel6.f172he = autofitTextRel6.getLayoutParams().height;
                    AutofitTextRel autofitTextRel7 = AutofitTextRel.this;
                    autofitTextRel7.setBgDrawable(autofitTextRel7.bgDrawable);
                }
            }
            return true;
        }
    };
    int margl;
    int margt;
    double onTouchAngle = 0.0d;
    private OnTouchListener rTouchListener = new OnTouchListener() {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action == 0) {
                double unused = AutofitTextRel.this.centerX = (double) ((((float) ((View) view.getParent()).getWidth()) / 2.0f) + ((View) view.getParent()).getX() + ((View) ((View) view.getParent()).getParent()).getX());
                int identifier = AutofitTextRel.this.getResources().getIdentifier("status_bar_height", "dimen", "android");
                double unused2 = AutofitTextRel.this.centerY = ((double) (((View) ((View) view.getParent()).getParent()).getY() + ((View) view.getParent()).getY())) + ((double) (identifier > 0 ? AutofitTextRel.this.getResources().getDimensionPixelSize(identifier) : 0)) + ((double) (((float) ((View) view.getParent()).getHeight()) / 2.0f));
                int[] iArr = new int[2];
                ((View) view.getParent()).getLocationOnScreen(iArr);
                ((View) view.getParent()).getRotation();
                double unused3 = AutofitTextRel.this.centerX = (double) ((((float) ((View) view.getParent()).getWidth()) / 2.0f) + ((float) iArr[0]));
                double unused4 = AutofitTextRel.this.centerY = (double) ((((float) ((View) view.getParent()).getHeight()) / 2.0f) + ((float) iArr[1]));
                AutofitTextRel autofitTextRel = AutofitTextRel.this;
                autofitTextRel.onTouchAngle = (Math.atan2(autofitTextRel.centerY - ((double) motionEvent.getRawY()), ((double) motionEvent.getRawX()) - AutofitTextRel.this.centerX) * 180.0d) / 3.141592653589793d;
                if (AutofitTextRel.this.listener != null) {
                    AutofitTextRel.this.listener.onEdit(AutofitTextRel.this, "gone");
                }
            } else if (action != 1) {
                if (action == 2) {
                    motionEvent.getRawY();
                    motionEvent.getRawX();
                    double atan2 = (Math.atan2(AutofitTextRel.this.centerY - ((double) motionEvent.getRawY()), ((double) motionEvent.getRawX()) - AutofitTextRel.this.centerX) * 180.0d) / 3.141592653589793d;
                    Log.v(AutofitTextRel.TAG, "log angle: " + atan2 + " ," + (((float) atan2) - 180.0f));
                    float rotation = ((View) view.getParent()).getRotation();
                    double d = atan2 - AutofitTextRel.this.onTouchAngle;
                    if (d > 0.5d || d < -0.5d) {
                        ((View) view.getParent()).setRotation(rotation - ((float) d));
                        AutofitTextRel.this.onTouchAngle = atan2;
                    }
                    ((View) view.getParent()).invalidate();
                    ((View) view.getParent()).requestLayout();
                }
            } else if (AutofitTextRel.this.listener != null) {
                AutofitTextRel.this.listener.onEdit(AutofitTextRel.this, "view");
            }
            return true;
        }
    };
    private ImageView rotate_iv;
    private float rotation;
    /* access modifiers changed from: private */

    /* renamed from: s */
    public int f173s;
    Animation scale;
    private ImageView scale_iv;
    private int shadowColor = 0;
    private int shadowProg = 0;
    private int tAlpha = 100;
    private int tColor = -1;
    private String text = "";
    /* access modifiers changed from: private */
    public AutoResizeTextView text_iv;
    /* access modifiers changed from: private */

    /* renamed from: wi */
    public int f174wi;
    Animation zoomInScale;
    Animation zoomOutScale;

    public interface TouchEventListener {
        void onDelete();

        void onDoubleTap();

        void onEdit(View view, String str);

        void onTouchDown(View view);

        void onTouchUp(View view);
    }

    public AutofitTextRel(Context context2) {
        super(context2);
        init(context2);
    }

    public AutofitTextRel(Context context2, AttributeSet attributeSet) {
        super(context2, attributeSet);
        init(context2);
    }

    public AutofitTextRel(Context context2, AttributeSet attributeSet, int i) {
        super(context2, attributeSet, i);
        init(context2);
    }

    public AutofitTextRel setOnTouchCallbackListener(TouchEventListener touchEventListener) {
        this.listener = touchEventListener;
        return this;
    }

    public void init(Context context2) {
        this.context = context2;
        this.text_iv = new AutoResizeTextView(this.context);
        this.scale_iv = new ImageView(this.context);
        this.border_iv = new ImageView(this.context);
        this.background_iv = new ImageView(this.context);
        this.delete_iv = new ImageView(this.context);
        this.rotate_iv = new ImageView(this.context);
        this.f173s = dpToPx(this.context, 30);
        this.f174wi = dpToPx(this.context, 200);
        this.f172he = dpToPx(this.context, 200);
        this.scale_iv.setImageResource(R.drawable.textlib_scale);
        this.background_iv.setImageResource(0);
        this.delete_iv.setImageResource(R.drawable.textlib_clear);
        this.rotate_iv.setImageResource(R.drawable.rotate);
        LayoutParams layoutParams = new LayoutParams(this.f174wi, this.f172he);
        int i = this.f173s;
        LayoutParams layoutParams2 = new LayoutParams(i, i);
        layoutParams2.addRule(12);
        layoutParams2.addRule(11);
        layoutParams2.setMargins(5, 5, 5, 5);
        int i2 = this.f173s;
        LayoutParams layoutParams3 = new LayoutParams(i2, i2);
        layoutParams3.addRule(12);
        layoutParams3.addRule(9);
        layoutParams3.setMargins(5, 5, 5, 5);
        LayoutParams layoutParams4 = new LayoutParams(-1, -1);
        layoutParams4.setMargins(5, 5, 5, 5);
        layoutParams4.addRule(17);
        int i3 = this.f173s;
        LayoutParams layoutParams5 = new LayoutParams(i3, i3);
        layoutParams5.addRule(10);
        layoutParams5.addRule(9);
        layoutParams5.setMargins(5, 5, 5, 5);
        LayoutParams layoutParams6 = new LayoutParams(-1, -1);
        LayoutParams layoutParams7 = new LayoutParams(-1, -1);
        setLayoutParams(layoutParams);
        setBackgroundResource(R.drawable.textlib_border_gray);
        addView(this.background_iv);
        this.background_iv.setLayoutParams(layoutParams7);
        this.background_iv.setScaleType(ImageView.ScaleType.FIT_XY);
        addView(this.border_iv);
        this.border_iv.setLayoutParams(layoutParams6);
        this.border_iv.setTag("border_iv");
        addView(this.text_iv);
        this.text_iv.setText(this.text);
        this.text_iv.setTextColor(this.tColor);
        this.text_iv.setTextSize(200.0f);
        this.text_iv.setLayoutParams(layoutParams4);
        this.text_iv.setGravity(17);
        this.text_iv.setMinTextSize(10.0f);
        addView(this.delete_iv);
        this.delete_iv.setLayoutParams(layoutParams5);
        this.delete_iv.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                final ViewGroup viewGroup = (ViewGroup) AutofitTextRel.this.getParent();
                AutofitTextRel.this.zoomInScale.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationRepeat(Animation animation) {
                    }

                    public void onAnimationStart(Animation animation) {
                    }

                    public void onAnimationEnd(Animation animation) {
                        viewGroup.removeView(AutofitTextRel.this);
                    }
                });
                AutofitTextRel.this.text_iv.startAnimation(AutofitTextRel.this.zoomInScale);
                AutofitTextRel.this.background_iv.startAnimation(AutofitTextRel.this.zoomInScale);
                AutofitTextRel.this.setBorderVisibility(false);
                if (AutofitTextRel.this.listener != null) {
                    AutofitTextRel.this.listener.onDelete();
                }
            }
        });
        addView(this.scale_iv);
        this.scale_iv.setLayoutParams(layoutParams2);
        this.scale_iv.setTag("scale_iv");
        this.scale_iv.setOnTouchListener(this.mTouchListener1);
        addView(this.rotate_iv);
        this.rotate_iv.setLayoutParams(layoutParams3);
        this.rotate_iv.setOnTouchListener(this.rTouchListener);
        this.rotation = getRotation();
        this.scale = AnimationUtils.loadAnimation(getContext(), R.anim.textlib_scale_anim);
        this.zoomOutScale = AnimationUtils.loadAnimation(getContext(), R.anim.textlib_scale_zoom_out);
        this.zoomInScale = AnimationUtils.loadAnimation(getContext(), R.anim.textlib_scale_zoom_in);
        initGD();
        setDefaultTouchListener();
    }

    public void setDefaultTouchListener() {
        setOnTouchListener(new MultiTouchListener().enableRotation(true).setOnTouchCallbackListener(this).setGestureListener(this.f171gd));
    }

    public boolean getBorderVisibility() {
        return this.isBorderVisible;
    }

    public void setBorderVisibility(boolean z) {
        this.isBorderVisible = z;
        if (!z) {
            this.border_iv.setVisibility(8);
            this.scale_iv.setVisibility(8);
            this.delete_iv.setVisibility(8);
            this.rotate_iv.setVisibility(8);
            setBackgroundResource(0);
        } else if (this.border_iv.getVisibility() != 0) {
            this.border_iv.setVisibility(0);
            this.scale_iv.setVisibility(0);
            this.delete_iv.setVisibility(0);
            this.rotate_iv.setVisibility(0);
            setBackgroundResource(R.drawable.textlib_border_gray);
            this.text_iv.startAnimation(this.scale);
        }
    }

    public String getBgDrawable() {
        return this.bgDrawable;
    }

    public void setBgDrawable(String str) {
        this.bgDrawable = str;
        this.bgColor = 0;
        Bitmap tiledBitmap = getTiledBitmap(this.context, getResources().getIdentifier(str, "drawable", this.context.getPackageName()), dpToPx(this.context, this.f174wi), dpToPx(this.context, this.f172he));
        if (tiledBitmap != null) {
            this.background_iv.setImageBitmap(tiledBitmap);
        }
        this.background_iv.setBackgroundColor(this.bgColor);
    }

    public String getText() {
        return this.text_iv.getText().toString();
    }

    public void setText(String str) {
        this.text_iv.setText(str);
        this.text = str;
        this.text_iv.startAnimation(this.zoomOutScale);
    }

    public void setTextFont(String str) {
        try {
            this.text_iv.setTypeface(Typeface.createFromAsset(this.context.getAssets(), str));
            this.fontName = str;
        } catch (Exception unused) {
        }
    }

    public void setTextColor(int i) {
        this.text_iv.setTextColor(i);
        this.tColor = i;
    }

    public void setTextAlpha(int i) {
        this.text_iv.setAlpha(((float) i) / 100.0f);
        this.tAlpha = i;
    }

    public void setTextShadowColor(int i) {
        this.shadowColor = i;
        this.text_iv.setShadowLayer((float) this.shadowProg, 0.0f, 0.0f, i);
    }

    public void setTextShadowProg(int i) {
        this.shadowProg = i;
        this.text_iv.setShadowLayer((float) i, 0.0f, 0.0f, this.shadowColor);
    }

    public void setBgColor(int i) {
        this.bgDrawable = "0";
        this.bgColor = i;
        this.background_iv.setImageResource(0);
        this.background_iv.setBackgroundColor(i);
    }

    public void setBgAlpha(int i) {
        this.background_iv.setAlpha(((float) i) / 255.0f);
        this.bgAlpha = i;
    }

    public TextInfo getTextInfo() {
        TextInfo textInfo = new TextInfo();
        textInfo.setPOS_X(getX());
        textInfo.setPOS_Y(getY());
        textInfo.setWIDTH(this.f174wi);
        textInfo.setHEIGHT(this.f172he);
        textInfo.setTEXT(this.text);
        textInfo.setFONT_NAME(this.fontName);
        textInfo.setTEXT_COLOR(this.tColor);
        textInfo.setTEXT_ALPHA(this.tAlpha);
        textInfo.setSHADOW_COLOR(this.shadowColor);
        textInfo.setSHADOW_PROG(this.shadowProg);
        textInfo.setBG_COLOR(this.bgColor);
        textInfo.setBG_DRAWABLE(this.bgDrawable);
        textInfo.setBG_ALPHA(this.bgAlpha);
        textInfo.setROTATION(getRotation());
        return textInfo;
    }

    public void setTextInfo(TextInfo textInfo) {
        this.f174wi = textInfo.getWIDTH();
        this.f172he = textInfo.getHEIGHT();
        this.text = textInfo.getTEXT();
        this.fontName = textInfo.getFONT_NAME();
        this.tColor = textInfo.getTEXT_COLOR();
        this.tAlpha = textInfo.getTEXT_ALPHA();
        this.shadowColor = textInfo.getSHADOW_COLOR();
        this.shadowProg = textInfo.getSHADOW_PROG();
        this.bgColor = textInfo.getBG_COLOR();
        this.bgDrawable = textInfo.getBG_DRAWABLE();
        this.bgAlpha = textInfo.getBG_ALPHA();
        this.rotation = textInfo.getROTATION();
        setX(textInfo.getPOS_X());
        setY(textInfo.getPOS_Y());
        setText(this.text);
        setTextFont(this.fontName);
        setTextColor(this.tColor);
        setTextAlpha(this.tAlpha);
        setTextShadowColor(this.shadowColor);
        setTextShadowProg(this.shadowProg);
        int i = this.bgColor;
        if (i != 0) {
            setBgColor(i);
        } else {
            this.background_iv.setBackgroundColor(0);
        }
        if (this.bgDrawable.equals("0")) {
            this.background_iv.setImageBitmap((Bitmap) null);
        } else {
            setBgDrawable(this.bgDrawable);
        }
        setBgAlpha(this.bgAlpha);
        setRotation(this.rotation);
        getLayoutParams().width = this.f174wi;
        getLayoutParams().height = this.f172he;
    }

    public void optimize(float f, float f2) {
        setX(getX() * f);
        setY(getY() * f2);
        getLayoutParams().width = (int) (((float) this.f174wi) * f);
        getLayoutParams().height = (int) (((float) this.f172he) * f2);
    }

    public int dpToPx(Context context2, int i) {
        context2.getResources();
        return (int) (((float) i) * Resources.getSystem().getDisplayMetrics().density);
    }

    private Bitmap getTiledBitmap(Context context2, int i, int i2, int i3) {
        Rect rect = new Rect(0, 0, i2, i3);
        Paint paint = new Paint();
        paint.setShader(new BitmapShader(BitmapFactory.decodeResource(context2.getResources(), i, new BitmapFactory.Options()), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        try {
            Bitmap createBitmap = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
            new Canvas(createBitmap).drawRect(rect, paint);
            return createBitmap;
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            return null;
        }
    }

    private void initGD() {
        this.f171gd = new GestureDetector(this.context, new GestureDetector.SimpleOnGestureListener() {
            public boolean onDoubleTapEvent(MotionEvent motionEvent) {
                return true;
            }

            public boolean onDown(MotionEvent motionEvent) {
                return true;
            }

            public boolean onDoubleTap(MotionEvent motionEvent) {
                if (AutofitTextRel.this.listener == null) {
                    return true;
                }
                AutofitTextRel.this.listener.onDoubleTap();
                return true;
            }

            public void onLongPress(MotionEvent motionEvent) {
                super.onLongPress(motionEvent);
            }
        });
    }

    public void onTouchCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchDown(view);
        }
    }

    public void onTouchUpCallback(View view) {
        TouchEventListener touchEventListener = this.listener;
        if (touchEventListener != null) {
            touchEventListener.onTouchUp(view);
        }
    }
}
